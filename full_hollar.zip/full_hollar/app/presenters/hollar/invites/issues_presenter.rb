module Hollar
  module Invites
    class IssuesPresenter < Draper::Decorator
      def type
        object.first
      end

      def message
        I18n.t "hollar.invites.issues.#{type}"
      end

      def emails
        object.last.map(&:email)
      end
    end
  end
end
