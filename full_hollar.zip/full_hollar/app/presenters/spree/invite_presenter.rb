module Spree
  # InvitePresenter is responsible of decorate the Invite model with
  # functions dedicated to the display
  class InvitePresenter < Draper::Decorator
    delegate :id, :date_sent, :referee_email, :status,
             :referer_id, :referee_id, :status_translation,
             :expire_at

    def credit_received
      moneyfy(object.credit_received)
    end

    def date_sent_humanized
      return '-' unless date_sent

      date_sent.strftime("%m/%d/%Y")
    end

    def expire_at_humanized
      return '-' unless expire_at

      expire_at.strftime("%m/%d/%Y")
    end

    private

    def moneyfy(amount)
      Spree::Money.new(amount,
                       currency: Spree::Config[:currency],
                       no_cents_if_whole: true).to_s
    end
  end
end
