class OrderRepository
  def find_by_number(number)
    model.where(number: number).first
  end

  private

  def model
    Spree::Order
  end
end
