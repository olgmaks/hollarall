class TaxonRepository
  def create_or_update(name, taxonomy, parent, published = false, description = nil)
    taxon = model.where(name: name).first
    if taxon
      taxon.permalink = name.parameterize
      taxon.published = published
      taxon.description = description if description
      taxon.save
      return taxon
    else
      model.create(name: name,
                   permalink: name.parameterize,
                   taxonomy_id: taxonomy.id,
                   parent_id: parent.try(:id),
                   published: published,
                   description: description)
    end
  end

  def model
    Spree::Taxon
  end
end
