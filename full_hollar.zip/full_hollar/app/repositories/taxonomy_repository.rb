class TaxonomyRepository
  def find_or_create name
    taxonomy = model.where(name: name).first
    return taxonomy if taxonomy

    model.create(name: name)
  end

  def model
    Spree::Taxonomy
  end
end
