class CommentRepository
  delegate :new, to: :model

  def find_all_by_order_id(order_id)
    model.where(order_id: order_id).order(created_at: :desc)
  end

  def find(id, order_id, customer_service_id)
    model.where(id: id.to_i,
                order_id: order_id,
                customer_service_id: customer_service_id).first
  end

  private

  def model
    Spree::Comment
  end
end
