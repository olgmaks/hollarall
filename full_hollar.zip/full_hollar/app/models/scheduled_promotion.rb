class ScheduledPromotion < ActiveRecord::Base
  belongs_to :promotion, class_name: '::Spree::Promotion'
  has_many :generated_scheduled_promotions
  has_many :codes, through: :generated_scheduled_promotions

  validates :campaign_name, presence: true

  scope :current, (lambda do
    now = Time.zone.now
    where('active = ? AND (effective_date IS NULL OR effective_date <= ?) AND (expiration_date IS NULL OR expiration_date > ?)',
      true, now, now)
  end)
end
