class ShelfGroup < ActiveRecord::Base
  acts_as_list

  has_many  :shelves, class_name: 'Shelf', foreign_key: :group_id, dependent: :nullify
  validates :permalink, presence: true, uniqueness: true, format: /\A[a-zA-Z0-9-]+\z/

  default_scope { order(position: :asc) }
  scope :published, -> { where(published: true) }

  has_attached_file :banner_image, ATTACHMENT_CONFIG.deep_merge(styles: { banner: '1400x290>' })
  validates_attachment :banner_image, content_type: { content_type: %w(image/jpg image/jpeg image/png image/gif) }

  has_attached_file :menu_icon, ATTACHMENT_CONFIG.deep_merge(styles: { icon: '60x60' })
  validates_attachment :menu_icon,
                       content_type: { content_type: %w(image/jpg image/jpeg image/png image/gif) }
end
