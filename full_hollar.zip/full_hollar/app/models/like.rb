class Like < ActiveRecord::Base
  belongs_to :user,    class_name: 'Spree::User'
  belongs_to :product, class_name: 'Spree::Product', counter_cache: :user_likes_count
end
