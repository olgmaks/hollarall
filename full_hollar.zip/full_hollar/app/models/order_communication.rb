class OrderCommunication < ActiveRecord::Base
  belongs_to :user, class_name: 'Spree::User'
  belongs_to :order, class_name: 'Spree::Order'
end
