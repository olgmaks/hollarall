class ProductRecommendationFactorHash < Hash
  def self.new
    results = Searchkick::Query.new(self, "*", load: false).results
    self[results.map { |r| [r["name"].to_sym, r["amount"]] }]
  rescue StandardError
    Rails.logger.info("Unable to load ProductRecommendationFactorHash from Elasticsearch")

    # good-enough values in case of emergency
    {
      order: 25.0,
      gender: 20.0,
      addtocart: 10.0,
      like: 8.0,
      view: 1.0
    }
  end

  # Searchkick config for for_user
  def self.searchkick_index
    Searchkick::Index.new("products_users_factors", searchkick_options)
  end

  def self.searchkick_options
    { load: false }
  end

  def self.searchkick_klass
    nil
  end

  def self.model_name
    "factor"
  end
end
