module Spree
  class Pod < ActiveRecord::Base
    acts_as_list
    has_one :image, class_name: Spree::Image, as: :viewable
    accepts_nested_attributes_for :image

    has_one :taxon
    belongs_to :taxon_destination, class_name: Spree::Taxon

    has_many :pod_products, class_name: 'Spree::PodsProduct'
    has_many :products, through: :pod_products

    scope :displayed_on_homepage, -> { where(display_homepage: true).order(position: :asc) }
  end
end
