module Hollar
  module Spree
    module StateDecorator
      def self.prepended(base)
        base.scope :billing, -> { base.where(billing: true, active: true) }
        base.scope :shipping, -> { base.where(shipping: true, active: true) }

        base.whitelisted_ransackable_attributes = %w[abbr]
      end
    end
  end
end

::Spree::State.prepend ::Hollar::Spree::StateDecorator
