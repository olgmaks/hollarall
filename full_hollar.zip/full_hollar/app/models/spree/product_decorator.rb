# predefine SearchkickWorker and pull in Searchkick::ReindexV2Job definition for Searchkick's reindex_async
SearchkickWorker.new

module Hollar
  module Spree
    module ProductDecorator
      REGULAR_PRICE_SAVINGS_MINIMUM = 50
      SHELVES_INDEX_MAP = {
        'Homepage Top'          => :homepage_position,
        'Homepage Top - Male'   => :homepage_position_male,
        'Homepage Top - Female' => :homepage_position_female
      }

      module ClassMethods
        def by_variant_id(variant_id)
          ::Spree::Product.joins(:variants_including_master).find_by(::Spree::Variant.table_name => { id: variant_id })
        end

        # don't use future values of deleted_at, unlike the leftover code in Solidus core
        def not_deleted
          where("#{::Spree::Product.quoted_table_name}.deleted_at IS NULL")
        end

        # use Time#beginning_of_minute to granularize availability for better cacheability
        def available(available_on = nil, _ = nil)
          joins(master: :prices).where("#{::Spree::Product.quoted_table_name}.available_on <= ?",
                                       available_on || Time.zone.now.beginning_of_minute)
        end

        # short-circuit the Searchkick class reindex method which cleans the index,
        # because we share index data with Oryx, which we do not control directly,
        # so change the default for full to false
        if ::Spree::Product.method(:searchkick_reindex).arity == -1
          # Searchkick 1.x
          def reindex(full: false, **options)
            searchkick_reindex(full: full, **options)
          end
        else
          # Searchkick 2.x
          def reindex(method_name = nil, full: false, **options)
            searchkick_reindex((method_name || :reindex), full: full, **options)
          end
        end
      end

      def self.prepended(base)
        base.belongs_to :parent, class_name: 'Spree::Product'
        base.belongs_to :group, class_name: 'Spree::Group'
        base.has_many :children, foreign_key: 'parent_id', class_name: 'Spree::Product'

        base.has_many :likes, dependent: :destroy
        base.has_many :liked_by, through: :likes, source: :user, class_name: 'Spree::User'

        base.has_many :shelf_product_memberships, dependent: :destroy
        base.has_many :shelves, through: :shelf_product_memberships

        base.belongs_to :merchant

        base.scope(:duplicates, lambda do |product|
          if product.primary_product_id
            base.where(primary_product_id: product.primary_product_id).where.not(id: product.id)
          else
            base.where("FALSE")
          end
        end)

        base.has_many :shelf_product_styles

        base.scope :most_likeable, -> { base.order(user_likes_count: :desc).where('user_likes_count > ?', 0) }
        base.scope :newest, -> { base.order(created_at: :desc).where('available_on <= ?', Time.zone.now) }
        base.scope(:most_purchasable, lambda do |timeframe|
          base.joins(:orders).where('spree_orders.completed_at >= ?', Time.zone.now - timeframe)
            .group(:id).order('COUNT(spree_orders.id) DESC')
        end)

        base.scope :all_except,   -> (product) { base.where.not(id: product) }
        base.scope :with_shelves, -> { scope_with_shelves(base) }
        base.scope(:displayable_on, lambda do |platform|
          if %w(android ios web).include? platform.try(:downcase)
            property = ::Spree::Property.find_by_name('hidden_' + platform.downcase)
            if property
              base.joins("LEFT JOIN #{::Spree::ProductProperty.table_name} AS speculative_properties ON " +
                         "speculative_properties.product_id = #{::Spree::Product.table_name}.id AND " +
                         "speculative_properties.property_id = #{property.id}").
              where("speculative_properties.id IS NULL OR LCASE(speculative_properties.value) <> 'true'")
            else
              base.where("TRUE")
            end
          else
            base.where("TRUE")
          end
        end)

        base.accepts_nested_attributes_for :master

        base.singleton_class.prepend ClassMethods

        base.extend OrderAsSpecified
      end

      def self.scope_with_shelves(base)
        base.active.includes(:shelves).where.not(TaxonShelfMembership.table_name.to_sym => { id: nil })
      end

      def featured_on_shelf?(shelf)
        shelf_product_styles.exists?(shelf: shelf)
      end

      def shelf_style_image(shelf, style = :square)
        image = shelf_product_styles.find_by(shelf: shelf).try(:image)
        image.url(style) if image
      end

      # Override of core Solidus method to avoid N+1 loading of every variant to check track_inventory attribute
      def total_on_hand
        if gift_card? # only gift cards do not track inventory, so skip calling any_variants_not_track_inventory?
          999_999
        elsif stock_items.loaded?
          # use loaded associations if present
          stock_items.map(&:count_on_hand).reduce(:+).to_i
        else
          # use sum through association
          stock_items.sum(:count_on_hand)
        end
      end

      def sold_by_hollar?
        ["Hollar"].include?(merchant.try(:name))
      end

      def base_search_data
        platform_sets = search_taxons.map do |t|
          Set.new [(t.display_android ? "android" : nil),
                   (t.display_ios ? "ios" : nil),
                   (t.display_web ? "web" : nil)]
        end
        taxon_platforms = platform_sets.present? ? platform_sets.inject(:&).to_a : %w(android ios web)

        display_platforms = taxon_platforms.reject do |platform|
          ActiveRecord::ConnectionAdapters::Column::TRUE_VALUES.include? property("hidden_#{platform}")
        end

        hollar_merchant = ::Merchant.hollar_merchants.first

        {
          id: id,
          name: name,
          description: description,
          active: available?,
          hidden: hidden?,
          deleted_at: deleted_at,
          created_at: created_at,
          updated_at: updated_at,
          available_on: available_on,
          price: price,
          skus: variants_including_master.map(&:sku),
          currency: currency,
          conversions: orders.complete.count,
          total_on_hand: total_on_hand,
          vendor_name: vendor_name,
          vendor_upc: master.vendor_upc,
          meta_title: meta_title,
          meta_description: meta_description,
          meta_keywords: meta_keywords,
          display_platforms: display_platforms,
          merchant_id: merchant_id || hollar_merchant.id
        }
      end

      def property_search_data
        ::Spree::Property.all.inject({}) do |data, prop|
          data.merge!(Hash[prop.filter_name, property(prop.name)])
        end
      end

      def taxonomy_search_data
        ::Spree::Taxonomy.all.inject({}) do |data, taxonomy|
          data.merge!(Hash[taxonomy.filter_name, taxon_by_taxonomy(taxonomy.id).map(&:id)])
        end
      end

      def taxon_search_data
        taxon_ids = []
        taxon_positions = {}

        taxons.each do |t|
          classification = ::Spree::Classification.find_by_product_id_and_taxon_id(id, t.id)
          classification.taxon.self_and_ancestors.each do |ht|
            taxon_ids << ht.id
            taxon_positions["taxon_#{ht.id}_position".to_sym] = (classification.position || 2_000_000_000)
          end
        end

        taxon_positions.merge(taxon_ids: taxon_ids)
      end

      def homepage_shelves
        @homepage_shelves ||= Shelf.displayed_on_homepage.where(display_last: false)
      end

      def shelf_search_data
        shelf_ids = []
        shelf_positions = { homepage_position: 2_000_000_000 }

        shelf_product_memberships.each do |spm|
          shelf_ids << spm.shelf_id
          shelf_positions["shelf_#{spm.shelf_id}_position".to_sym] = spm.position

          if shelf = homepage_shelves.find_by(id: spm.shelf_id)
            shelf_positions[SHELVES_INDEX_MAP[shelf.name]] = spm.position
          end
        end

        shelf_positions.merge(shelf_ids: shelf_ids)
      end

      def search_data
        base_search_data.merge(taxon_search_data).merge(shelf_search_data).
          merge(property_search_data).merge(taxonomy_search_data)
      end

      def brand_new?
        DateTime.now.utc <= available_on.utc + brand_new_period.days
      end
      alias_method :brand_new, :brand_new?

      def bundle_type_property
        # keep workaround until bundle types are fully implemented
        ActiveRecord::ConnectionAdapters::Column::TRUE_VALUES.include? property('bundle')
      end

      def regular_price_savings?
        regular_price.present? && off_price >= REGULAR_PRICE_SAVINGS_MINIMUM
      end

      def off_price
        100 - (price * 100 / regular_price)
      end

      def mobile_price
        price.to_i
      end

      # At Hollar, we prefer for the master variant not to get special treatment for displaying image,
      # as opposed to how the Spree Product class wishes to present things
      def display_image
        variant_images.first || ::Spree::Image.new
      end

      def ca_prop_65?
        ActiveRecord::ConnectionAdapters::Column::TRUE_VALUES.include? property('CA Prop 65')
      end

      def unsearchable?
        ActiveRecord::ConnectionAdapters::Column::TRUE_VALUES.include? property(:unsearchable)
      end

      def search_taxons
        # don't include root so taxonomy names are not indexed
        taxons.map(&:self_and_ancestors).flatten.uniq.reject(&:root?)
      end

      def suggestions(total, initial = [])
        suggested_products = initial

        suggested_products += taxon_based_suggestions(total)

        suggested_products = suggested_products.slice(0, total)

        if suggested_products.count < total
          suggested_products += top_of_homepage_suggestions(total - suggested_products.count)
        end

        suggested_products.reject(&:hidden)
      end

      def holiday_suggestions(total)
        holiday_taxon = ::Spree::Taxon.find_by(permalink: 'gifts/holiday-wrapping')

        if holiday_taxon.nil?
          nil
        else
          holiday_taxon.suggestions(total, [])
        end
      end

      def taxon_based_suggestions(total)
        categories, collections = taxons.partition(&:category?)
        suggested_products = []

        unless collections.empty?
          collection_suggestions = (categories.empty? ? total : (total / 3))
          suggested_products += collections.map do |c|
            c.suggestions([collection_suggestions / collections.count, 1].max, suggested_products + [self])
          end.flatten
        end

        unless categories.empty?
          departments = categories.map(&:parent).uniq

          if departments.empty?
            category_suggestions = total - suggested_products.count
          else
            category_suggestions = ((total * 2) / 3) - suggested_products.count
          end

          suggested_products += categories.map do |c|
            c.suggestions([category_suggestions / categories.count, 1].max, suggested_products + [self])
          end.flatten

          unless departments.empty?
            department_suggestions = total - suggested_products.count
            suggested_products += departments.map do |c|
              c.suggestions([department_suggestions / departments.count, 1].max, suggested_products + [self])
            end.flatten
          end
        end

        suggested_products
      end

      def top_of_homepage_suggestions(amount)
        selection = Shelf.displayed_on_homepage.first.products.limit(2 * ::Spree::Config[:admin_products_per_page])
        subquery_scope = ::Spree::Product.unscoped.from(selection, ::Spree::Product.table_name)
        subquery_scope.order("RAND()").where.not(id: id).first(amount)
      end

      def out_of_stock
        total_on_hand == 0
      end

      def bundle_unit_price
        return nil if price.nil? || master.bundle_quantity.nil?
        price / master.bundle_quantity
      end

      def stickers(shelf = nil)
        callout = nil
        caption = nil

        if total_on_hand < 1
          callout = { line1: 'Sold', line2: 'Out', background_color: '#333333' }
        elsif total_on_hand > 0 && total_on_hand < 10
          callout = { line1: 'Only', line2: "#{total_on_hand} left", background_color: '#66CCCC' }
        elsif brand_new?
          callout = { line1: 'New', line2: 'Item', background_color: '#FF5000' }
        elsif master.recent_price_drop?
          callout = { line1: 'Price', line2: 'Drop!', background_color: '#3A5EAE' }
        elsif bundle_type == 'Case'
          callout = { line1: 'Case', line2: "of #{master.bundle_quantity}", background_color: '#BD87F2' }
        elsif regular_price.present? && off_price >= 50 && !FeatureFlags[:no_original_prices].enabled?
          callout = { line1: "#{off_price.to_i}%", line2: 'Off', background_color: '#A9DD65' }
        end

        if %w(Party Product).include? bundle_type
          caption = { line1: 'BUNDLE & SAVE!', background_color: '#FF5000', icon_url: nil }
        elsif bundle_type == 'Case'
          caption = { line1: 'BUY IN BULK', background_color: '#BD87F2',
                      icon_url: ActionController::Base.helpers.path_to_asset('icon-cubes-white@3x.png', type: :image) }
        elsif shelf && featured_on_shelf?(shelf)
          caption = { line1: 'TODAY ONLY!',
                      background_color: '#F5942C',
                      icon_url: nil }

        end

        { callout: callout, caption: caption }
      end

      %w(Party Product Case).each do |bundle_type|
        define_method "bundle_type_#{bundle_type.downcase}?" do
          self.bundle_type == bundle_type
        end
      end

      private

      def brand_new_period
        ENV.fetch('BRAND_NEW_PERIOD', 3).to_i
      end
    end
  end
end

::Spree::Product.prepend ::Hollar::Spree::ProductDecorator
