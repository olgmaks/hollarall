class Spree::TaxonGroup < ActiveRecord::Base
  has_many :taxons, -> { sorted }, foreign_key: :group_id
end
