module Hollar
  module Spree
    module TaxonDecorator
      module ClassMethods
        # generate SQL-safe attribute names from a platform name
        def platform_display_attribute(app_platform)
          case app_platform.to_s.downcase
          when 'android' then :display_android
          when 'ios' then :display_ios
          when 'web' then :display_web
          end # otherwise nil
        end
      end


      def self.prepended(base)
        base.acts_as_list(column: :ingroup_position)
        base.singleton_class.prepend ClassMethods

        base.has_many :pods

        base.has_many :taxon_properties, dependent: :destroy, inverse_of: :taxon
        base.has_many :properties, through: :taxon_properties
        base.belongs_to :group, class_name: '::Spree::TaxonGroup'

        base.has_many :images, -> { order(created_at: :desc) }, as: :viewable, dependent: :destroy,
                                                                class_name: 'Spree::TaxonImage'
        base.accepts_nested_attributes_for :images

        base.has_attached_file :image, ATTACHMENT_CONFIG.merge(
          styles: {
            normal: '480x325>',
            featured: '980x440>',
            normal_retina: '720x487.5>',
            featured_retina: '1470x660>'
          },
          default_style: :normal
        )

        base.validates_attachment :image, content_type: {
          content_type: %w(image/jpg image/jpeg image/png image/gif)
        }

        base.has_attached_file :featured_image, ATTACHMENT_CONFIG.merge(
          styles: {
            normal: '480x325>',
            featured: '980x440>',
            normal_retina: '720x487.5>',
            featured_retina: '1470x660>'
          },
          default_style: :normal
        )

        base.validates_attachment :featured_image, content_type: {
          content_type: %w(image/jpg image/jpeg image/png image/gif)
        }

        base.has_attached_file :icon_image, ATTACHMENT_CONFIG.merge(
          styles: {
            small: '32x32>',
            small_retina: '64x64>',
            large: '128x128>',
            large_retina: '256x256>',
          },
          default_style: :large
        )

        base.validates_attachment :icon_image, content_type: {
          content_type: %w(image/jpg image/jpeg image/png image/gif)
        }

        base.scope :ungrouped, -> { base.where(group_id: nil) }
        base.scope :sorted,    -> { base.order(ingroup_position: :asc) }
        base.scope :published, -> { base.where(published: true) }
        base.has_many :published_children, -> { where(published: true).order(base.order_column) },
                      class_name: '::Spree::Taxon', foreign_key: 'parent_id'

        base.scope(:displayable_on, lambda do |platform|
          display_attribute = base.platform_display_attribute(platform)
          if display_attribute
            base.where(display_attribute => true)
          else
            base.where("TRUE")
          end
        end)

        base.has_many :taxon_shelf_memberships, dependent: :destroy
        base.has_many :shelves, through: :taxon_shelf_memberships

        # Add after_save callback to touch products, to account for taxon membership and
        # visibility which can affect cache and search indexing
        base.after_save -> { products.map(&:touch) }
      end

      def published_children_with_guard
        return [] unless children
        return [] if children.empty?

        children.published
      end

      def published_children_with_guard_with_platform(platform)
        taxons = published_children_with_guard
        return [] if taxons.empty?
        taxons.displayable_on(platform)
      end

      def featured?
        siblings_and_self = siblings << self
        lft == siblings_and_self.map(&:lft).sort.first
      end

      def brand_new?
        DateTime.now.utc <= created_at + brand_new_period_in_days
      end

      def main_image
        return images.first if images.any?

        NullImage.new(520, 520)
      end

      def main_image?
        images.any?
      end

      def property(property_name)
        prop = properties.find_by(name: property_name)
        prop && taxon_properties.find_by(property: prop).try(:value)
      end

      def category?
        @category_taxonomy ||= ::Spree::Taxonomy.category_taxonomy
        taxonomy == @category_taxonomy
      end

      def suggestions(amount, exclusions)
        scope = ::Spree::Product.in_taxon(self).active.reorder("RAND()")

        if exclusions
          scope = scope.where.not(id: [*exclusions].map(&:id))
        end

        scope.first(amount)
      end

      def brand_new_period_in_days
        7.days
      end

      def displayable_on?(platform)
        attribute = ::Spree::Taxon.platform_display_attribute(platform)

        if attribute
          self[attribute]
        else
          attribute == platform # true if platform was itself nil, otherwise false
        end
      end

      class NullImage
        attr_reader :attachment_width, :attachment_height

        def initialize(width, height)
          @attachment_width = width
          @attachment_height = height
        end

        def attachment(*args)
          return 'placeholder.jpg' if args.any?

          NullAttachment.new
        end

        class NullAttachment
          def url
            'placeholder.jpg'
          end
        end
      end
    end
  end
end

::Spree::Taxon.prepend ::Hollar::Spree::TaxonDecorator
