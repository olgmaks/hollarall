module Hollar
  module Spree
    module InventoryUnitDecorator
      def allow_ship?
        self.on_hand?
      end

      def adjusted_amount(qty)
        ::Spree::Money.new(variant.product.price * qty)
      end
    end
  end
end

::Spree::InventoryUnit.prepend ::Hollar::Spree::InventoryUnitDecorator
