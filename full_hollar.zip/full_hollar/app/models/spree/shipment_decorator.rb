module Hollar
  module Spree
    module ShipmentDecorator
      def self.prepended(base)
        base.state_machine.after_transition to: :canceled,
                                            do: :delete_snapfulfil_shipments

        base.has_one :merchant, through: :stock_location
        base.scope :hollar_merchant, -> { base.joins(:merchant).where('hollar_merchant_merchants.is_marketplace': false) }
        base.scope :marketplace_merchant, -> { base.joins(:merchant).where('hollar_merchant_merchants.is_marketplace': true) }
      end

      def delete_snapfulfil_shipments
        Snapfulfil::Shipment::Update.new(self).cancel
      end

      def split?
        split_at.present?
      end

      def has_short_ship_item?
        get_short_shipped_items.count >= 1
      end

      def get_short_shipped_items
        line_items.select { |i| i.adjustments.where(label: "Cancellation - Short Ship").count > 0 }
      end

      def get_short_ship_adjustments
        adjustments = []
        line_items.each do |item|
          item.adjustments.where(label: "Cancellation - Short Ship").find_each do |adjustment|
            adjustments << adjustment
          end
        end
        adjustments
      end

      def has_pending_items?
        get_pending_items.count >= 1
      end

      def get_pending_items
        line_items.select { |i| i.inventory_units.where(state: "on_hand") }
      end

      def sent_shipment_to_wms?
        sent_shipment_to_wms_at.present?
      end

      def sent_attachment_to_wms?
        sent_attachment_to_wms_at.present?
      end

      def can_transition_from_pending_to_ready?
        order.can_ship? &&
          inventory_units.all? { |iu| iu.allow_ship? || iu.canceled? } &&
          (order.paid? || !::Spree::Config[:require_payment_to_ship]) && life_cycle_completed?
      end

      # Determines the appropriate +state+ according to the following logic:
      #
      # canceled   if order is canceled
      # pending    unless order is complete and +order.payment_state+ is +paid+
      # shipped    if already shipped (ie. does not change the state)
      # ready      all other cases
      def determine_state(order)
        return 'canceled' if order.canceled?
        return 'shipped' if shipped?
        return 'pending' unless order.can_ship?
        if can_transition_from_pending_to_ready?
          'ready'
        else
          'pending'
        end
      end

      def life_cycle_completed?
        return true if order.contains_gift_card? || stock_location.dropship?

        if ENV.fetch('RATELINX_ENABLED', true) != 'false'
          sent_attachment_to_wms? && sent_shipment_to_wms? && split?
        else
          sent_shipment_to_wms?
        end
      end

      def tracking_url
        super if tracking && shipping_method
      end

      def refresh_shipment_rates
        return true if order.gift_card?

        shipments.map(&:refresh_rates)
      end
    end
  end
end

::Spree::Shipment.prepend ::Hollar::Spree::ShipmentDecorator
