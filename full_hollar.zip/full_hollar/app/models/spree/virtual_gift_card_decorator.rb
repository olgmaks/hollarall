module Hollar
  module Spree
    module VirtualGiftCardDecorator
      def self.prepended(base)
        base.scope :to_deliver, -> { base.order_completed.not_sent.where('send_email_at <= ?', Date.today) }
        base.scope :not_sent, -> { base.order_completed.where(sent_at: nil) }
        base.scope :order_completed, -> { base.joins(:order).where.not(spree_orders: { completed_at: nil }) }

        base.validate :emojis_in_message?, on: [:create, :update]
      end

      def emojis_in_message?
        return unless self.gift_message =~ EmojiParser.unicode_regex
        errors.add(:base, 'Sorry, emoji is not supported.')
      end

      def redeem(redeemer)
        return false if redeemed? || !redeemable?
        create_store_credit!(
          amount: amount,
          currency: currency,
          memo: memo,
          user: redeemer,
          created_by: redeemer,
          action_originator: self,
          category: store_credit_category,
        )
        GiftCardMailer.new(order, self).redeem_email
        update_attributes(redeemed_at: Time.now, redeemer: redeemer)
      end

      def send_email
        return if send_email_at

        send_email_immediately
      end

      def send_email_immediately
        mailer = GiftCardMailer.new(order, self)
        if hand_delivery?
          mailer.order_confirm_email
          mailer.send_to_friend_email
        end
        mailer.print_email if print_delivery?
        update_attributes!(sent_at: DateTime.now)
      end

      def print_delivery?
        purchaser_name.nil? || purchaser_name.empty?
      end

      def hand_delivery?
        !print_delivery?
      end

      def main_image_url
        line_item.variant.images.first.attachment(:main_image)
      end

      def main_image
        return nil if line_item.nil?
        line_item.variant.id
      end
    end
  end
end

::Spree::VirtualGiftCard.prepend ::Hollar::Spree::VirtualGiftCardDecorator
