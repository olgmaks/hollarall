module Spree
  # An Invite is an object stored in database used to track the status of the
  # invites sent by a user by email or sent via other channel(e.g: social
  # networks)
  class Invite < ActiveRecord::Base
    belongs_to :referer, class_name: Spree::User
    belongs_to :referee, class_name: Spree::User
    belongs_to :referer_store_credit, class_name: Spree::StoreCredit
    belongs_to :referee_store_credit, class_name: Spree::StoreCredit

    scope :subscribed, -> { where(status: :referee_subscribed) }
    scope :refered_to, ->(referee) { where(referee_id: referee.id) }
    scope :sent_to, ->(emails) { where('referee_email IN (?)', emails) }
    scope :sent_by, ->(user) { where(referer_id: user.id) }
    scope :not_converted, -> { where.not(status: :first_purchase) }
    scope :converted, -> { where(status: :first_purchase) }

    validates :referer_id, uniqueness: { scope: [:referee_email] }

    INVITE_REWARD = 2

    state_machine :status, initial: :invite_sent do
      after_transition on: :purchase, do: :store_credit_referer
      after_transition on: :purchase, do: :on_referee_converted

      event :subscribe do
        transition [:signed_from_else, :invite_sent] => :referee_subscribed
      end

      event :purchase do
        transition [:referee_subscribed] => :first_purchase
      end

      event :sign_from_elsewhere do
        transition [:invite_sent] => :signed_from_else
      end
    end

    class << self
      def credit_potential(user)
        sent_by(user).not_converted.count * INVITE_REWARD
      end

      def credit_received(user)
        sent_by(user).converted.map do |invite|
          referer_store_credit = invite.referer_store_credit
          referer_store_credit.try(:amount)
        end.sum
      end

      def sorted
        order(date_sent: :desc)
      end
    end

    def store_credit_referer
      invite_manager.credit_referer(self)
    end

    def on_referee_converted
      invite_manager.on_referee_converted(self)
    end

    def status_translation
      I18n.t("spree.invite.status.#{status}")
    end

    def credit_received
      referer_store_credit.try(:amount) || 0
    end

    def expire_at
      return unless referer_store_credit
      referer_store_credit.created_at + 12.months
    end

    private

    def invite_manager
      @_invite_manager ||= Hollar::Spree::InviteManager.new
    end
  end
end
