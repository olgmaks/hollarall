module Hollar
  module Spree
    module OrderCancellationsDecorator
      def self.prepended(base)
        base.send_cancellation_mailer = false
      end
    end
  end
end

::Spree::OrderCancellations.prepend ::Hollar::Spree::OrderCancellationsDecorator
