module Spree
  class EmailTemplate < ActiveRecord::Base
    validates :reference, :bronto_key, presence: true
  end
end
