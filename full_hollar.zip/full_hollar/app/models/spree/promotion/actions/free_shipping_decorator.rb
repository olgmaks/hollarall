module Spree
  class Promotion
    module Actions
      class FreeShipping < Spree::PromotionAction
        def perform(payload = {})
          order = payload[:order]
          promotion_code = payload[:promotion_code]

          results = order.shipments.map do |shipment|
            return false if promotion_credit_exists?(shipment) || !shipment_eligible_for_merchant?(shipment)

            shipment.adjustments.create!(
              order: shipment.order,
              amount: compute_amount(shipment),
              source: self,
              promotion_code: promotion_code,
              label: label,
            )
            true
          end
          # Did we actually end up applying any adjustments?
          # If so, then this action should be classed as 'successful'
          results.any? { |r| r == true }
        end

        private

        def shipment_eligible_for_merchant?(shipment)
          promotion_eligible_merchant_ids.include?(shipment.merchant.try(:id))
        end
      end
    end
  end
end
