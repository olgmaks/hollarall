module Spree
  class Promotion
    module Rules
      class MobileOrder < PromotionRule
        def applicable?(promotable)
          promotable.is_a?(Spree::Order)
        end

        def eligible?(order, options = {})
          @order = order
          @user = order.try(:user) || options[:user]
          @email = order.email

          eligible_order?
          eligibility_errors.empty?
        end

        private

        attr_reader :user, :email, :order

        def orders_by_email
          Spree::Order.where(email: email).complete
        end

        def eligible_order?
          if user || email
            eligibility_errors.add(:base, eligibility_error_message(:not_mobile_order)) if !order.mobile?
          else
            eligibility_errors.add(:base, eligibility_error_message(:no_user_or_email_specified))
          end
        end
      end
    end
  end
end
