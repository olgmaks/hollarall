module Spree
  class Promotion
    module Rules
      class Merchant < PromotionRule
        has_many :promotion_rule_merchants, foreign_key: :promotion_rule_id
        has_many :merchants, through: :promotion_rule_merchants

        def applicable?(promotable)
          promotable.is_a?(Spree::Order)
        end

        def eligible?(order, options = {})
          hollar_merchant = ::Merchant.hollar_merchants.first
          order_merchant_ids = order.line_items.map { |item| item.merchant.nil? ? hollar_merchant.id : item.merchant.id }.uniq
          merchant_ids.any? { |id| order_merchant_ids.include?(id) }
        end

        def merchant_ids_string
          merchant_ids.join(',')
        end

        def merchant_ids_string=(s)
          self.merchant_ids = s.to_s.split(',').map(&:strip)
        end
      end
    end
  end
end
