module Spree
  class Promotion
    module Rules
      class MobileFirstOrder < PromotionRule
        def applicable?(promotable)
          promotable.is_a?(Spree::Order)
        end

        def eligible?(order, options = {})
          unless order.mobile?
            eligibility_errors.add(:base, eligibility_error_message(:not_mobile_order))
            return false
          end

          @order = order
          @user = order.try(:user) || options[:user]
          @email = order.email

          eligible_order?
          eligibility_errors.empty?
        end

        private

        attr_reader :user, :email, :order

        def completed_mobile_orders
          if user
            user.orders.mobile.complete
          else
            ::Spree::Order.where(email: email).mobile.complete
          end
        end

        def first_order?
          completed_mobile_orders.empty?
        end

        def eligible_order?
          if !user && !email
            eligibility_errors.add(:base, eligibility_error_message(:no_user_or_email_specified))
          elsif !first_order?
            eligibility_errors.add(:base, eligibility_error_message(:not_first_order))
          end
        end
      end
    end
  end
end
