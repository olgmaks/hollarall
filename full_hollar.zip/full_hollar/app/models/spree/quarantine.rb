class Spree::Quarantine < ActiveRecord::Base
  belongs_to :order, class_name: 'Spree::Order'
end
