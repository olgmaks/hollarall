module Hollar
  module Spree
    module PromotionCodeDecorator
      # 25 characters: 36 letters plus digits minus the 11 most easily-confused
      UnambiguousCharacters = [*('A'..'Y'), *('3'..'9')] - %w(B D I O Q S 5)

      module ClassMethods
        def generate_unique_code(length = 6)
          loop do
            code = UnambiguousCharacters.sample(length).join
            redo if ::Spree::PromotionCode.where(value: code).any?
            return code
          end
        end
      end

      def self.prepended(base)
        base.has_many :generated_scheduled_promotions, through: :promotion
        base.singleton_class.prepend ClassMethods
      end
    end
  end
end

::Spree::PromotionCode.prepend ::Hollar::Spree::PromotionCodeDecorator
