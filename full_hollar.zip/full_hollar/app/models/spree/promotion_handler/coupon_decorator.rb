module Hollar
  module Spree
    module PromotionHandler
      module CouponDecorator
        def remove(adjustment)
          order.promotions.delete(promotion_for(adjustment))
          adjustment.destroy
          order.update!
        end

        def handle_present_promotion(promotion)
          super

          if successful?
            code = promotion_code

            if code
              handler = ::Spree::PromotionHandler::Coupon.new(order)

              # remove all other promotion code adjustments
              order.all_adjustments.to_a.each do |a|
                if a.promotion_code && a.promotion_code != code
                  handler.remove(a)
                end
              end
            end
          end
        end

        private

        def promotion_for(adjustment)
          ::Spree::Promotion.find(adjustment.source.promotion_id)
        end
      end
    end
  end
end

::Spree::PromotionHandler::Coupon.prepend ::Hollar::Spree::PromotionHandler::CouponDecorator
