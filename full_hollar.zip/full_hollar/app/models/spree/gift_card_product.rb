module Spree
  class GiftCardProduct < ::Spree::Product
    default_scope { where(gift_card: true) }

    def min_custom_amount
      10
    end

    def max_custom_amount
      100
    end

    def image_variants
      ([master] + variants).flatten
    end

    def designs
      list = []
      image_variants.select(&:in_stock?).sort_by(&:position).each do |variant|
        image = variant.images.first
        next if image_url(image, :product).empty?

        list << {
          id: variant.id,
          updated_at: variant.updated_at,
          thumbnail_image_url: image_url(image, :product),
          large_image_url: image_url(image, :main_image),
        }
      end
      list
    end

    def amounts
      Spree::GiftCardAmount.all
    end

    private

    def image_url(image, format)
      return '' unless image && image.attachment

      image.attachment.url(format, false)
    end
  end
end
