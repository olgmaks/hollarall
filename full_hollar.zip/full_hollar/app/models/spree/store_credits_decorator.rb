module Hollar
  module Spree
    module StoreCreditDecorator
      def self.prepended(base)
        base.scope :valid, (lambda do
          base.where('invalidated_at IS NULL AND (expires_on IS NULL OR expires_on > ?)', Time.zone.now)
        end)
        base.scope :order_by_priority, (lambda do
          base.includes(:credit_type).order('spree_store_credit_types.priority ASC, -expires_on DESC')
        end)
        base.before_create :set_expiration_date
      end

      def set_expiration_date
        if category.duration.present? && !expires_on
          self.expires_on = Time.zone.now + category.duration.to_i.days
        end
      end
    end
  end
end

::Spree::StoreCredit.prepend ::Hollar::Spree::StoreCreditDecorator
