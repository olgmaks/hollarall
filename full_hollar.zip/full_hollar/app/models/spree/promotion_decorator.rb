module Hollar
  module Spree
    module PromotionDecorator
      def self.prepended(base)
        base.has_many :generated_scheduled_promotions
      end

      def clone
        promotion_copy = dup

        promotion_rules.each do |rule|
          rule_copy = rule.dup
          rule_copy.promotion = promotion_copy
          promotion_copy.promotion_rules << rule_copy
        end

        promotion_actions.each do |action|
          action_copy = action.dup
          action_copy.promotion = promotion_copy
          promotion_copy.promotion_actions << action_copy

          if action.calculator
            calculator_copy = action.calculator.dup
            calculator_copy.calculable = action_copy
            action_copy.calculator = calculator_copy
          end
        end

        promotion_copy
      end
    end
  end
end

::Spree::Promotion.prepend ::Hollar::Spree::PromotionDecorator
