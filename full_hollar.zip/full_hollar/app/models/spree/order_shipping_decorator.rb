module Hollar
  module Spree
    module OrderShippingDecorator
      def ship(inventory_units:, stock_location:, address:, shipping_method:,
               shipped_at: Time.now, external_number: nil, tracking_number: nil, suppress_mailer: false)

        return if inventory_units.empty?

        carton = nil

        ::Spree::InventoryUnit.transaction do
          inventory_units.each(&:ship!)

          carton = ::Spree::Carton.create!(
            stock_location: stock_location,
            address: address,
            shipping_method: shipping_method,
            inventory_units: inventory_units,
            shipped_at: shipped_at,
            external_number: external_number,
            tracking: tracking_number
          )
        end

        inventory_units.map(&:shipment).uniq.each do |shipment|
          shipment.update_attributes!(tracking: tracking_number)
          if shipment.inventory_units(true).any? { |iu| iu.on_hand? || iu.shipped? }
            shipment.update_columns(state: 'shipped', shipped_at: Time.now)
          end
        end

        shipment = carton.shipments.first

        fulfill_order_stock_locations(stock_location)
        if shipment.has_short_ship_item?
          RefundShortShipJob.perform_later(@order, shipment)
        elsif stock_location.fulfillable? && !suppress_mailer
          send_shipment_emails(shipment)
        end
        @order.shipments.reload
        @order.update!

        carton
      end

      def send_shipment_emails(shipment)
        ShipmentMailer.new(shipment).shipment_shipped
      end
    end
  end
end

::Spree::OrderShipping.prepend ::Hollar::Spree::OrderShippingDecorator
