module Hollar
  module Spree
    module ShippingMethodDecorator
      def self.prepended(base)
        base.belongs_to :image, class_name: ::Spree::Image
        base.scope :gift_cards, -> { base.where(gift_card: true) }
      end

      def build_tracking_url(tracking)
        return if tracking.blank? || tracking_url.blank?

        filtered_tracking = tracking

        if code == 'FEDEX_SMART_POST'
          filtered_tracking.gsub!('USPS=', '')
        end

        tracking_url.gsub(/:tracking/, ERB::Util.url_encode(filtered_tracking))
      end

      def method_icon_url
        return unless image

        image.mini_url
      end
    end
  end
end

::Spree::ShippingMethod.prepend ::Hollar::Spree::ShippingMethodDecorator
