module Spree
  class PromotionRuleMerchant < ActiveRecord::Base
    self.table_name = 'spree_promotion_rules_merchants'

    belongs_to :promotion_rule, class_name: 'Spree::PromotionRule'
    belongs_to :merchant, class_name: '::Merchant'
  end
end
