module Hollar
  module Spree
    module CreditCardDecorator
      def email
        return nil if data.nil?
        data['email']
      end
    end
  end
end

::Spree::CreditCard.prepend ::Hollar::Spree::CreditCardDecorator
