module Hollar
  module Spree
    module AdjustmentDecorator
      def auto_applied?
        source && source.is_a?(::Spree::PromotionAction) &&
          source.try(:promotion).try(:apply_automatically)
      end

      def auto_free_shipping?
        order && order.free_shipping? &&
          label =~ /Promotion.+Free Shipping/i &&
          source_type == "Spree::PromotionAction" &&
          adjustable_type == "Spree::Shipment"
      end

      def zero_shipping_tax_adjustment?
        source_type == "Spree::TaxRate" &&
          adjustable_type == "Spree::Shipment" &&
          amount == "0.0"
      end
    end
  end
end
::Spree::Adjustment.prepend ::Hollar::Spree::AdjustmentDecorator
