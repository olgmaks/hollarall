module Hollar
  module Spree
    module TaxonomyDecorator
      def self.prepended(base)
        styles = { styles:
                     { normal:        '980x440>',
                       normal_retina: '1470x660>' },
                   default_style: :normal }

        base.has_attached_file :image, ATTACHMENT_CONFIG.merge(styles)
        base.validates_attachment :image,
                                  content_type: { content_type: ["image/jpg", "image/jpeg", "image/png", "image/gif"] }

        base.scope :published, -> { base.where(published: true) }
        base.scope(:displayable_on, lambda do |platform|
          if platform.present?
            base.distinct.joins(:taxons).merge(::Spree::Taxon.where("display_#{platform.downcase}" => true))
          else
            base.distinct
          end
        end)

        base.extend(ClassMethods)
      end

      module ClassMethods
        def category_taxonomy
          find_by_name("Category") || first
        end
      end
    end
  end
end

::Spree::Taxonomy.prepend ::Hollar::Spree::TaxonomyDecorator
