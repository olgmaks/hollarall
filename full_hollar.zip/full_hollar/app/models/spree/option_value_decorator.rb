module Hollar
  module Spree
    module OptionValueDecorator
      def self.prepended(base)
        # Solidus validates uniqueness only on name and option_type_id
        # https://github.com/solidusio/solidus/blob/master/core/app/models/spree/option_value.rb#L9

        # But we need to support different shades of e.g."Red" where the hex color will be different
        # by allowing the existence of options with the same name but differing presentation values.

        # Remove previous validations on name (including uniqueness within option_type_id scope):
        base._validators.delete(:name).each do |v|
          base._validate_callbacks.delete(base._validate_callbacks.detect { |c| c.raw_filter == v })
        end

        # add replacement validator with a scope of not only option_type_id but presentation as well
        base.validates :name, presence: true, uniqueness: { scope: [:option_type_id, :presentation] }
      end
    end
  end
end

::Spree::OptionValue.prepend ::Hollar::Spree::OptionValueDecorator
