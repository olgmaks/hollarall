module Hollar
  module Spree
    module BackendConfigurationDecorator
      def self.prepended(base)
        unless base.const_defined?("DISPLAY_TABS")
          base.const_set("DISPLAY_TABS", [:pods, :shelves, :homepage_pods])
        end
        base.send(:remove_const, :ORDER_TABS) if base.const_defined?(:ORDER_TABS)
        base.const_set("ORDER_TABS", [:orders, :quarantine_orders, :giftcard_orders, :payments,
                                      :creditcard_payments, :shipments, :credit_cards,
                                      :return_authorizations, :customer_returns, :adjustments, :customer_details])
        base.send(:remove_const, :CONFIGURATION_TABS) if base.const_defined?(:CONFIGURATION_TABS)
        base.const_set('CONFIGURATION_TABS', [:configurations, :general_settings, :tax_categories,
                                              :tax_rates, :zones, :countries, :states, :payment_methods,
                                              :shipping_methods, :shipping_categories, :stock_locations, :trackers,
                                              :refund_reasons, :reimbursement_types, :return_authorization_reasons,
                                              :minfraud])
      end
    end
  end
end

::Spree::BackendConfiguration.prepend ::Hollar::Spree::BackendConfigurationDecorator
