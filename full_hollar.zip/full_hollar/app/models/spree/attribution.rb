module Spree
  class Attribution < ActiveRecord::Base
    belongs_to :taggable, polymorphic: true
  end
end
