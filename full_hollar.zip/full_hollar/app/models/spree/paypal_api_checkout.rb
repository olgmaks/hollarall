class Spree::PaypalApiCheckout < ActiveRecord::Base
end
