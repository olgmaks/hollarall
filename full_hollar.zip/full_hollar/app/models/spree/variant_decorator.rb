module Hollar
  module Spree
    module VariantDecorator
      def self.prepended(base)
        base.acts_as_list

        # Override old Solidus handling of product reflection to prevent problems with fetching variants of
        # deleted items using includes() such as stock item and other admin pages. This is a backport of:
        # https://github.com/solidusio/solidus/commit/8090a4dce549fcb22821e6b63da48b2324d6609d
        base.belongs_to :product, -> { with_deleted }, touch: true, class_name: 'Spree::Product', inverse_of: :variants
        base.after_save :update_primary
      end

      def purchasable_amount(user)
        limit = VariantLimiter.new(user, self)
        limit.compute
      end

      def images_or_master_images
        is_product_type_size = !product.option_types.find_by(name: 'Size').nil?

        if is_master || !images.empty? || !is_product_type_size
          images
        else
          product.master.images
        end
      end

      def recent_price_drop?
        previous_price && (price < previous_price) && (price_updated_at > 5.days.ago)
      end

      def shipping_terms
        if product.merchant.is_marketplace
          "$#{format('%#.2f', shipping_price_standard.to_f)} Shipping"
        else
          'Eligible for Hollar free shipping'
        end
      end

      private

      def update_primary
        if changed.include?("vendor_upc") || changed.include?("vendor_item_number")
          PrimaryProductWorker.perform_later(self)
        end
      end

      # Use timestamp in cache key instead of explicitly clearing cache, more ETL-friendly that way.
      def in_stock_cache_key
        "variant-#{id}-in_stock-#{updated_at.to_i}"
      end

      def clear_in_stock_cache
        # Do nothing
      end
    end
  end
end

::Spree::Variant.prepend ::Hollar::Spree::VariantDecorator
