class Spree::Assessment < ActiveRecord::Base
  belongs_to :order, class_name: 'Spree::Order'
  serialize :details, JSON
end
