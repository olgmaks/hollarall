module Hollar
  module Spree
    module ImageDecorator
      def attachment_geometry(style = nil)
        geometry = Paperclip::Geometry.new(attachment_width, attachment_height)

        if style
          geometry = geometry.resize_to(attachment.styles[style].geometry)
        end

        geometry
      end
    end
  end
end

::Spree::Image.prepend ::Hollar::Spree::ImageDecorator
