module Hollar
  module Spree
    module LineItemDecorator
      def self.prepended(base)
        base.belongs_to :merchant

        base.delegate :max_product_per_order, to: :product
        base.delegate :max_product_per_customer, to: :product
        base.delegate :regular_price, to: :product
        base.delegate :group, to: :product, allow_nil: true

        base.scope :hollar_merchant, -> { base.joins(:merchant).where('hollar_merchant_merchants.is_marketplace': false) }
        base.scope :marketplace_merchant, -> { base.joins(:merchant).where('hollar_merchant_merchants.is_marketplace': true) }

        base.before_create :ensure_merchant_present
        base.has_many :comments
      end

      def ineligible?(eligible_merchant_ids)
        line_item_merchant_id = (merchant || ::Merchant.hollar_merchants.first).id
        eligible_merchant_ids ||= [::Merchant.hollar_merchants.first.id]

        property = ::Spree::Property.find_by(name: 'promo_eligible')

        product.product_properties.find_by(property: property, value: 'false') ||
          !eligible_merchant_ids.include?(line_item_merchant_id)
      end

      def variant_product_name
        return '' unless variant
        variant.product.name
      end

      def canceled_quantity
        adjustments.where(label: "Cancellation - Short Ship").count
      end

      def canceled_amount
        ::Spree::Money.new(canceled_quantity * price)
      end

      def outstanding_quantity
        quantity - canceled_quantity
      end

      def adjusted_amount
        ::Spree::Money.new(outstanding_quantity * price)
      end

      def short_shipped?
        canceled_quantity > 0
      end

      def copy_price
        self.original_price = regular_price
        super
      end

      def ensure_merchant_present
        unless merchant
          self.merchant = variant.product.merchant
        end
      end
    end
  end
end

::Spree::LineItem.prepend ::Hollar::Spree::LineItemDecorator
