module Hollar
  module Spree
    module OrderUpdateAttributesDecorator
      def assign_payments_attributes
        @order.payments.from_credit_card.checkout.each(&:invalidate!) unless @payments_attributes.empty?

        @payments_attributes.each do |payment_attributes|
          # HACK: fix android sending both state and state_id params
          address_attributes = payment_attributes['source_attributes'].try { |sa| sa['address_attributes'] }

          if address_attributes && address_attributes['state_id'] && address_attributes['state']
            address_attributes.delete('state')
          end

          ::Spree::PaymentCreate.new(order, payment_attributes, request_env: @request_env).build
        end
      end
    end
  end
end

::Spree::OrderUpdateAttributes.prepend ::Hollar::Spree::OrderUpdateAttributesDecorator
