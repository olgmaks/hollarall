module Hollar
  module Spree
    module RefundDecorator
      def perform!
        return true if transaction_id.present?

        credit_cents = ::Spree::Money.new(amount.to_f, currency: payment.currency).money.cents

        @response = process!(credit_cents)

        if paypal?
          self.transaction_id = payment.source.refund_transaction_id
        else
          self.transaction_id = @response.authorization
        end
        update_columns(transaction_id: transaction_id)
        update_order
      end

      def process!(credit_cents)
        response = case
                   when payment.payment_method.payment_profiles_supported?
                     payment.payment_method.credit(credit_cents, payment.source, payment.transaction_id,
                                                   originator: self)
                   when paypal?
                     payment.payment_method.refund(payment, (credit_cents.to_f / 100).to_s)
                   else
                     payment.payment_method.credit(credit_cents, payment.transaction_id, originator: self)
                   end

        unless response.success?
          logger.error(::Spree.t(:gateway_error) + "  #{response.to_yaml}")
          text = response.params['message'] || response.params['response_reason_text'] || response.message
          raise ::Spree::Core::GatewayError, text
        end

        response
      rescue ::ActiveMerchant::ConnectionError => e
        logger.error(::Spree.t(:gateway_error) + "  #{e.inspect}")
        raise ::Spree::Core::GatewayError, ::Spree.t(:unable_to_connect_to_gateway)
      end

      private

      def paypal?
        payment.payment_method.type == 'Spree::Gateway::PayPalExpress'
      end
    end
  end
end

::Spree::Refund.prepend ::Hollar::Spree::RefundDecorator
