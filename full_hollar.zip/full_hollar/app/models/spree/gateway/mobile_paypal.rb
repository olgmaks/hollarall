require 'paypal-sdk-merchant'
module Spree
  class Gateway::MobilePaypal < Gateway

    def name
      "Mobile Paypal"
    end

    def method_type
      :mobile_paypal
    end

    def supports?(source)
      true
    end

    def provider
    end

    def auto_capture
      true
    end

    def provider_class
    end

    def cancel response_code
      payment = ::Spree::Payment.where(response_code: response_code).first
      refund(payment, payment.amount)
    end

    def refund(payment, amount)
      source = payment.source
      capture = ::PayPal::SDK::REST::DataTypes::Capture.find(source.transaction_id)
      refund  = capture.refund({
                                 :amount => {
                                   :currency => payment.currency,
                                   :total => amount }
                               })
      source.update_column(:refunded_at, DateTime.now)
      source.update_column(:refund_transaction_id, refund.try(:id))

      if refund.success?
        logger.info "Refund[#{refund.id}] Success"
      else
        logger.error "Unable to Refund"
        logger.error refund.error.inspect
      end
      refund
    rescue ::PayPal::SDK::Core::Exceptions::ResourceNotFound => err
      logger.error "Authorization Not Found"
    end

    def purchase(amount, checkout, gateway_options={})
      decimal_amount = amount / 100.0
      @checkout = checkout
      authorization_id = checkout.authorization_id
      PaypalPayment::Capture.new(self, authorization_id, decimal_amount.to_s).call
    end

    def on_paypal_payment_captured capture_id
      capture_id = capture_id  #TO COMPLETE
      checkout.update_column(:transaction_id, capture_id)
      Class.new do
        def success?; true; end
        def authorization; nil; end
      end.new
    end

    def on_paypal_payment_not_captured error
      {error: error}.to_json
    end

    private

    attr_accessor :checkout
  end
end
