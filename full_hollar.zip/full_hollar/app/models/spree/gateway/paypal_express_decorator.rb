module Hollar
  module Spree
    module Gateway
      module PayPalExpressDecorator
        def cancel(response_code)
          payment = ::Spree::Payment.find_by(response_code: response_code)
          refund(payment, payment.amount)
        end
      end
    end
  end
end

::Spree::Gateway::PayPalExpress.prepend ::Hollar::Spree::Gateway::PayPalExpressDecorator
