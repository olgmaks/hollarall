module Spree
  class Article < ActiveRecord::Base
    acts_as_list
    default_scope -> { order(position: :asc) }

    styles = {
      normal: '480x325>',
      featured: '980x440>',
      normal_retina: '720x487.5>',
      featured_retina: '1470x660>'
    }

    has_attached_file    :logo, ATTACHMENT_CONFIG.merge(styles)
    validates_attachment :logo, content_type: {
      content_type: %w(image/jpg image/jpeg image/png image/gif)
    }
  end
end
