module Hollar
  module Spree
    module PaymentMethod
      module StoreCreditDecorator
        def cancel(auth_code)
          # workaround for bug in solidus when canceling orders with a store credit payment
          success = super(auth_code)
          ActiveMerchant::Billing::Response.new(success, '', {}, {})
        end
      end
    end
  end
end

::Spree::PaymentMethod::StoreCredit.prepend ::Hollar::Spree::PaymentMethod::StoreCreditDecorator
