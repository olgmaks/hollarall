module Hollar
  module Spree
    module StockLocationDecorator
      def self.prepended(base)
        base.belongs_to :merchant
      end
    end
  end
end

::Spree::StockLocation.prepend ::Hollar::Spree::StockLocationDecorator
