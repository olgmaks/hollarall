module Spree
  class OrderMailerAttributes
    def initialize(order, carton, shipment = nil)
      @order = order
      @carton = carton
      @shipment = shipment if shipment.present?
      @attrs = {}
    end

    def build_attributes
      build_message_tags
      build_line_item_tags
      build_pending_line_item_tags
      build_canceled_line_item_tags
      build_refund_tags
      build_shipping_tags
      build_payment_tags
      build_address_tags('bill')
      build_address_tags('ship')
      attrs
    end

    private

    attr_reader :order, :attrs, :carton

    def build_message_tags
      attrs[:orderIncrementId] = order.number
      attrs[:orderStoreCreditTotals] = order.display_total_applicable_store_credit.to_html
      if order.has_short_ship_item?
        attrs[:orderSubTotals] = currency_for(order.adjusted_item_total)
        attrs[:orderTaxTotals] = currency_for(order.adjusted_tax_total)
      else
        attrs[:orderSubTotals] = currency_for(order.item_total)
        attrs[:orderTaxTotals] = currency_for(order.tax_total)
      end
      attrs[:orderTotals] = order.display_order_total_after_store_credit.to_html
      attrs[:orderShippingDescription] = order.shipments.first.try(:shipping_method).try(:name)
      if carton.is_a?(Spree::Carton)
        attrs[:orderShippingDescription] = carton.shipping_method.try(:name)
        attrs[:shipmentTracking] = carton.tracking
        attrs[:shipmentTrackingUrl] = carton.tracking_url
      end
    end

    def build_line_item_tags
      if @shipment
        @shipment.inventory_units.where(state: 'shipped').group(:variant_id).select('*, count(id) as quantity').
          each_with_index do |unit, idx|
          uncanceled_qty = unit.quantity
          attrs[:"productImgUrl_#{idx}"] = ActionController::Base.helpers.asset_path('placeholder.jpg')
          attrs[:"productImgUrl_#{idx}"] = unit.variant.images.first.attachment.url(:small) if unit.variant.images.any?
          attrs[:"productName_#{idx}"] = unit.variant.name
          attrs[:"productSku_#{idx}"] = unit.variant.sku
          attrs[:"productQty_#{idx}"] = uncanceled_qty
          attrs[:"productPriceExclTax_#{idx}"] = currency_for(unit.line_item.price)
        end
      else
        order.line_items.select { |it| it.quantity - it.adjustments.where(label: 'Cancellation - Short Ship').count > 0 }.
          each_with_index do |item, idx|
          uncanceled_qty = item.quantity - item.adjustments.where(label: "Cancellation - Short Ship").count
          attrs[:"productImgUrl_#{idx}"] = ActionController::Base.helpers.asset_path('placeholder.jpg')
          attrs[:"productImgUrl_#{idx}"] = item.variant.images.first.attachment.url(:small) if item.variant.images.any?
          attrs[:"productName_#{idx}"] = item.variant.name
          attrs[:"productSku_#{idx}"] = item.variant.sku
          attrs[:"productQty_#{idx}"] = uncanceled_qty
          attrs[:"productPriceExclTax_#{idx}"] = currency_for(item.price)
        end
      end
    end

    def build_pending_line_item_tags
      order.inventory_units.where(state: "on_hand").group_by(&:variant).each_with_index do |group, idx|
        variant = group.first
        quantity = group.second.count
        attrs[:"pending_productImgUrl_#{idx}"] = ActionController::Base.helpers.asset_path('placeholder.jpg')
        attrs[:"pending_productImgUrl_#{idx}"] = variant.images.first.attachment.url(:small) if variant.images.any?
        attrs[:"pending_productName_#{idx}"] = variant.name
        attrs[:"pending_productSku_#{idx}"] = variant.sku
        attrs[:"pending_productQty_#{idx}"] = quantity
      end
    end

    def build_canceled_line_item_tags
      if order.get_short_shipped_items.count > 0
        order.get_short_shipped_items.each_with_index do |item, idx|
          attrs[:"canceledProductImgUrl_#{idx}"] = ActionController::Base.helpers.asset_path('placeholder.jpg')
          if item.variant.images.any?
            attrs[:"canceledProductImgUrl_#{idx}"] = item.variant.images.first.attachment.url(:small)
          end
          attrs[:"canceledProductName_#{idx}"] = item.variant.name
          attrs[:"canceledProductSku_#{idx}"] = item.variant.sku
          attrs[:"canceledProductQty_#{idx}"] = item.adjustments.where(label: "Cancellation - Short Ship").count
          # 'canc' vs 'canceled' because of 25 char limit
          attrs[:"cancProductPriceExclTax_#{idx}"] = currency_for(item.price)
        end
      end
    end

    def build_refund_tags
      attrs[:orderRefundTotal] = currency_for(order.refund_total)
    end

    def build_shipping_tags
      attrs[:orderShippingTotals] = "Free!" and return if free_shipping?
      attrs[:orderShippingTotals] = currency_for(order.shipment_total)
    end

    def build_payment_tags
      payments = []

      @order.payments.valid.not_void.each do |payment|
        if payment.source.is_a?(::Spree::CreditCard)
          if payment.source.cc_type == 'paypal'
            payments << "PayPal #{payment.source.try(:display_number)}"
          else
            payments << "#{payment.source.cc_type} Ending in #{payment.source.last_digits}"
          end
        elsif payment.payment_method.is_a?(::Spree::Gateway::PayPalExpress) ||
              payment.payment_method.is_a?(::Spree::Gateway::MobilePaypal)
          payments << 'PayPal'
        else
          payments << payment.payment_method.name
        end
      end

      attrs[:paymentInfo] = payments.join(', ')
    end

    def build_address_tags(type)
      attrs[:"#{type}Name"] = "#{address_for(type).firstname} #{address_for(type).lastname}"
      address_street_block(type)
      address_city_block(type)
      attrs[:"#{type}Country"] = address_for(type).country.name
    end

    def address_street_block(type)
      attrs[:"#{type}StreetAddress"] = address_for(type).address1
      return unless address_for(type).address2
      attrs[:"#{type}StreetAddress"] += "\n #{address_for(type).address2}"
    end

    def address_city_block(type)
      attrs[:"#{type}CityLine"] = "#{address_for(type).city}, #{address_for(type).zipcode}"
      return unless address_for(type).state
      attrs[:"#{type}CityLine"] = "#{address_for(type).city}, #{address_for(type).state.name},
        #{address_for(type).zipcode}"
    end

    def address_for(type)
      order.send(:"#{type}_address")
    end

    def payment_source
      order.payments.valid.first.try(:source)
    end

    def free_shipping?
      order.promotions.map(&:name).any? { |val| val =~ /Free Shipping/i }
    end

    def credit_card?
      payment_source.is_a?(::Spree::CreditCard)
    end

    def paypal?
      payment_source.try(:token) || payment_source.try(:authorization_id)
    end

    def currency_for(number)
      ActionController::Base.helpers.number_to_currency(number)
    end
  end
end
