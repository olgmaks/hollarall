module Hollar
  module Spree
    module PaymentMethodDecorator
      def self.prepended(base)
        base.scope :mobile_payment_method, -> { base.where(type: 'Spree::Gateway::MobilePaypal') }
        base.scope :limit_platform, -> (platform) { base.where("limit_platform IS NULL OR (limit_platform IS NOT NULL AND limit_platform = ?)", platform) }
      end
    end
  end
end

::Spree::PaymentMethod.prepend ::Hollar::Spree::PaymentMethodDecorator
