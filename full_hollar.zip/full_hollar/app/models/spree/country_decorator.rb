module Hollar
  module Spree
    module CountryDecorator
      def self.prepended(base)
        base.whitelisted_ransackable_attributes = %w[iso]
      end
    end
  end
end

::Spree::Country.prepend ::Hollar::Spree::CountryDecorator
