module Spree
  class GiftCardAmount

    def self.all
      [
        { id: 1, amount_label: '$10', amount: 10 },
        { id: 2, amount_label: '$25', amount: 25 },
        { id: 3, amount_label: '$50', amount: 50 },
        { id: 4, amount_label: '$100', amount: 100 }
      ]
    end

    def self.find_by_id id
      all.select { |amount| amount.id == id }
    end

  end
end
