module Hollar
  module Spree
    module PriceDecorator
      def self.prepended(base)
        base.before_save :update_price_updated_at
      end

      private

      def update_price_updated_at
        if is_default && amount_changed? && variant
          variant.update_columns(previous_price: changes['amount'][0], price_updated_at: Time.zone.now)
        end
      end
    end
  end
end

::Spree::Price.prepend ::Hollar::Spree::PriceDecorator
