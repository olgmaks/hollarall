module Hollar
  module Spree
    module ClassificationDecorator
      def self.prepended(base)
        # Add touch callback to products association to account for taxon membership and
        # visibility which can affect cache and search indexing
        base.belongs_to :product, class_name: "Spree::Product", inverse_of: :classifications, touch: true
        base.after_commit :reindex_product
      end

      def reindex_product
        product.reindex_async if Searchkick.callbacks?
      end
    end
  end
end

::Spree::Classification.prepend ::Hollar::Spree::ClassificationDecorator
