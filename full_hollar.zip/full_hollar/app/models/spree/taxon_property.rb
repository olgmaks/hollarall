module Spree
  class TaxonProperty < Spree::Base
    belongs_to :taxon, touch: true, class_name: 'Spree::Taxon', inverse_of: :taxon_properties
    belongs_to :property, class_name: 'Spree::Property', inverse_of: :taxon_properties

    self.whitelisted_ransackable_attributes = ['value']
  end
end
