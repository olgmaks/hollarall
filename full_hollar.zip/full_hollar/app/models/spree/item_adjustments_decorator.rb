class NullItem
  def persisted?
    false
  end
end

module Hollar
  module Spree
    module ItemAdjustmentsDecorator
      def update
        @item = NullItem.new if item.nil?
        super
      end
    end
  end
end

::Spree::ItemAdjustments.prepend ::Hollar::Spree::ItemAdjustmentsDecorator
