module Hollar
  module Spree
    module AddressDecorator
      def full_name
        "#{self.firstname} #{self.lastname}".strip
      end
    end
  end
end
::Spree::Address.prepend ::Hollar::Spree::AddressDecorator
