module Hollar
  module Spree
    module OrderUpdaterDecorator
      def recalculate_adjustments
        adjustables = all_adjustments.includes(:adjustable).map(&:adjustable).uniq.compact
        adjustables.each { |adjustable| ::Spree::ItemAdjustments.new(adjustable).update }
      end
    end
  end
end

::Spree::OrderUpdater.prepend ::Hollar::Spree::OrderUpdaterDecorator
