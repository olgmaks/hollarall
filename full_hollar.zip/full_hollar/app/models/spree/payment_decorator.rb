module Hollar
  module Spree
    module PaymentDecorator
      def self.prepended(base)
        base.alias_attribute :identifier, :number
        base.scope :paypal_express, -> { base.where(source_type: 'Spree::PaypalExpressCheckout') }
        base.scope :paypal_mobile,  -> { base.where(source_type: 'Spree::PaypalApiCheckout') }
        base.scope :not_void, -> { base.where.not(state: 'void') }
        base.scope :from_user, -> { base.where(source_type: ['Spree::CreditCard',
                                                             'Spree::PaypalExpressCheckout',
                                                             'Spree::PaypalApiCheckout']) }
      end
    end
  end
end

::Spree::Payment.prepend ::Hollar::Spree::PaymentDecorator
