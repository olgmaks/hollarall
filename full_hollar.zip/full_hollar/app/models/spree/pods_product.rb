module Spree
  class PodsProduct < ActiveRecord::Base
    belongs_to :product, class_name: 'Spree::Product'
    belongs_to :pod, class_name: 'Spree::Pod'
  end
end
