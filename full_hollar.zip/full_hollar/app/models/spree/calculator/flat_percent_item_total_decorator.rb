module Spree
  module Calculator::FlatPercentItemTotalDecorator
    def compute(object)
      order_amount = object.line_items.reject { |i| i.ineligible?(promotion_eligible_merchant_ids) }.
                     inject(0.0) { |sum, li| sum + li.amount }

      computed_amount = (order_amount * preferred_flat_percent / 100).round(2)

      # We don't want to cause the promotion adjustments to push the order into a negative total.
      [computed_amount, object.amount].map(&:abs).min
    end
  end
end

::Spree::Calculator::FlatPercentItemTotal.prepend ::Spree::Calculator::FlatPercentItemTotalDecorator
