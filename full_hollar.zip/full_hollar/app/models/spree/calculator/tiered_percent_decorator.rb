module Spree
  class Calculator
    module TieredPercentDecorator
      include ::Ineligible

      def compute(object)
        return 0.0 if ineligible_line_item?(object, promotion_eligible_merchant_ids)

        order = object.is_a?(Order) ? object : object.order
        _base, percent = preferred_tiers.sort.reverse.detect { |b, _| order.item_total >= b }
        order_amount = object.line_items.reject { |i| i.ineligible?(promotion_eligible_merchant_ids) }.
                       inject(0.0) { |sum, li| sum + li.amount }

        (order_amount * (percent || preferred_base_percent) / 100).round(2)
      end
    end
  end
end

::Spree::Calculator::TieredPercent.prepend ::Spree::Calculator::TieredPercentDecorator
