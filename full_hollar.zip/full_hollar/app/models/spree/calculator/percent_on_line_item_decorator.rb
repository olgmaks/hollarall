module Spree
  module Calculator::PercentOnLineItemDecorator
    include ::Ineligible

    def compute(object)
      ineligible_line_item?(object, promotion_eligible_merchant_ids) ? 0 : discount(object)
    end

    private

    def discount(object)
      (object.amount * preferred_percent) / 100
    end
  end
end

::Spree::Calculator::PercentOnLineItem.prepend ::Spree::Calculator::PercentOnLineItemDecorator
