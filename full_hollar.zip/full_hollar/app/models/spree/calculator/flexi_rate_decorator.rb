module Spree
  class Calculator
    module FlexiRateDecorator
      include ::Ineligible

      def compute(object)
        sum = 0
        max = preferred_max_items.to_i
        ineligible_count = 0

        return sum if ineligible_line_item?(object, promotion_eligible_merchant_ids)

        if object.is_a?(::Spree::Order)
          ineligible_count = object.line_items.select { |i| i.ineligible?(promotion_eligible_merchant_ids) }.
                             sum(&:quantity)
        end
        items_count = object.quantity - ineligible_count.to_i

        items_count.times do |i|
          if i.zero?
            sum += preferred_first_item.to_f
          elsif ((max > 0) && (i <= (max - 1))) || max.zero?
            sum += preferred_additional_item.to_f
          end
        end

        sum
      end
    end
  end
end

::Spree::Calculator::FlexiRate.prepend ::Spree::Calculator::FlexiRateDecorator
