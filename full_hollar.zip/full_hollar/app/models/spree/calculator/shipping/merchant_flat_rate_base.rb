require_dependency 'spree/shipping_calculator'

module Spree
  module Calculator::Shipping
    class MerchantFlatRateBase < ShippingCalculator
      preference :currency, :string, default: ->{ Spree::Config[:currency] }

      def compute_package(package)
        package.contents.map { |i| item_rate(i) || 0}.sum
      end

      def item_rate(content_item)
        0
      end
    end
  end
end
