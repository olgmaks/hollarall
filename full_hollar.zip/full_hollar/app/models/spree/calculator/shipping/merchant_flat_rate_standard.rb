module Spree
  module Calculator::Shipping
    class MerchantFlatRateStandard < MerchantFlatRateBase
      def self.description
        "Merchant Flat Rate - Standard"
      end

      def item_rate(content_item)
        content_item.variant.shipping_price_standard
      end
    end
  end
end
