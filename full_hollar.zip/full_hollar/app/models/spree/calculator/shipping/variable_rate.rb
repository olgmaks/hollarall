require_dependency 'spree/calculator'

module Spree
  class Calculator::Shipping::VariableRate < ::Spree::Calculator::Shipping::PriceSack
  end
end
