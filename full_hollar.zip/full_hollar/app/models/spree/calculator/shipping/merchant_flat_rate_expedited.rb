module Spree
  module Calculator::Shipping
    class MerchantFlatRateExpedited < MerchantFlatRateBase
      def self.description
        "Merchant Flat Rate - Expedited"
      end

      def item_rate(content_item)
        content_item.variant.shipping_price_expedited
      end
    end
  end
end
