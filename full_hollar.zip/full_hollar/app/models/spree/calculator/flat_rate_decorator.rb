module Spree
  class Calculator
    module FlatRateDecorator
      include ::Ineligible

      def compute(object)
        merchant_ids = promotion_eligible_merchant_ids
        order_amount = 0.0

        return 0.0 if !same_currency?(object) || ineligible_line_item?(object, merchant_ids)

        if object.is_a?(::Spree::Order)
          order_amount = object.line_items.reject { |i| i.ineligible?(merchant_ids) }.
                         inject(0.0) { |sum, li| sum + li.amount }
        end

        [preferred_amount, order_amount].compact.map(&:abs).min
      end

      private

      def same_currency?(object)
        object && preferred_currency.casecmp(object.currency).zero?
      end
    end
  end
end

::Spree::Calculator::FlatRate.prepend ::Spree::Calculator::FlatRateDecorator
