module Spree
  class Calculator
    class HighestPricedItemPercent < ::Spree::Calculator
      preference :percent, :decimal, default: 0
      preference :exclude_bundles, :boolean, default: false

      def self.description
        'Highest Priced Item Percent'
      end

      def compute(object)
        # because order.line_items has an existing order scope
        line_items = ::Spree::LineItem.joins(:product).where(order: object)
        line_items = line_items.where('spree_products.bundle_type IS NULL') if preferred_exclude_bundles
        line_items = line_items.order(price: :desc).reject { |i| i.ineligible?(promotion_eligible_merchant_ids) }

        if line_items.any?
          highest_price = line_items.first.price
          (highest_price * preferred_percent / 100).round(2)
        else
          0
        end
      end
    end
  end
end
