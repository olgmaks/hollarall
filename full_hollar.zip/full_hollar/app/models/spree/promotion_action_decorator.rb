module Hollar
  module Spree
    module PromotionActionDecorator
      def promotion_eligible_merchant_ids
        merchant_rule = promotion.rules.find_by(type: 'Spree::Promotion::Rules::Merchant')

        if merchant_rule && merchant_rule.merchant_ids
          return merchant_rule.merchant_ids
        end

        hollar_merchants = ::Merchant.hollar_merchants
        hollar_merchants.map(&:id)
      end
    end
  end
end

::Spree::PromotionAction.prepend ::Hollar::Spree::PromotionActionDecorator
