module Hollar
  module Spree
    module OrderDecorator
      SHIPPING_ADDRESS_STATE_BLACKLIST = %w(AA AE AK AP HI PR).freeze
      HOLLAR_STANDARD_SHIPPING_RATE = 4.95

      module ClassMethods
        def minimum_checkout_amount
          10.0
        end

        def hollar_first_order_free_shipping_amount
          ::Hollar::Config.hollar_first_order_free_shipping_amount.to_f
        end

        def hollar_everyday_free_shipping_amount
          ::Hollar::Config.hollar_everyday_free_shipping_amount.to_f
        end

        [:minimum_checkout_amount, :hollar_first_order_free_shipping_amount,
         :hollar_everyday_free_shipping_amount].each do |method_name|
          define_method("display_#{method_name}") do
            ::Spree::Money.new(minimum_checkout_amount, no_cents_if_whole: true)
          end
        end
      end

      def self.prepended(base)
        base.state_machine.after_transition to: :complete,
                                            do: :assess
        base.state_machine.after_transition to: :complete,
                                            do: :update_invites
        base.state_machine.after_transition to: :complete,
                                            do: :activate_gift_cards
        base.state_machine.after_transition to: :delivery, do: :advance_shipping_step

        base.has_many :attributions, -> { order(created_at: :desc) }, as: :taggable

        base.has_one :quarantine, class_name: 'Spree::Quarantine'
        base.has_one :assessment, class_name: 'Spree::Assessment'

        base.has_many :comments, class_name:  'Spree::Comment'
        base.money_methods :saved_amount, :refund_total,
                           :adjusted_order_total_after_store_credit, :adjusted_tax_total, :adjusted_item_total,
                           :store_credit_total, :hollar_item_total, :hollar_shipping_total,
                           :hollar_promo_adjustments_total, :hollar_total, :marketplace_item_total,
                           :marketplace_shipping_total, :marketplace_total, :subtotal,
                           free_shipping_required_item_total: { no_cents_if_whole: true },
                           amount_remaining_for_free_shipping: { no_cents_if_whole: true },
                           amount_remaining_for_checkout: { no_cents_if_whole: true }
        base.singleton_class.prepend ClassMethods
        base.scope :treasurable, ->(date) { base.where('completed_at >= ? and treasurable = ?', date, true) }
        base.scope :mobile, -> { base.where(channel: %w[ios mobile android]) }
        base.scope :parked, -> { base.where(parked: true) }
        base.scope :risky, -> { base.joins(:quarantine) }
        base.scope :not_risky, -> { base.where.not(id: ::Spree::Quarantine.pluck(:order_id)) }
        base.scope :giftcards, -> { base.joins(:line_items).joins(:products).where('spree_products.gift_card = true') }
        base.scope :not_giftcards, -> { base.where(gift_card: false) }
        base.whitelisted_ransackable_attributes =
          %w[completed_at created_at email number state payment_state shipment_state total gift_code]

        base.validate :shipping_state_supported
      end

      def risky?
        quarantine
      end

      def deliver_order_confirmation_email
        DelayedSend.perform_later(email,
                                  ::EmailTemplateSelector.select_template('order_received'),
                                  mailer_attributes)
        update_column(:confirmation_delivered, true)
      end

      def available_payment_methods
        # workaround Android app trying to use payment methods limited to "web"
        @available_payment_methods ||= (
          ::Spree::PaymentMethod.available(:front_end, store: store) +
          ::Spree::PaymentMethod.available(:both, store: store)
        ).uniq - ::Spree::PaymentMethod.limit_platform('web')
      end

      def release(callee:)
        quarantine.destroy
        virtual_gift_card.update(redeemable: true) if contains_gift_card?

        create_assessment_comment(customer_service: callee)

        cartonize_shipments
      end

      def create_cancellation_comment(customer_service:, items:)
        text = items.group_by(&:variant).map do |variant, inv_units|
          humanized_options = "(#{variant.options_text})" unless variant.option_values.empty?
          humanized_sku     = "SKU: #{variant.sku}" if variant.sku.present?

          "#{variant.name} x #{inv_units.size} #{humanized_options} #{humanized_sku}"
        end

        comments.create(
          user:             user,
          customer_service: customer_service,
          comment_type:     'Customer Service',
          channel:          'Customer Service',
          reason:           'Other',
          detailed_reason:  'Other',
          text:             "Cancel Inventory:\n #{text.join("\n")}"
        )
      end

      def create_assessment_comment(quarantine: false, customer_service:)
        comments.create(
          customer_service: customer_service,
          comment_type:     'Secondary',
          channel:          'Management',
          reason:           'Fraud Assessment',
          detailed_reason:  "Quarantine #{'Release' unless quarantine}",
          text:             "Order has been #{quarantine ? 'quarantined' : 'released'}"
        )
      end

      def available_payment_methods_for_web
        payment_methods = (
          ::Spree::PaymentMethod.available(:front_end, store: store) +
          ::Spree::PaymentMethod.available(:both, store: store)
        )

        (::Spree::PaymentMethod.limit_platform('web') & payment_methods) -
          ::Spree::PaymentMethod.mobile_payment_method
      end

      def contains_hidden_products?
        treasurable || products.any?(&:hidden)
      end

      def temporary_address
        false
      end

      def assess
        return cartonize_shipments unless ::Hollar::Config.minfraud_enabled

        Rails.logger.info("Calling an assessment worker with order number: #{number}")

        assessment_params = {
          order_id: id,
          ip_address: ::Hollar::Config.minfraud_use_ip ? ::Hollar::Config.minfraud_ip_address : last_ip_address
        }
        AssessmentsWorker.perform_later(assessment_params)
      end

      def cartonize_shipments
        return true if contains_gift_card?

        Rails.logger.info("Calling the shipment factory worker with order number #{number}")
        ShipmentFactoryWorker.perform_later(id)
      end

      def refund_total
        refunds = payments.flat_map(&:refunds).sum(&:amount)
        credits = payments.where('amount < 0').sum(:amount).abs
        refunds + credits
      end

      def saved_amount
        total_before_discounts = 0

        line_items.each do |item|
          if item.product.regular_price.present?
            total_before_discounts += item.product.regular_price * item.quantity
          else
            total_before_discounts += item.product.price * item.quantity
          end
        end

        total_savings = total_before_discounts - item_total
        total_savings > 0 ? ::Spree::Money.new(total_savings, no_cents_if_whole: true) : ""
      end

      def persist_user_address!
        super

        if bill_address && bill_address.attributes
          user = self.user
          return unless user

          attributes = bill_address.attributes
          attributes.delete('id')
          user.build_bill_address(attributes)
          user.save
        end
      end

      def assign_default_credit_card
        return if payments.from_user.count > 0 || user.nil?

        previous_order = user.orders.complete.not_giftcards.last
        if previous_order
          latest_default_payment = previous_order.payments.completed.from_user.first

          # Only use credit cards (i.e. not legacy PayPal methods)
          if latest_default_payment && latest_default_payment.source.class == ::Spree::CreditCard
            newest_credit_card = find_newest_payment_method_credit_card(latest_default_payment)
            if newest_credit_card
              payments.create!(payment_method_id: newest_credit_card.payment_method_id,
                               source: newest_credit_card)
              self.bill_address ||= newest_credit_card.address || user.bill_address
            else
              payments.create!(payment_method_id: latest_default_payment.payment_method_id,
                               source: latest_default_payment.source)
              self.bill_address ||= latest_default_payment.source.address || user.bill_address
            end
          end
        end
      end

      def find_newest_payment_method_credit_card(legacy_payment)
        newest_payment_method = ::Spree::PaymentMethod.find_by(type: 'Solidus::Gateway::BraintreeGateway')
        return if newest_payment_method.nil?

        legacy_credit_card = legacy_payment.source
        # If it's already a credit card using the solidus gateway, we return it.
        return legacy_credit_card if legacy_credit_card.class == ::Spree::CreditCard &&
                                     legacy_credit_card.payment_method == newest_payment_method

        user.credit_cards.find_by(month: legacy_credit_card.month,
                                  year: legacy_credit_card.year,
                                  last_digits: legacy_credit_card.last_digits,
                                  payment_method_id: newest_payment_method.id)
      end

      def free_shipping?
        return true if hollar_item_total >= free_shipping_required_item_total
      end

      def free_shipping_required_item_total
        if user && user.first_hollar_item_purchase?(self)
          BigDecimal(self.class.hollar_first_order_free_shipping_amount, 12)
        else
          BigDecimal(self.class.hollar_everyday_free_shipping_amount, 12)
        end
      end

      def amount_remaining_for_free_shipping
        amount = free_shipping_required_item_total - hollar_item_total
        BigDecimal([0, amount].max)
      end

      def minimum_amount?
        total >= self.class.minimum_checkout_amount
      end

      def amount_remaining_for_checkout
        amount = BigDecimal(self.class.minimum_checkout_amount, 12) - item_total
        BigDecimal([0, amount].max)
      end

      def mobile?
        channel.downcase.match(/(ios|mobile|android)/)
      end

      def outstanding_balance
        # If reimbursement has happened add it back to total to prevent balance_due payment state
        # See: https://github.com/spree/spree/issues/6229
        if reimbursements.any?
          adjusted_payment_total = payment_total + refund_total
        else
          # If direct refunds being done,  payment_total already includes the refund total
          adjusted_payment_total = payment_total
        end

        if state == 'canceled'
          -1 * adjusted_payment_total
        else
          total - adjusted_payment_total
        end
      end

      def has_picked_snapfulfil_shipment?
        snap_shipments = []
        shipments.each do |shipment|
          snap_shipments << Snapfulfil::Shipment::Retrieve.new.by_id(shipment.number).try(:first)
        end
        statuses = snap_shipments.compact.map { |sp| sp["Stage"] }
        picked_statuses = statuses.select { |status| status.to_i >= 20 }
        return true if picked_statuses.any?
        false
      end

      def has_pending_items?
        get_pending_items.count >= 1
      end

      def get_pending_items
        inventory_units.where(state: "on_hand")
      end

      def send_short_ship_refund_email(shipment)
        mail = ::Spree::OrderMailerAttributes.new(self, nil, shipment).build_attributes
        if has_pending_items?
          DelayedSend.perform_later(email,
                                    ::EmailTemplateSelector.
                                    select_template(external_key['order_shipped_with_short_and_backorder']),
                                    mail)
        else
          DelayedSend.perform_later(email,
                                    ::EmailTemplateSelector.select_template(external_key['order_shipped_with_short']),
                                    mail)
        end
      end

      def get_short_ship_adjustments
        adjustments = []
        line_items.each do |item|
          item.adjustments.where(label: "Cancellation - Short Ship").find_each do |adjustment|
            adjustments << adjustment
          end
        end
        adjustments
      end

      def has_short_ship_item?
        get_short_shipped_items.count >= 1
      end

      def get_short_shipped_items
        line_items.select { |i| i.adjustments.where(label: "Cancellation - Short Ship").count > 0 }
      end

      def adjusted_order_total_after_store_credit
        order_total_after_store_credit > 0 ? order_total_after_store_credit : "$0"
      end

      def adjusted_tax_total
        total = tax_total
        get_short_shipped_items.each do |i|
          total -= i.adjustments.where(label: "Cancellation - Short Ship").count *
                   (i.included_tax_total * percentage_of_line_item(i) +
                    i.additional_tax_total * percentage_of_line_item(i))
        end
        total
      end

      def adjusted_item_total
        items_subtotal = line_items.sum('price * quantity')
        get_short_shipped_items.each do |i|
          items_subtotal -= i.adjustments.where(label: "Cancellation - Short Ship").count * i.price
        end
        items_subtotal
      end

      def percentage_of_line_item(line_item)
        1 / line_item.quantity.to_f
      end

      def void_payments_with_checkout_state
        payments.checkout.each(&:void!)
      end

      def total_applicable_store_credit_minus_voided
        if confirm? || complete?
          payments.not_void.store_credits.valid.sum(:amount)
        else
          [total, (user.try(:total_available_store_credit) || 0.0)].min
        end
      end

      def display_total_applicable_store_credit_minus_voided
        ::Spree::Money.new(-total_applicable_store_credit_minus_voided, currency: currency)
      end

      def update_invites
        invite_manager.purchase(user) if user
      end

      def activate_gift_cards
        return true unless gift_cards.any?
        gift_cards.each { |gc| gc.update_attributes!(redeemable: true) unless quarantine }
      end

      def store_credit_total
        payments.store_credits.sum(:amount)
      end

      def advance_shipping_step
        return if mobile?
        self.next
      end

      def contains_gift_card?
        return true if gift_card
        line_items.any? { |li| li.gift_cards.any? }
      end

      def add_store_credit_payments
        return true if gift_card?
        payments.store_credits.checkout.each(&:invalidate!)
        authorized_total = payments.pending.sum(:amount)

        remaining_total = outstanding_balance - authorized_total

        if user && user.store_credits.any?
          payment_method = ::Spree::PaymentMethod::StoreCredit.first

          user.store_credits.valid.order_by_priority.each do |credit|
            break if remaining_total.zero?
            next if credit.amount_remaining.zero?

            amount_to_take = [credit.amount_remaining, remaining_total].min
            payments.create!(source: credit,
                             payment_method: payment_method,
                             amount: amount_to_take,
                             state: 'checkout',
                             response_code: credit.generate_authorization_code)
            remaining_total -= amount_to_take
          end
        end

        other_payments = payments.checkout.not_store_credits
        if remaining_total.zero?
          other_payments.each(&:invalidate!)
        elsif other_payments.size == 1
          other_payments.first.update_attributes!(amount: remaining_total)
        end

        payments.reset

        if payments.where(state: %w(checkout pending)).sum(:amount) != total
          errors.add(:base, ::Spree.t("store_credit.errors.unable_to_fund")) and return false
        end
      end

      def virtual_gift_card
        @_virtual_gc ||= line_items.select { |li| li.gift_cards.any? }.first.gift_cards.last
      end

      def refresh_shipment_rates
        return true if gift_card?

        shipments.map(&:refresh_rates)
      end

      def create_proposed_shipments
        return shipments if unreturned_exchange?
        return shipments if gift_card? && state == 'address'

        if completed?
          raise ::Spree::Order::CannotRebuildShipments, ::Spree.t(:cannot_rebuild_shipments_order_completed)
        elsif shipments.any? { |s| !s.pending? }
          raise ::Spree::Order::CannotRebuildShipments, ::Spree.t(:cannot_rebuild_shipments_shipments_not_pending)
        else
          adjustments.shipping.destroy_all
          shipments.destroy_all
          self.shipments = ::Spree::Stock::Coordinator.new(self).shipments
        end
      end

      def tax_cloud_eligible?
        return false if gift_card?

        line_items.present? && ship_address.try(:state_id?)
      end

      # Finalizes an in progress order after checkout is complete.
      # Called after transition to complete state when payments will have been processed
      def finalize!
        # lock all adjustments (coupon promotions, etc.)
        all_adjustments.each(&:finalize!)

        # update payment and shipment(s) states, and save
        updater.update_payment_state
        shipments.each do |shipment|
          shipment.update!(self)
          shipment.finalize!
        end

        updater.update_shipment_state
        save!
        updater.run_hooks

        touch :completed_at

        deliver_order_confirmation_email unless confirmation_delivered? || gift_card?
      end

      def shipping_state_supported
        return if ship_address.nil? || ship_address.state.nil?

        if SHIPPING_ADDRESS_STATE_BLACKLIST.include?(ship_address.state.abbr)
          errors.add(:'ship_address.state_id', 'is not a supported state')
        end
      end

      def line_item_adjustments_with_code
        line_item_adjustments.promotion.select do |a|
          a.source.promotion.codes.any? { |code| code.value.present? }
        end
      end

      def remove_coupon_code(code = nil)
        coupon_adjustments = adjustments_for_coupon_code(code)

        return false if coupon_adjustments.empty?

        coupon_promotions = coupon_adjustments.map(&:source).map(&:promotion).uniq

        promotions.select { |p| coupon_promotions.include?(p) }.each do |p|
          promotions.delete(p)
        end

        coupon_adjustments.each(&:destroy)
        update!
      end

      # Override of base class
      # Code is exactly the same except that Order.count is replaced with Order.maximum(:id)
      def generate_order_number(options = {})
        options[:length]  ||= ::Spree::Order::ORDER_NUMBER_LENGTH
        options[:letters] ||= ::Spree::Order::ORDER_NUMBER_LETTERS
        options[:prefix]  ||= ::Spree::Order::ORDER_NUMBER_PREFIX

        possible = (0..9).to_a
        possible += ('A'..'Z').to_a if options[:letters]

        self.number ||= loop do
          # Make a random number.
          random = "#{options[:prefix]}#{(0...options[:length]).map { possible.sample }.join}"
          # Use the random  number if no other order exists with it.
          if self.class.exists?(number: random)
            # If over half of all possible options are taken add another digit.
            options[:length] += 1 if self.class.maximum(:id) > (10**options[:length] / 2)
          else
            break random
          end
        end
      end

      def hollar_item_total
        BigDecimal(line_items.hollar_merchant.sum('price * quantity'), 12)
      end

      def hollar_shipping_total
        if line_items.hollar_merchant.empty?
          BigDecimal(0)
        elsif shipments.empty?
          free_ship_min = free_shipping_required_item_total
          BigDecimal(hollar_item_total < free_ship_min ? HOLLAR_STANDARD_SHIPPING_RATE : 0, 12)
        else
          BigDecimal(shipments.hollar_merchant.to_a.sum(&:final_price), 12)
        end
      end

      def hollar_promo_adjustments_total
        BigDecimal(adjustments.eligible.sum(:amount), 12)
      end

      def hollar_total
        hollar_item_total + hollar_shipping_total + hollar_promo_adjustments_total
      end

      def marketplace_item_total
        BigDecimal(line_items.marketplace_merchant.sum('price * quantity'), 12)
      end

      def marketplace_shipping_total
        BigDecimal(line_items.marketplace_merchant.sum('COALESCE(marketplace_shipping_price, 0) * quantity'), 12)
      end

      def marketplace_total
        sum_total = line_items.marketplace_merchant.sum('(price + COALESCE(marketplace_shipping_price, 0)) * quantity')
        BigDecimal(sum_total, 12)
      end

      def subtotal
        hollar_total + marketplace_total
      end

      private

      def adjustments_for_coupon_code(code = nil)
        # Adapted from Order#determine_promotion_application_result
        if code.present?
          # strip promotions matching codes
          selector = lambda do |p|
            p.source.promotion.codes.any? { |c| c.value == code.downcase }
          end
        else
          # strip all promotions with codes
          selector = ->(p) { p.source.promotion.codes.any? }
        end

        # Check for applied adjustments.
        line_item_adjustments.promotion.select(&selector) +
          shipment_adjustments.promotion.select(&selector) +
          adjustments.promotion.select(&selector)
      end

      def send_cancel_email
        DelayedSend.perform_later('support@hollar.com',
                                  ::EmailTemplateSelector.select_template(external_key['canceled_order']),
                                  mailer_attributes)
      end

      def external_key
        @_external_key ||= ::Spree::BrontoConfiguration.account[store.code]
      end

      def invite_manager
        ::Hollar::Spree::InviteManager.new
      end
    end
  end
end

::Spree::Order.prepend ::Hollar::Spree::OrderDecorator
