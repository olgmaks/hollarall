module Hollar
  module Spree
    module UserDecorator
      PRODUCT_RECOMMENDATION_MODEL_CACHE_KEY = "Spree::User.product_recommendation_model_data".freeze
      TREASURE_HUNT_TIMEOUT = 90.days

      module ClassMethods
        # Please use for administrative and developer testing purposes only.
        def find_by_whatever(identifier = :random)
          if identifier.respond_to?(:to_i) && identifier.to_i > 0
            # find by exact ID (no exception raised if not found)
            find_by_id(identifier.to_i)
          elsif identifier.is_a?(Hash) || identifier.empty? ||
                (identifier.respond_to?(:to_s) && identifier.to_s == "random")
            # find by attribute hash (if present), randomizing if multiple results
            scope = identifier.is_a?(Hash) ? where(identifier) : self
            total = scope.count
            user = nil

            if total > 0
              user = scope.offset(rand(total)).first while user.nil?
            end

            return user
          elsif identifier.respond_to?(:to_s) && identifier.to_s =~ /@/
            # find by exact email (no exception raised if not found)
            find_by_email(identifier.to_s)
          end
        end

        def product_recommendation_model
          Rails.cache.fetch(PRODUCT_RECOMMENDATION_MODEL_CACHE_KEY) do
            ProductRecommendationModel.new
          end
        end

        def invalidate_product_recommendation_model
          Rails.cache.delete(PRODUCT_RECOMMENDATION_MODEL_CACHE_KEY)
        end
      end

      def self.prepended(base)
        base.singleton_class.prepend ClassMethods

        base.accepts_nested_attributes_for :bill_address
        base.after_create :generate_api_key
        base.after_create :generate_invite_code!
        base.after_create :register_invite_subscription!
        base.after_create :update_bronto_fields

        base.has_one :timed_promotion
        base.has_many :attributions, -> { order(created_at: :desc) }, as: :taggable
        base.has_many :user_accesses

        base.has_many :likes, dependent: :destroy
        base.has_many :liked_products, through: :likes, source: :product, class_name: 'Spree::Product'

        base.devise :impersonatable
      end

      def has_hidden_product_in_cart?
        last_incomplete_spree_order.try(:contains_hidden_products?)
      end

      def bought_hidden_product_before?
        orders.treasurable(Time.zone.now - TREASURE_HUNT_TIMEOUT).any?
      end

      def allowed_to_see_hidden_products?
        !has_hidden_product_in_cart? && !bought_hidden_product_before?
      end

      def product_recommendation_basis
        ProductRecommendationBasis.for_user(self.class.product_recommendation_model, self)
      end

      def flipper_id
        "User:#{id}"
      end

      def full_name
        "#{first_name} #{last_name}".strip
      end

      def recurring_user
        created_at.strftime('%Y%m%d H%M') != updated_at.strftime('%Y%m%d H%M')
      end

      def first_order?
        orders.complete.empty?
      end

      def first_hollar_item_purchase?(order)
        purchases = orders.complete.not_giftcards
        return true if purchases.empty?
        return false if purchases.count > 10
        hollar_purchases = purchases.to_a.select { |o| o.hollar_item_total > 0 }
        hollar_purchases.count == 1 and hollar_purchases.include?(order)
      end

      def billing_address
        if bill_address
          bill_address.country ||= ::Spree::Country.first
          return bill_address
        end

        build_bill_address(country: ::Spree::Country.first)
      end

      def shipping_address
        if ship_address
          ship_address.country ||= ::Spree::Country.first
          return ship_address
        end

        ::Spree::Address.new(country: ::Spree::Country.first)
      end

      def generate_api_key
        generate_spree_api_key!
      end

      def store_credit_amount
        store_credits.valid.map(&:amount_remaining).reduce(:+)
      end

      def generate_invite_code!
        code = nil
        while code.nil?
          # 20 characters that are unambiguous and highly unlikely to spell words
          code = ([*('b'..'y'), *('2'..'9')] - %w(d i o g q s e u c f k t)).sample(8).join
          code = nil if ::Spree::User.exists?(invite_code: code)
        end
        update_attribute(:invite_code, code)
      end

      def register_invite_subscription!
        invite_manager.subscribe(self)
      end

      def invite_manager
        ::Hollar::Spree::InviteManager.new
      end

      def update_bronto_fields
        BrontoContactAdd.perform_later(email,
                                       'spree',
                                       funnel_status: 'registered')
      end

      def total_available_store_credit
        store_credits.valid.reload.to_a.sum(&:amount_remaining)
      end

      def available_gift_cards
        ::Spree::VirtualGiftCard.where(redeemer_id: id, redeemable: true)
      end

      def current_gift_card
        ::Spree::VirtualGiftCard.find_by(purchaser_id: id, redeemable: false, redeemer_id: nil)
      end

      def update_from_omniauth(auth_hash)
        return true if first_name && last_name
        update_attributes(first_name: auth_hash['first_name'],
                          last_name: auth_hash['last_name'])
      end

      def last_incomplete_order_without_gift_cards(store: nil, only_frontend_viewable: true)
        self_orders = orders
        self_orders = self_orders.where(frontend_viewable: true) if only_frontend_viewable
        self_orders = self_orders.where(store: store) if store
        if ::Spree::Config.completable_order_updated_cutoff_days
          self_orders = self_orders.where('updated_at > ?',
                                          ::Spree::Config.completable_order_updated_cutoff_days.days.ago)
        end
        if ::Spree::Config.completable_order_created_cutoff_days
          self_orders = self_orders.where('created_at > ?',
                                          ::Spree::Config.completable_order_created_cutoff_days.days.ago)
        end
        self_orders = self_orders.not_giftcards
        last_order = self_orders.order(:created_at).last
        last_order unless last_order.try!(:completed?)
      end

      def activate_timed_promotion(order)
        current_time = Time.zone.now

        # create a new promotion if there is not one active and order is eligible
        if (!timed_promotion && TimedPromotion.order_eligible?(order)) ||
           (timed_promotion && !timed_promotion.active?(current_time) && timed_promotion.eligible?(order, current_time))
          timed_promotion.destroy if timed_promotion
          TimedPromotion.create(user: self, started_at: current_time,
                                ended_at: current_time + TimedPromotion::ACTIVE_DURATION)
          @timed_promotion_just_activated = true
        end
      end

      def timed_promotion_countdown(order, time)
        if timed_promotion && timed_promotion.eligible?(order, time)
          # currently active or merely restartable?
          if timed_promotion.active?(time)
            { time_left: timed_promotion.time_left(time), just_activated: @timed_promotion_just_activated || false }
          else
            # show full duration
            { time_left: TimedPromotion::ACTIVE_DURATION, just_activated: @timed_promotion_just_activated || false }
          end
        end # otherwise nil
      end

      def update_user_access(platform, version)
        user_access_cache_key = "user_access/#{id}/#{platform}"
        return if Rails.cache.exist?(user_access_cache_key)

        # store whether the user has registered activity for the given platform in the cache
        Rails.cache.write(user_access_cache_key, true, expires_in: 30.minutes)
        user_access = user_accesses.find_by(platform: platform)

        if user_access.nil?
          user_accesses.create(
            platform: platform,
            platform_version: version,
            access_time: Time.zone.now
          )
        else
          user_access.update_attributes(access_time: Time.zone.now, platform_version: version)
        end
      end
    end
  end
end

::Spree::User.prepend ::Hollar::Spree::UserDecorator
