module Spree
  class Comment < ActiveRecord::Base
    belongs_to :user, class_name: Spree.user_class, foreign_key: 'user_id'
    belongs_to :order, class_name: Spree::Order, foreign_key: 'order_id'
    belongs_to :customer_service, class_name: Spree.user_class, foreign_key: 'customer_service_id'
    belongs_to :line_item, class_name: Spree::LineItem, foreign_key: 'line_item_id'
  end
end
