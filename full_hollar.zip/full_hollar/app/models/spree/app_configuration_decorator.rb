Spree::AppConfiguration.class_eval do
  preference :taxcloud_api_login_id, :string, default:  ENV['TAXCLOUD_API_ID']
  preference :taxcloud_api_key, :string, default: ENV['TAXCLOUD_API_KEY']
  preference :taxcloud_default_product_tic, :string, default: '00000'
  preference :taxcloud_shipping_tic, :string, default: '11010'
  preference :taxcloud_usps_user_id, :string
  preference :cron_product_index_timestamp, :datetime
  preference :wms_shipment_tags, :string, default: '{}'
  preference :delayed_order_email_threshold, :integer, default: 10
  preference :delayed_order_email_max, :integer, default: 20
  preference :minfraud_enabled, :boolean, default: false
  preference :minfraud_threshold, :float, default: 100
  preference :minfraud_ip_address, :string
  preference :minfraud_use_ip, :boolean, default: false
  preference :usps_username, :string
  preference :minimum_checkout_amount, :float, default: 10.0
  preference :hollar_everyday_free_shipping_amount, :float, default: 25.0
  preference :hollar_first_order_free_shipping_amount, :float, default: 10.0

  TaxCloud.configure do |config|
    config.api_login_id = ENV['TAXCLOUD_API_ID']
    config.api_key = ENV['TAXCLOUD_API_KEY']
  end
end
