class TimedPromotion < ActiveRecord::Base
  module StoreCredit
    CATEGORY_NAME  = 'Timed Promotion'.freeze
    TYPE_NAME      = 'Expiring'.freeze
    CREATOR_EMAIL  = 'support@hollar.com'.freeze
  end

  ACTIVE_DURATION        = 15.minutes
  COOLDOWN_DURATION      = 10.hours

  belongs_to :user, class_name: 'Spree::User'

  def self.order_eligible?(order)
    order.total >= order.free_shipping_required_item_total && !order.contains_gift_card?
  end

  def complete(time, amount, memo)
    return unless active?(time) && FeatureFlags[:promotion_timer].enabled?(user)

    category = ::Spree::StoreCreditCategory.find_by(name: StoreCredit::CATEGORY_NAME)
    credit_type = ::Spree::StoreCreditType.find_by(name: StoreCredit::TYPE_NAME)
    created_by = ::Spree::User.find_by(email: StoreCredit::CREATOR_EMAIL)

    unless category && credit_type && created_by
      raise "Unable to credit $#{amount} to user #{user.id} for #{memo} due to missing data"
    end

    ::Spree::StoreCredit.create!(user: user, category: category, amount: amount,
                                 currency: Spree::Config[:currency], credit_type: credit_type,
                                 memo: memo, created_by: created_by)

    update(ended_at: time)
  end

  def eligible?(order, time)
    TimedPromotion.order_eligible?(order) && (active?(time) || restartable?(time))
  end

  def active?(time)
    (started_at..ended_at).cover?(time)
  end

  def restartable?(time)
    !ended_at || ended_at + COOLDOWN_DURATION <= time
  end

  def time_left(time)
    (ended_at - time).to_i if ended_at >= time
  end
end
