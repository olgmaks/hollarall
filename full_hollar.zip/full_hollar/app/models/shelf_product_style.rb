class ShelfProductStyle < ActiveRecord::Base
  belongs_to :shelf,   class_name: 'Shelf'
  belongs_to :product, class_name: 'Spree::Product', touch: true

  validates_uniqueness_of :shelf_id, scope: :product_id

  has_attached_file    :image, ATTACHMENT_CONFIG.merge(styles: { square: '476' }, default_url: 'placeholder.jpg', default_style: 'square')
  validates_attachment :image, content_type: { content_type: %w(image/jpg image/jpeg image/png image/gif) }
end
