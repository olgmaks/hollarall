class Error
  delegate :any?, to: :errors
  delegate :empty?, to: :errors
  delegate :first, to: :errors
  delegate :each, to: :errors

  def initialize(status)
    @status = status.to_i
    @container = { errors: [], status: status.to_i }
  end

  def add_error(error)
    add_custom_error(error[:code].to_i, error[:message], error[:details], error[:full_message])
  end

  def add_custom_error(code, message, details = nil, full_message = nil)
    all << { code: code.to_i, message: message, details: details, full_message: full_message }
  end

  def filter_by_code(code)
    all.select { |error| error[:code] == code.to_i }
  end

  def all
    container[:errors]
  end

  attr_accessor :status

  private

  alias_method :errors, :all
  attr_accessor :container
end
