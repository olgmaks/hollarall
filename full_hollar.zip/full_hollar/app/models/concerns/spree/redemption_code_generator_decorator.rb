Spree::RedemptionCodeGenerator.module_eval do
  # 25 characters: 36 letters plus digits minus the 11 most easily-confused
  UnambiguousCharacters = [*('A'..'Y'), *('3'..'9')] - %w(B D I O Q S 5)

  def self.generate_redemption_code
    UnambiguousCharacters.sample(16).join
  end

  def self.format_redemption_code_for_lookup(redemption_code)
    redemption_code.delete('-').strip.upcase
  end
end
