module Hollar
  module Gateway
    module SolidusBraintreeGatewayDecorator
      def create_profile(payment)
        super

        # make a copy of the credit card for use with Spree::Gateway::BraintreeGateway
        spree_braintree = ::Spree::PaymentMethod.find_by(active: true, type: 'Spree::Gateway::BraintreeGateway')

        if spree_braintree
          existing_credit_card = ::Spree::CreditCard.find_by(gateway_payment_profile_id: payment.source.gateway_payment_profile_id,
                                                             payment_method_id: spree_braintree.id)

          unless existing_credit_card
            credit_card_copy = payment.source.dup
            credit_card_copy.payment_method = spree_braintree
            credit_card_copy.save
          end
        end
      end
    end
  end
end

::Solidus::Gateway::BraintreeGateway.prepend ::Hollar::Gateway::SolidusBraintreeGatewayDecorator
