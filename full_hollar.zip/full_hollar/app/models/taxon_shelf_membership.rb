class TaxonShelfMembership < ActiveRecord::Base
  belongs_to :taxon, class_name: "Spree::Taxon"
  belongs_to :shelf, touch: true

  acts_as_list scope: :taxon
  default_scope { order("position ASC") }

  validates :taxon, presence: true
  validates :shelf, presence: true
end
