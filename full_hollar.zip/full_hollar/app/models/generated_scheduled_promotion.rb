class GeneratedScheduledPromotion < ActiveRecord::Base
  belongs_to :scheduled_promotion
  belongs_to :promotion, class_name: '::Spree::Promotion'

  has_many :codes, through: :promotion
end
