require 'import_logger'

module Filemaker
  class Product
    include Filemaker::Model

    # Config fields
    database ENV.fetch('FILEMAKER_DATABASE', 'HollarData')
    layout ENV.fetch('FILEMAKER_TABLE_PRODUCTS', 'Products')

    # Product fields
    string :name,         fm_name: 'ItemName'
    string :description,  fm_name: 'Description'
    string :category,     fm_name: 'Category'
    string :department,   fm_name: 'DepartmentName'
    string :item_number,  fm_name: 'ItemNumber'
    string :vendor_name,  fm_name: 'Vendor'

    # Variant fields
    string :sku,           fm_name: 'SKU'
    string :variant_desc,  fm_name: 'VariantDescription'
    string :metatags,      fm_name: 'Metatags'

    integer :variant_id,  fm_name: 'VariantNumber'
    string  :color,       fm_name: 'Color'
    string  :hex_color,   fm_name: 'HexColor'
    string  :size,        fm_name: 'VariantSize'
    string  :style,       fm_name: 'VariantStyle'
    integer :foldable,    fm_name: 'Foldable'

    number :weight_lbs,  fm_name: 'Weight_lbs'
    number :weight_oz,   fm_name: 'Weight_oz'
    number :height,      fm_name: 'Height'
    number :depth,       fm_name: 'Length'

    money  :price
    money  :cost_price,     fm_name: 'Cost'
    money  :regular_price,  fm_name: 'RegularPrice'

    # Images fields
    string   :image

    # Others
    datetime :available_on, fm_name: 'ReleaseDate'

    def self.option_types
      %w(color size style)
    end

    def parent?
      parent_id && parent_id > 0
    end

    def variant?
      variant_id && variant_id > 0
    end

    def weight
      # NOTE(cab): In Spree all the shipping calculation is made in ounces.
      # If we have the weight in pounds, we have to convert it to ounces.
      # The proper ratio is 1 for 16.
      return weight_oz if weight_oz?
      return weight_lbs * 16 if weight_lbs?

      0
    end

    def should_update_or_create?
      # TODO(cab): Check if we should update / create the product before doing
      # so. We are waiting for them to insert a field in the database for that.
      true
    end

    def valid?
      %w(sku price name category).each do |field|
        valid = send("#{field}").present?
        unless valid
          IMPORT_LOGGER.info("--- SKIP #{self}")
          IMPORT_LOGGER.info("The product is invalid. The following field is missing: #{field}")
          return false
        end
      end

      true
    end

    def to_s
      variant_string = variant? ? 'VARIANT' : 'PRODUCT'
      "[#{variant_string}] #{sku}"
    end

    def at_least_one_color_field?
      color.present? || hex_color.present?
    end

    # Option type validation
    self.option_types.each do |option_type_name|
      define_method "#{option_type_name}?" do
        send("#{option_type_name}").present?
      end
    end

    def color?
      color.present? && hex_color.present?
    end

    def foldable?
      foldable == 1 ? true : false
    end

    private

    def weight_lbs?
      weight_lbs && weight_lbs > 0
    end

    def weight_oz?
      weight_oz && weight_oz > 0
    end
  end
end
