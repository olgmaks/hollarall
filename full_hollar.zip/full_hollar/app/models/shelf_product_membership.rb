class ShelfProductMembership < ActiveRecord::Base
  belongs_to :shelf, touch: true
  belongs_to :product, class_name: "Spree::Product"

  after_commit :reindex_product

  acts_as_list scope: :shelf
  default_scope { order(position: :asc) }

  validates :shelf, presence: true
  validates :product, presence: true
  validate :only_membership_for_associated_shelves, on: :create

  def reindex_product
    product.reindex_async if product && Searchkick.callbacks?
  end

  protected

  def only_membership_for_associated_shelves
    if shelf.display_homepage
      associated = [shelf]
    else
      associated = shelf.taxons.flat_map { |t| Shelf.for_taxon_id(t.id).select { |x| product.taxons.include?(x) } }
    end

    unless associated.all? { |s| s.products.find_by(id: product_id).nil? }
      errors.add(:product, "is already on a shelf #{shelf.display_homepage ? 'on the homepage' : 'within this taxon'}")
    end
  end
end
