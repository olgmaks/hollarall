class Merchant < ActiveRecord::Base
  extend FriendlyId
  friendly_id :slug_candidates, use: :history
  self.table_name = "hollar_merchant_merchants"
  has_many :user, class_name: 'Spree::User'
  has_many :product, class_name: 'Spree::Product'

  before_validation :normalize_slug, on: :update

  scope :hollar_merchants, -> { where(is_marketplace: false) }

  validates :slug, presence: true, uniqueness: { allow_blank: true }

  def normalize_slug
    self.slug = normalize_friendly_id(slug)
  end

  # Try building a slug based on the following fields in increasing order of specificity.
  def slug_candidates
    [
      :name,
      [:name, :shop_name]
    ]
  end
end
