require 'matrix'

class ProductRecommendationBasis
  attr_accessor :vector

  # Gender products have "M" and "F" as their Elasticsearch _id value, but have no
  # representation in the database so their internal "id" is a mere placeholder.
  # They are created with these ES requests:
  # PUT /spree_products_production/spree%2Fproduct/F {"id": 2000000000,"name": "F"}
  # PUT /spree_products_production/spree%2Fproduct/M {"id": 2000000001,"name": "M"}

  ANONYMOUS = Vector[0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0].freeze

  def self.for_user(model, user)
    result = Searchkick::Query.new(ProductRecommendationBasis,
                                   query: { match: { user_id: user.id } },
                                   load: false).results.first
    new(model, result && result["factors"])
  end

  def initialize(model, vector = nil)
    @model = model
    @vector = vector ? Vector[*vector] : ANONYMOUS.dup
  end

  def anonymous?
    @vector == ANONYMOUS
  end

  def update(increment, strength)
    return if strength.zero?

    product = @vector.inner_product(increment)
    return if product >= 1.0

    if @vector.inject(&:+).zero?
      scale = 0.5
    else
      scale = product
    end

    target_product = scale + (strength / (1 + strength)) * (1.0 - [0.0, scale].max)
    product_diff = target_product - product

    @vector += @model.solve(Vector[*increment] * product_diff)
  end

  def update_from_events(events)
    factors = ProductRecommendationFactorHash.new
    product_events = events.map { |e| [(e[0] == :gender ? e[1].upcase : e[0]), (factors[e[0]] || 0.0)] }
    product_results = ProductRecommendationModel.vector_results_for_product_ids(product_events.map(&:first))
    product_vectors = Hash[product_results.map do |result|
      [result["_id"], ProductRecommendationModel::PERSONALIZATION_KEYS.map { |k| result[k] }]
    end]

    product_events.each do |product_id, strength|
      increment_vector = product_vectors[product_id]
      unless increment_vector.blank?
        update(increment_vector, strength.to_f)
      end
    end
  end

  def to_s
    # convert to floats with single precision, then to a base64 string (minus newline)
    [@vector.to_a.pack('g*')].pack('m').chomp
  end

  def self.from_s(model, str)
    # convert from a base64 string to array of single-precision-format floats
    new(model, str.unpack('m').first.unpack('g*'))
  rescue StandardError # possibility of a RangeError or ArgumentError on bad data
    nil
  end

  # Searchkick config for for_user
  def self.searchkick_index
    Searchkick::Index.new("personalization_users", searchkick_options)
  end

  def self.searchkick_options
    { load: false }
  end

  def self.searchkick_klass
    nil
  end

  def self.model_name
    "users"
  end
end
