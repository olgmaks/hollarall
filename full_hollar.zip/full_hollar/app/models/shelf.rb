class Shelf < ActiveRecord::Base
  has_many :taxons, class_name: "Spree::Taxon", through: :taxon_shelf_memberships
  has_many :products, class_name: "Spree::Product", through: :shelf_product_memberships

  has_many :taxon_shelf_memberships, dependent: :destroy
  has_many :shelf_product_memberships, dependent: :destroy

  belongs_to :referenced_taxon, class_name: 'Spree::Taxon'

  has_many :shelf_product_styles

  acts_as_list

  default_scope { order(position: :asc) }

  belongs_to :group, class_name: 'ShelfGroup'

  scope :autoloaded, -> { where(autoload: true) }
  scope :displayed_on_homepage, -> { where(display_homepage: true) }
  scope :fixed_position, -> { where(fixed_position: true) }
  scope :fixed_position_homepage, -> { where(fixed_position: true, display_homepage: true) }
  scope :for_taxon, ->(taxon) { for_taxon_id(taxon.id) }
  scope :for_taxon_id, ->(taxon_id) { joins(:taxons).where(::Spree::Taxon.table_name.to_sym => { id: taxon_id }) }
  scope :ungrouped, -> { where(group_id: nil) }

  HOMEPAGE_SHELVES = Hash.new('Homepage Top').merge('male' => 'Homepage Top - Male',
                                                    'female' => 'Homepage Top - Female').freeze

  def self.gender_specific?(user)
    FeatureFlags[:gender_specific_shelves].enabled?(user) && user.try(:gender)
  end

  def self.homepage_name_for_user(user)
    HOMEPAGE_SHELVES[gender_specific?(user) && user.gender.downcase]
  end

  def self.homepage_for_user(user, fixed_position)
    if fixed_position
      fixed_position_homepage.first
    else
      find_by(name: homepage_name_for_user(user)) || displayed_on_homepage.first
    end
  end

  def client_count
    taxons.count + (display_homepage ? 1 : 0)
  end

  def shelf_products_positions
    @positions ||= Hash[shelf_product_memberships.pluck(:position, :product_id)]
  end

  def pepper_products(other_products, page = 1, per_page = 32)
    offset = (page.to_i - 1) * per_page.to_i
    other_products.each.with_index(1) do |_p, i|
      if shelf_products_positions[i + offset].present?
        other_products.insert(i - 1, shelf_products_positions[i + offset])
      else
        next
      end
    end
    other_products
  end
end
