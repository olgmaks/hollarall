class FeatureExperiment < ActiveRecord::Base
  validates :name, :source, presence: true
  validates :name, uniqueness: true
end
