require 'matrix'

class ProductRecommendationModel
  attr_reader :matrix

  delegate :solve, to: :matrix

  PERSONALIZATION_KEYS = (1..10).map { |n| "personalization_#{n}" }.freeze

  # Searchkick config for for_user
  def self.searchkick_index
    Searchkick::Index.new("products_users_model_#{Rails.env}", ProductRecommendationModel.searchkick_options)
  end

  def self.searchkick_options
    { load: false }
  end

  def self.searchkick_klass
    nil
  end

  def self.model_name
    "matrix"
  end

  def initialize(matrix = nil)
    unless matrix.present?
      result = Searchkick::Query.new(ProductRecommendationModel,
                                     query: { match: { _id: 1 } },
                                     load: false).results.first
    end

    @matrix = Matrix.new(matrix || result["matrix"])
  rescue Searchkick::MissingIndexError
    @matrix = Matrix.new(::Matrix.zero(PERSONALIZATION_KEYS.count).to_a)
  end

  def self.vector_results_for_product_ids(ids)
    ::Spree::Product.search(query: { bool: { must: [{ exists: { field: "personalization_1" } },
                                                    { ids: { type: Spree::Product.model_name.collection,
                                                             values: ids } }] } },
                            load: false, select_v2: { include: ["_id"] })
  rescue Searchkick::MissingIndexError
    Searchkick::Results.new(::Spree::Product, "hits" => { "total" => 0, "hits" => [] })
  end

  class Matrix
    attr_accessor :value

    def self.matrix_for_product_vector(vector)
      ::Matrix.build(vector.length, vector.length) do |row, column|
        vector[row] * vector[column]
      end
    end

    def initialize(rows)
      self.value = ::Matrix.rows(rows)
    end

    def ==(other)
      @value == other.value
    end

    def value=(m)
      @value = m
      @lupd = ::Matrix::LUPDecomposition.new(@value)
    end

    def add_product_vectors(vectors)
      m = @value

      vectors.each do |v|
        m += self.class.matrix_for_product_vector(v)
      end

      self.value = m
    end

    def solve(vector)
      @lupd.solve(vector)
    end
  end
end
