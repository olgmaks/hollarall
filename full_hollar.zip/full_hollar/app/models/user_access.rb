class UserAccess < ActiveRecord::Base
  belongs_to :user, class_name: 'Spree::User'

  validates :user_id, :platform, :access_time, presence: true
  validates :platform, uniqueness: { scope: :user_id }
end
