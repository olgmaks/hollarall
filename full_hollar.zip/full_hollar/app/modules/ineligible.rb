module Ineligible
  def ineligible_line_item?(object, eligible_merchant_ids)
    ineligible_partial_line_item?(object, eligible_merchant_ids) || ineligible_normal_line_item?(object, eligible_merchant_ids)
  end

  def ineligible_normal_line_item?(object, eligible_merchant_ids)
    object.is_a?(::Spree::LineItem) && object.ineligible?(eligible_merchant_ids)
  end

  def ineligible_partial_line_item?(object, eligible_merchant_ids)
    return unless object.is_a?(Spree::Promotion::Actions::CreateQuantityAdjustments::PartialLineItem)
    object.instance_variable_get('@line_item').ineligible?(eligible_merchant_ids)
  end
end
