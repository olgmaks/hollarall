module StoreCreditable
  def create_credit_for_timed_promotion(params)
    policy = ::TimedPromotionPolicy.new(user: params[:reciever])

    return unless policy.in_progress? && FeatureFlags[:promotion_timer].enabled?(params[:reciever])

    category = ::Spree::StoreCreditCategory.find_by!(name: params[:category_name])
    type     = ::Spree::StoreCreditType.find_by!(name: params[:credit_type])
    creator  = ::Spree::User.find_by!(email: params[:creator_email])

    ::Spree::StoreCredit.create!(
      user:        params[:reciever],
      category:    category,
      amount:      params[:amount],
      currency:    'USD',
      credit_type: type,
      memo:        params[:memo],
      created_by:  creator
    )
    params[:reciever].timed_promotion.update(ended_at: Time.zone.now)
  end
end
