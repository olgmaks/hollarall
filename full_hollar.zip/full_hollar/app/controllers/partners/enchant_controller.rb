# Enchant is our client services ticketing system
# This adds a sidebar content to Enchant with direct Admin links to the Solidus backoffice
#   http://dev.enchant.com/guides/sidebar-box
# Only used in Production

class Partners::EnchantController < ApplicationController
  layout false

  skip_before_filter :verify_authenticity_token

  def sidebar
    body = request.body.read
    signature = request.headers["Enchant-Signature"]

    key = ENV.fetch('ENCHANT_SIDEBAR_KEY', '')
    hash_signature = OpenSSL::HMAC.hexdigest(OpenSSL::Digest::Digest.new('sha256'), key, body)

    @request_verified = (signature==hash_signature)
    if @request_verified
      email = params['customer']['contacts'].select{|c| c['type']=='email'}.first['value']
      @members = Spree::User.where(email: email).all
    end
  end
end
