module SearchFilters
  extend ActiveSupport::Concern

  def default_filter(display_platform = nil, merchant_id = nil)
    query_hash = { name: { not: "Gift Card" } }
    # support property to suppress products from search
    query_hash[:property_unsearchable] = { not: "true" } if params[:keywords]
    query_hash[:merchant_id] = merchant_id if merchant_id

    # only return active & non-hidden products
    query_hash.merge!(deleted_at: nil, hidden: false, available_on: { lte: Time.zone.now })

    if display_platform
      query_hash[:display_platforms] = [display_platform.downcase]
    end

    query_hash
  end
end
