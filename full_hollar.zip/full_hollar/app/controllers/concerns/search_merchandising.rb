module SearchMerchandising
  extend ActiveSupport::Concern

  include SearchFilters

  def index_searcher(user, params)
    search_params = params.reverse_merge(app_platform: 'web')

    search_params[:order_params] = format_order_params(user, true, params)

    merchant_id = params[:merchant_id] if params[:merchant_id]

    ::Spree::Config.searcher_class.new(search_params).tap do |searcher|
      if search_params[:product_recommendation_basis].present?
        recommendation_factors = search_params[:product_recommendation_basis].vector.to_a
        script_elements = recommendation_factors.map.with_index do |bve, i|
          "#{format('%.12f', bve)} * doc['personalization_#{i + 1}']"
        end

        searcher.searchkick_options = {
          load: false,
          select_v2: { include: %w(id taxon_ids) },
          where: default_filter(params[:app_platform] || 'web', merchant_id),
          query: {
            function_score: {
              functions: [{
                script_score: {
                  lang: "expression",
                  script: script_elements.join(" + ")
                }
              }]
            }
          }
        }
      else
        searcher.searchkick_options = { load: false, select_v2: { include: %w(id taxon_ids) },
                                        where: default_filter(search_params[:app_platform], merchant_id) }
      end
    end
  end

  def format_order_params(user, for_homepage, search_params)
    if search_params[:product_recommendation_basis].present?
      return search_params[:order_params] && Hash[params[:order_params]["order"].to_sym,
                                                  params[:order_params]["direction"].to_sym]
    end

    [].tap do |order_params|
      if search_params[:order_params].present?
        order_params << Hash[params[:order_params]["order"].to_sym, params[:order_params]["direction"].to_sym]

        if search_params[:order_params]["order"] == "price"
          order_params << { conversions: :desc }
        end
      end

      if for_homepage
        key = "homepage_position"
        key += "_#{user.gender.downcase}" if user && Shelf.gender_specific?(user)
        order_params << { key.to_sym => :asc }
      end
    end
  end

  def relevant_taxon_ids_from_results(results)
    # use taxon IDs from departments as well as categories and gift/party taxons
    results.map { |r| r.taxon_ids.uniq }.flatten.uniq
  end

  def shuffle_in_new_products_in_taxons(user, existing_product_ids, product_taxon_ids, params)
    searcher = ::Spree::Config.searcher_class.new(params.merge(order_params: { available_on: :desc,
                                                                               conversions: :desc }))
    searcher.searchkick_options = { where: { display_platforms: [params[:app_platform] || 'web'],
                                             taxon_ids: product_taxon_ids,
                                             property_unsearchable: { not: "true" } } }
    searcher.current_user = user

    # shuffle in an item for every third item:
    # [:a, :b, :c, :d, :e].each_slice(2).to_a.zip([:x, :y]).flatten.compact => [:a, :b, :x, :c, :d, :y, :e]
    existing_product_ids.each_slice(2).to_a.zip(searcher.retrieve_products.map(&:id)).flatten.compact
  end

  def load_products(product_ids, params, preloads = [], extra_preloads = {})
    per_page = params[:per_page] || ::Spree::Config.products_per_page
    page = [params[:page].to_i, 1].max

    product_ids = product_ids[0, per_page]
    scope = ::Spree::Product.where(id: product_ids).order_as_specified(id: product_ids)
    preloads += [:stock_items, :variant_images]
    scope = scope.preload(*preloads.uniq)
    scope.preload(extra_preloads.deep_merge(variants: :prices, master: :default_price))

    available_product_count = Rails.cache.fetch("products/merchandising-available-count", expires_in: 5.minutes) do
      ::Spree::Product.available.count
    end

    Kaminari::PaginatableArray.new(scope.to_a, total_count: available_product_count,
                                               limit: per_page, offset: (page - 1) * per_page)
  end

  def product_recommendation_basis(user, basis_param, items_views, cart_items)
    model = ::Spree::User.product_recommendation_model

    if model && FeatureFlags[:product_recommendations].enabled?(user) # user can be nil
      if basis_param.present? && basis_param.is_a?(String)
        return ProductRecommendationBasis.from_s(model, basis_param)
      end

      if basis_param.nil?
        basis = nil

        if user
          basis = user.product_recommendation_basis
          basis &&= basis.dup
        end

        basis ||= ProductRecommendationBasis.new(model)

        begin
          update_events = []

          if items_views.present?
            items_views.each_key do |p|
              update_events << [:view, p]
            end
          end

          if cart_items.present?
            cart_items.each do |p|
              update_events << [:addtocart, p]
            end
          end

          if user && user.gender
            update_events << [:gender, user.gender]
          end

          unless update_events.empty?
            basis.update_from_events(update_events)
          end
        rescue ExceptionForMatrix::ErrNotRegular
          basis = user && user.product_recommendation_basis && user.product_recommendation_basis.dup
          basis ||= ProductRecommendationBasis.new(model)
        end

        return basis.anonymous? ? nil : basis
      end
    end

    nil # just so we're clear
  end

  def get_recommendation_basis(user)
    basis_param = params[:product_recommendation_basis]
    recommendation_user = user

    # allow admins to override recommendations
    if ::Spree.user_class && can?(:admin, ::Spree.user_class) && params[:as].present?
      recommendation_user = ::Spree::User.find_by_whatever(params[:as])
    end

    product_recommendation_basis(recommendation_user, basis_param,
                                 session[:products_views],
                                 session[:cart_items])
  end
end
