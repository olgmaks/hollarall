# NOTE(cab): This module is mainly used during the checkout flow of the API
# This is only being used for API < V3
module CartValidations
  extend ActiveSupport::Concern

  def error_for_adding_product(variant_id, quantity, current_user, current_order)
    quantity ||= 0
    related_product = ::Spree::Product.by_variant_id(variant_id)

    # NOTE(cab): We are doing some kind of hacks in order to not display out of stock items.
    # We set the item as deleted, but the client could still have the item in the cart,
    # Thus crashing here since the product is not found. This is a failsafe to make sure
    # we do not crash the user / nor receive airbrake errors.
    return nil if related_product.nil? || quantity == 0

    cart_product_quantity = current_order.line_items.includes(:variant)
      .where(spree_variants: { product_id: related_product.id })
      .where.not(variant_id: variant_id)
      .sum(:quantity) + quantity

    if (related_product.max_product_per_order || 0) > 0 &&
      cart_product_quantity > related_product.max_product_per_order
      return {
        long_message: "Limit #{related_product.max_product_per_order} per order: #{related_product.name}",
        type: 'order'
      }
    elsif current_user && (related_product.max_product_per_customer || 0) > 0
      historic_product_quantity = ::Spree::LineItem.joins(:order, :variant)
        .where(spree_orders: { user_id: current_user.id }, spree_variants: { product_id: related_product.id  })
        .where.not(order_id: current_order.id)
        .sum(:quantity)

      if historic_product_quantity + cart_product_quantity > related_product.max_product_per_customer
        return {
          long_message: "Limit #{related_product.max_product_per_customer} per customer: #{related_product.name}",
          type: 'customer'
        }
      end
    end

    nil
  end

  def error_for_min_checkout(current_order)
    {
      long_message: "A $#{::Spree::Order.minimum_checkout_amount} minimum order is required to checkout.",
      type: 'order'
    } unless current_order.minimum_amount?
  end
end
