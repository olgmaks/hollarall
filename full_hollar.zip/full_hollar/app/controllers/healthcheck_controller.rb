class HealthcheckController < ApplicationController
  def alive
    render json: { status: "healthy"}
  end
end
