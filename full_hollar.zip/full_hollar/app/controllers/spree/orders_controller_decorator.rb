module Hollar
  module Spree
    module Controllers
      module OrdersControllerDecorator
        def self.prepended(base)
          base.before_action :assign_order, only: [:update, :set_quantity, :offer_promotion]
          base.around_action :lock_order, only: [:update, :set_quantity]
          base.before_action :apply_coupon_code, only: [:update, :set_quantity]
        end

        def show
          super
          display_invite_modal
          decide_to_show_credit_applied_box
        end

        def edit
          @order = current_order
          @order ||= ::Spree::Order.incomplete.find_or_initialize_by(guest_token: cookies.signed[:guest_token])

          order_rules = OrderCheckoutRules.new(@order, try_spree_current_user)
          order_rules.verify_insufficient_stock
          order_rules.verify_max_products_per_line_items
          order_rules.verify_max_by_group
          @errors = order_rules.error_container

          if @errors.any?
            OrderCheckoutSolver.new(@order, @errors).auto_solve
          end

          associate_user
          case params[:display_layout]
          when 'false'
            render(layout: false)
          when 'mobile_modal'
            render(layout: 'mobile_modal')
          else
            render
          end
          super
        end

        def offer_promotion
          if spree_current_user
            spree_current_user.activate_timed_promotion(@order)

            render json: spree_current_user.timed_promotion_countdown(@order, Time.zone.now)
          else
            render json: nil
          end
        end

        def cart_refresh
          @order = current_order(create_order_if_necessary: false)
          if @error
            flash[:error] = @error
            respond_with(@order) do |format|
              format.js { render "populate.js.erb" }
              format.html { redirect_back_or_default(spree.root_path) }
            end
          else
            respond_with(@order) do |format|
              format.js { render "populate.js.erb" }
              format.html { redirect_to cart_path }
            end
          end
        end

        # Adds a new item to the order (creating a new order if none already exists)
        def populate
          @order   = current_order(create_order_if_necessary: true)
          variant  = ::Spree::Variant.find(params[:variant_id])
          quantity = params[:quantity].to_i

          # avoid item totals above 2,147,483,647 by limiting to reasonable quantity (see https://github.com/spree/spree/issues/2695).
          if !quantity.between?(1, 1_000)
            @error = ::Spree.t(:please_enter_reasonable_quantity)
          else
            order_rules = ::OrderCheckoutRules.new(@order, spree_current_user)
            errors = order_rules.verify_would_hit_max_product(variant.id, quantity)

            @error = errors.first[:message] if errors.any?
          end

          unless @error
            begin
              @previous_total = @order.total
              @order.contents.add(variant, quantity)
            rescue ActiveRecord::RecordInvalid => e
              @error = e.record.errors.full_messages.join(", ")
            end
          end

          if @error
            flash[:error] = @error
            respond_to do |format|
              format.html { redirect_back_or_default(spree.root_path) }
              format.js
            end
          else
            if session[:cart_items]
              session[:cart_items] << variant.product.id
            else
              session[:cart_items] = @order.products.ids
            end
            respond_with(@order) do |format|
              format.html { redirect_to cart_path }
              format.js
            end
          end
        end

        def remove_line_adjustments
          @order = ::Spree::Order.find(params[:order_id])
          adjustments = ::Spree::Adjustment.find(params[:id])
          handler = ::Spree::PromotionHandler::Coupon.new(@order)
          adjustments.each { |a| handler.remove(a) }
          if %w{cart address}.include? @order.state
            redirect_to cart_path
          else
            redirect_to checkout_path
          end
        end

        def set_quantity
          line_item = @order.line_items.where(id: params[:line_item_id]).first

          unless line_item.nil? || params[:quantity].to_i > 1_000
            old_quantity = line_item.quantity
            new_quantity = params[:quantity].to_i

            if new_quantity < old_quantity
              if new_quantity == 0
                session[:cart_items] ||= @order.products.ids
                session[:cart_items].delete(line_item.product.id)
              end
              @order.contents.remove(line_item.variant, old_quantity - new_quantity)
            elsif new_quantity > old_quantity
              @order.contents.add(line_item.variant, new_quantity - old_quantity)
            end
          end

          respond_to do |format|
            format.html do
              render partial: 'spree/shared/cart_dropdown', locals: { order: @order }
            end
            format.js { render 'populate' }
          end
        end

        def can_add_product
          current_order = current_order(create_order_if_necessary: true)

          quantity = params[:quantity].to_i
          variant_id = params[:variant_id]

          order_rules = ::OrderCheckoutRules.new(current_order, spree_current_user)
          errors = order_rules.verify_would_hit_max_product(variant_id, quantity)
          errors = order_rules.verify_would_hit_max_by_group(variant_id, quantity) unless errors.any?
          if errors.any?
            respond_to do |format|
              format.all { render 'api/errors/show', status: :unprocessable_entity, locals: { errors: errors } }
            end
          else
            head :ok
          end
        end

        private

        def decide_to_show_credit_applied_box
          @credit_applied = request.referer && (request.referer.include? '/checkout/') &&
                            @order && @order.user && @order.user.timed_promotion &&
                            @order.user.timed_promotion.ended_at > 1.minute.ago &&
                            TimedPromotion.order_eligible?(@order)
        end

        def display_invite_modal
          if request.referer && (request.referer.include? '/checkout/')
            @display_invite_modal = true
          end
        end
      end
    end
  end
end

::Spree::OrdersController.prepend ::Hollar::Spree::Controllers::OrdersControllerDecorator
