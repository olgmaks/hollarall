module Spree
  class MarketplaceLandingController < Spree::StoreController
    def index
    end

    def apply
      ::Hollar::Spree::MarketplaceApplicationMailer.new(params).send_application
      redirect_to marketplace_landing_path, notice: 'Your application has been submitted.'
    end
  end
end
