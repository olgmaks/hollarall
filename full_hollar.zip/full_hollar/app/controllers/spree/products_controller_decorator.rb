module Hollar
  module Spree
    module Controllers
      module ProductsControllerDecorator
        include SearchFilters

        def show
          return redirect_to root_path if (@product.unsearchable? || @product.hidden) && !request.xhr? && !@product.gift_card?

          @product.taxons.each do |taxon|
            raise ActiveRecord::RecordNotFound unless taxon.display_web?
          end

          @variants = @product.variants_including_master.active(current_currency).includes([:option_values, :images])
          @product_properties = @product.product_properties.includes(:property)
          @product_limits_text = product_limits.join('<br/>').html_safe
          if params[:suggestions] != 'false'
            if FeatureFlags[:holiday_yaml].enabled?(spree_current_user)
              @suggestions = @product.suggestions(get_num_product_suggestions,
                                                  @product.holiday_suggestions(((get_num_product_suggestions * 2) / 3)))
            else
              @suggestions = @product.suggestions(get_num_product_suggestions)
            end
            if current_spree_user.try(:allowed_to_see_hidden_products?)
              @suggestions.insert(6, *@product.children.available)
              @suggestions = @suggestions.compact[0..get_num_product_suggestions - 1]
            end
          end

          session[:products_views] ||= {}
          if session[:products_views].size >= 50
            session[:products_views].delete(session[:products_views].first[0])
          end
          val = session[:products_views].delete(@product.id).to_i
          session[:products_views][@product.id] = val + 1

          case params[:display_layout]
          when 'false'
            render(layout: false)
          when 'mobile_modal'
            render(layout: 'mobile_modal', action: "show-mobile_modal")
          else
            @page_pdp = true
            render
          end
        end

        def index
          if params[:ids] || params[:keywords].blank?
            params[:app_platform] = 'web'
            return super
          end

          @searcher = build_searcher(params.merge(include_images: true))
          @searcher.searchkick_options = { where: default_filter('web', params[:merchant_id]) }
          @products = @searcher.retrieve_products
          @taxonomies = ::Spree::Taxonomy.includes(root: :children).displayable_on('web')
        end

        private

        def get_num_product_suggestions
          FeatureFlags[:marketplace_pdp].enabled? ? 15 : 12
        end

        def product_limits
          limits = []

          if @product.max_product_per_customer
            limits << "Limit #{@product.max_product_per_customer} per customer"
          end

          if @product.max_product_per_order
            limits << "Limit #{@product.max_product_per_order} per order"
          end

          limits
        end

        def load_product
          super
          if @product.gift_card?
            if current_gift_card_order.nil? || current_gift_card_order.gift_cards.first.nil? || !editing_gift_card?
              @gift_card = ::Spree::VirtualGiftCard.new
            else
              @gift_card = current_gift_card_order.gift_cards.first
            end
          end
        rescue ActiveRecord::RecordNotFound
          @product = ::Spree::Product.displayable_on('web').with_deleted.friendly.find(params[:id])
        end

        def editing_gift_card?
          request.path.match(/gift-card/) && params[:edit]
        end
      end
    end
  end
end

::Spree::ProductsController.prepend ::Hollar::Spree::Controllers::ProductsControllerDecorator
