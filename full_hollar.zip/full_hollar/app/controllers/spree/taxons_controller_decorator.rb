module Hollar
  module Spree
    module Controllers
      module TaxonsControllerDecorator
        def self.prepended(base)
          base.include SearchFilters
          base.include SearchMerchandising
        end

        def build_searcher(params)
          extra_params = { include_images: true }

          if params[:taxon].present? and params[:q].blank?
            extra_params[:order_params] = {
              "taxon_#{params[:taxon]}_position".to_sym => { order: :asc, unmapped_type: 'integer' }
            }
          end

          if params[:order_params].present?
            extra_params[:order_params] = format_order_params(spree_current_user, true, params)
          end

          searcher = ::Spree::Config.searcher_class.new(params.merge(extra_params))

          if params[:taxon].present?
            searcher.searchkick_options = { where: default_filter('web', params[:merchant_id]).merge(taxon_ids: [params[:taxon].to_i]) }
          else
            searcher.searchkick_options = { where: default_filter('web', params[:merchant_id]) }
          end

          searcher.current_user = try_spree_current_user

          searcher
        end
      end
    end
  end
end

::Spree::TaxonsController.prepend ::Hollar::Spree::Controllers::TaxonsControllerDecorator
