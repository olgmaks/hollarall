module Spree
  class ShareController < Spree::UserRegistrationsController
    def show
      if current_spree_user.present?
        redirect_to root_path
        return
      end

      @code = params[:id]
      cookies[:invite_code] = @code
      @resource = Spree::User.new
    end

    def create
      code = params[:id]
      build_resource(spree_user_params)
      resource.referral_invite_code = code
      if resource.save
        set_flash_message(:notice, :signed_up)
        sign_in(:spree_user, resource)
        session[:spree_user_signup] = true
        associate_user
        respond_with resource, location: after_sign_up_path_for(resource)
      else
        clean_up_passwords(resource)
        flash[:error] = resource.errors.full_messages.first
        redirect_to share_path(id: code)
      end
    end
  end
end
