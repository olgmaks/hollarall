module Hollar
  module Spree
    module Controllers
      module StoreControllerDecorator
        def self.prepended(base)
          base.before_action :update_user_access
        end

        def apply_coupon_code
          @order.update_attribute(:channel, 'spree')
          super
        end

        private

        def update_user_access
          try_spree_current_user.update_user_access('spree', nil) if try_spree_current_user
        end
      end
    end
  end
end

::Spree::StoreController.prepend ::Hollar::Spree::Controllers::StoreControllerDecorator
