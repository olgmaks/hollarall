module Hollar
  module Spree
    module Controllers
      module StaticContentControllerDecorator
        private

        def determine_layout
          if !request.params['app'].blank?
            'spree/layouts/app_content_only'
          elsif @page && @page.layout.present? && !@page.render_layout_as_partial?
            @page.layout
          else
            ::Spree::Config.layout
          end
        end
      end
    end
  end
end

::Spree::StaticContentController.prepend ::Hollar::Spree::Controllers::StaticContentControllerDecorator
