module Spree
  class PodsController < Spree::StoreController
    def show
      @pod = Spree::Pod.find(params[:id])
    end
  end
end
