module Spree
  class NewslettersController < Spree::StoreController
    def create
      BrontoContactAdd.perform_later(newsletter_attributes[:email],
                                     current_store_code)
      redirect_to spree.root_path, notice: I18n.t(:successful_newsletter_signup, scope: 'spree')
    end

    private

    def newsletter_attributes
      params.require(:newsletter).permit(:email)
    end

    def current_store_code
      Store.current.code
    end
  end
end
