module Spree
  class ArticlesController < Spree::StoreController
    def index
      @articles = Spree::Article.all

      respond_with(@articles)
    end
  end
end
