module Spree
  class BackToSchoolController < Spree::StoreController
    PRIZES = {
      ten_pct_off:    { name: '10% off ($12 min)', type: :pct, off: 10, min: 12 },
      twenty_pct_off: { name: '20% off ($15 min)', type: :pct, off: 20, min: 15 },
      thirty_pct_off: { name: '30% off ($15 min)', type: :pct, off: 30, min: 15 },
      forty_pct_off:  { name: '40% off ($18 min)', type: :pct, off: 40, min: 18 },
      fifty_pct_off:  { name: '50% off ($20 min)', type: :pct, off: 50, min: 20 },
      two_usd_off:    { name: '$2 off ($12 min)',  type: :usd, off: 2,  min: 12 },
      five_usd_off:   { name: '$5 off ($15 min)',  type: :usd, off: 5,  min: 15 },
      ten_usd_off:    { name: '$10 off ($20 min)', type: :usd, off: 10, min: 20 }
    }.freeze

    PRIZE_PROBABILITIES = {
      non_buyer: {
        ten_pct_off:    50,
        twenty_pct_off: 15,
        thirty_pct_off: 5,
        forty_pct_off:  2,
        fifty_pct_off:  1,
        two_usd_off:    20,
        five_usd_off:   5,
        ten_usd_off:    2
      },
      lapsed_buyer: {
        ten_pct_off:    60,
        twenty_pct_off: 20,
        two_usd_off:    20
      },
      active_buyer: {
        ten_pct_off:    100
      }
    }.freeze

    STORE_CREDIT_WIN_TIMES = {
      '07/25/16' => Time.zone.local(2016, 7, 25, 16, 7),
      '07/26/16' => Time.zone.local(2016, 7, 26, 18, 7),
      '07/27/16' => Time.zone.local(2016, 7, 27, 4,  15),
      '08/01/16' => Time.zone.local(2016, 8, 1,  20, 31),
      '08/02/16' => Time.zone.local(2016, 8, 2,  17, 52),
      '08/03/16' => Time.zone.local(2016, 8, 3,  14, 28),
      '08/04/16' => Time.zone.local(2016, 8, 4,  12, 45),
      '08/05/16' => Time.zone.local(2016, 8, 5,  9,  3)
    }.freeze

    STORE_CREDIT_PRIZE_AMOUNT = 100
    B2S_CODE = 'B2S2016'.freeze
    START_DATE1 = Time.zone.local(2016, 7, 25)
    END_DATE1   = Time.zone.local(2016, 7, 28)
    START_DATE2 = Time.zone.local(2016, 8, 1)
    END_DATE2   = Time.zone.local(2016, 8, 6)

    before_action :promotion_active?
    after_action :store_location, only: [:index]

    def index
    end

    def spin
      unless spree_current_user
        render json: { error: 'not_logged_in' }, status: 403
        return
      end

      if user_has_unused_coupons?
        render json: { error: 'pending_coupon' }
        return
      end

      date_string = Time.zone.now.strftime('%x')

      if STORE_CREDIT_WIN_TIMES[date_string] && Time.zone.now > STORE_CREDIT_WIN_TIMES[date_string] &&
         !store_credit_winner?(date_string)
        store_credit_category = ::Spree::StoreCreditCategory.find_by!(name: 'Promotion')
        store_credit_type = ::Spree::StoreCreditType.find_by!(name: 'Expiring')
        store_credit_creator = ::Spree::User.find_by!(email: 'support@hollar.com')

        ::Spree::StoreCredit.create!(user: spree_current_user,
                                     category: store_credit_category,
                                     amount: STORE_CREDIT_PRIZE_AMOUNT,
                                     currency: 'USD',
                                     credit_type: store_credit_type,
                                     memo: memo_for_store_credit(date_string),
                                     created_by: store_credit_creator)

        render json: { prize: 'store_credit' }
        return
      end

      prize = choose_prize

      promotion = create_prize_for_user(PRIZES[prize])
      ::Hollar::Spree::PromoCodeMailer.new(promotion, spree_current_user).send_promo_code

      render json: { prize: prize }
    end

    private

    def promotion_active?
      now = Time.zone.now
      render :unavailable unless (now >= START_DATE1 && now < END_DATE1) || (now >= START_DATE2 && now < END_DATE2)
    end

    def user_has_unused_coupons?
      promotion_category = ::Spree::PromotionCategory.find_by!(code: B2S_CODE)
      now = Time.zone.now

      user_promotions = ::Spree::Promotion.joins(<<-EOS
        inner join spree_promotion_categories
          on spree_promotions.promotion_category_id = spree_promotion_categories.id
        inner join spree_promotion_rules
          on spree_promotions.id = spree_promotion_rules.promotion_id
        inner join spree_promotion_rules_users
          on spree_promotion_rules.id = spree_promotion_rules_users.promotion_rule_id
        EOS
      ).where('spree_promotion_rules_users.user_id = ? and spree_promotions.expires_at > ?',
              spree_current_user.id, now)

      applied_order_promotions = ::Spree::Promotion.joins(order_promotions: :order).
                                 where('spree_promotions.promotion_category_id = ? and spree_orders.user_id = ? and spree_promotions.expires_at > ?',
                                       promotion_category.id, spree_current_user.id, now).
                                 where.not('spree_orders.completed_at': nil)

      !(user_promotions - applied_order_promotions).empty?
    end

    def store_credit_winner?(date)
      store_credit_category = ::Spree::StoreCreditCategory.find_by!(name: 'Promotion')
      ::Spree::StoreCredit.find_by(category: store_credit_category,
                                   memo: memo_for_store_credit(date))
    end

    def memo_for_store_credit(date)
      "B2S2016: Store Credit Winner #{date}"
    end

    def choose_prize
      last_order = spree_current_user.orders.complete.order(:completed_at).last
      eligible_prizes = nil

      if last_order
        if last_order.completed_at < 60.days.ago
          eligible_prizes = PRIZE_PROBABILITIES[:lapsed_buyer]
        else
          eligible_prizes = PRIZE_PROBABILITIES[:active_buyer]
        end
      else
        eligible_prizes = PRIZE_PROBABILITIES[:non_buyer]
      end

      i = Random.rand(eligible_prizes.values.sum)
      current = 0

      eligible_prizes.each do |k, v|
        current += v
        return k if i < current
      end
    end

    def create_prize_for_user(prize_entry)
      promotion_category = ::Spree::PromotionCategory.find_by!(code: B2S_CODE)

      base_options = {
        expires_at: Time.zone.now.beginning_of_day + 7.days,
        promotion_category: promotion_category,
        name: prize_entry[:name]
      }

      promotion = ::Spree::Promotion.new(base_options)

      promotion_code = ::Spree::PromotionCode.new(value: ::Spree::PromotionCode.generate_unique_code)
      promotion.codes << promotion_code

      promotion.promotion_rules.build(
        promotion: promotion,
        type: 'Spree::Promotion::Rules::ItemTotal',
        preferences: { amount: BigDecimal.new(prize_entry[:min]), operator: 'gte' }
      )

      promotion.promotion_rules.build(
        promotion: promotion,
        type: 'Spree::Promotion::Rules::OneUsePerUser'
      )

      user_rule = ::Spree::PromotionRule.new(promotion: promotion, type: 'Spree::Promotion::Rules::User')
      promotion.promotion_rules << user_rule
      promotion.save!

      ::Spree::PromotionRuleUser.create(promotion_rule: user_rule, user: spree_current_user)

      if prize_entry[:type] == :pct
        create_pct_prize(promotion, prize_entry[:off])
      else
        create_usd_prize(promotion, prize_entry[:off])
      end

      promotion
    end

    def create_pct_prize(promotion, pct)
      calculator = ::Spree::Calculator::FlatPercentItemTotal.new(
        preferences: { flat_percent: BigDecimal(-pct) }
      )

      ::Spree::PromotionAction.create!(
        promotion: promotion,
        type: 'Spree::Promotion::Actions::CreateAdjustment',
        calculator: calculator
      )
    end

    def create_usd_prize(promotion, usd)
      calculator = ::Spree::Calculator::FlatRate.new(
        preferences: { amount: BigDecimal(-usd), currency: 'USD' }
      )

      ::Spree::PromotionAction.create!(
        promotion: promotion,
        type: 'Spree::Promotion::Actions::CreateAdjustment',
        calculator: calculator
      )
    end
  end
end
