module Spree
  class EarnsController < Spree::StoreController
    skip_before_action :set_current_order

    def show
      unless spree_current_user
        store_location
        flash[:error] = "You must be logged in"
        redirect_to login_path
        return
      end
    end
  end
end
