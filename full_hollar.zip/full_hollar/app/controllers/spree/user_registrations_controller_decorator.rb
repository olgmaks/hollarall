module Hollar
  module Spree
    module Controllers
      module UserRegistrationsControllerDecorator
        protected

        def build_resource(spree_user_params)
          super
          @spree_user.apply_omniauth(session[:omniauth]) if session[:omniauth]
          @spree_user.referral_invite_code = params[:invite_code] if params[:invite_code]
          @spree_user
        end

        def associate_user
          tag_attribution
          super
        end

        def create
          # save return-to page for in-flow registrations
          unless request.referer.nil? or [spree.signup_path, spree.login_path].include? URI(request.referer).path
            session[:spree_user_return_to] ||= request.referer
          end
          super
        end

        def tag_attribution
          return unless try_spree_current_user && cookies[Rack::Utm::USER_COOKIE_NAME]

          Hollar::Spree::Attributions::Create.new(
            self, try_spree_current_user, cookie: Rack::Utm::USER_COOKIE_NAME
          ).call
        end
      end
    end
  end
end

::Spree::UserRegistrationsController.prepend ::Hollar::Spree::Controllers::UserRegistrationsControllerDecorator
