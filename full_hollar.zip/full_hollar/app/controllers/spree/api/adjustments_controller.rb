module Spree
  module Api
    class AdjustmentsController < BaseController
      before_action :authorize_order!

      def destroy
        remove_promotion! if adjustment

        head :no_content
      end

      private

      def authorize_order!
        authorize! :update, current_order
      end

      def remove_promotion!
        handler.remove(adjustment)
      end

      def adjustment
        @adjustment ||= current_order.adjustments.find(params[:id])
      end

      def current_order
        @current_order ||= Spree::Order.find_by(number: params[:order_id])
      end

      def handler
        @handler ||= PromotionHandler::Coupon.new(current_order)
      end
    end
  end
end
