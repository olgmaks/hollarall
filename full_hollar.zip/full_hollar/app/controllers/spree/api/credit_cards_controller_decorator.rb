module Hollar
  module Spree
    module Api
      module Controllers
        module CreditCardsControllerDecorator
          ANDROID_PAYPAL_SUPPORTED_VERSION = Gem::Version.new('1.0.15')
          BRAINTREE_CREDIT_CARD_TYPES = %w(visa master-card american-express diners-club discover jcb unionpay maestro).freeze

          def index
            @credit_cards = user.
                            credit_cards.
                            joins(:payment_method).
                            accessible_by(current_ability, :read).
                            with_payment_profile

            if legacy_client?
              @credit_cards = @credit_cards.where.not(cc_type: 'paypal').
                              where(payment_method_id: legacy_payment_method.id)
            else
              @credit_cards = @credit_cards.where(payment_method_id: solidus_payment_method.id)
            end

            @credit_cards = credit_cards_for_cc_type(@credit_cards, params[:cc_type])
            @credit_cards = @credit_cards.page(params[:page]).per(params[:per_page])
            respond_with(@credit_cards)
          end

          private

          def legacy_client?
            # api_version 3 and below or android version 1.0.14 and below
            return true if derived_version.blank?

            app_platform = params[:app_platform]
            app_version = Gem::Version.new(params[:app_version] || 0)

            derived_version <= 3 &&
              (app_platform != 'android' || (app_platform == 'android' && (app_version <=> ANDROID_PAYPAL_SUPPORTED_VERSION) < 0))
          end

          def credit_cards_for_cc_type(credit_cards, cc_type)
            return credit_cards if cc_type.blank?

            case cc_type
            when 'cc'
              credit_cards.where(cc_type: BRAINTREE_CREDIT_CARD_TYPES)
            else
              credit_cards.where(cc_type: cc_type)
            end
          end

          def legacy_payment_method
            ::Spree::PaymentMethod.find_by!(type: 'Spree::Gateway::BraintreeGateway')
          end

          def solidus_payment_method
            ::Spree::PaymentMethod.find_by!(type: 'Solidus::Gateway::BraintreeGateway')
          end
        end
      end
    end
  end
end

::Spree::Api::CreditCardsController.prepend ::Hollar::Spree::Api::Controllers::CreditCardsControllerDecorator
