module Hollar
  module Spree
    module Api
      module Controllers
        module LineItemsControllerDecorator
          def create
            if params[:app_platform] == 'ios'
              variant = ::Spree::Variant.find(params[:line_item][:variant_id])
              order_rules = OrderCheckoutRules.new(@order, @current_api_user)
              max_product_by_group_errors = order_rules.verify_would_hit_max_by_group(variant.id, params[:line_item][:quantity].to_i)

              if max_product_by_group_errors.any?
                # iOS hack - need to provide existing error code
                max_product_by_group_errors.first[:code] = ErrorCode::ORDER_MAX_PRODUCT_PER_ORDER_HIT
                render 'api/errors/show', status: :unprocessable_entity, locals: { errors: max_product_by_group_errors }
                return
              end
            end

            super
          end

          def update
            if params[:app_platform] == 'ios'
              @line_item = find_line_item
              if @order.contents.update_cart(line_items_attributes)
                @line_item.reload

                order_rules = OrderCheckoutRules.new(@order, @current_api_user)
                max_product_by_group_errors = order_rules.verify_max_by_group

                if max_product_by_group_errors.any?
                  order_checkout_solver = OrderCheckoutSolver.new(@order, @errors)
                  order_checkout_solver.solve_max_product_per_group_error

                  # iOS hack - need to provide existing error code
                  max_product_by_group_errors.first[:code] = ErrorCode::ORDER_MAX_PRODUCT_PER_ORDER_HIT
                  render 'api/errors/show', status: :unprocessable_entity, locals: { errors: max_product_by_group_errors }
                else
                  respond_with(@line_item, default_template: :show)
                end
              else
                invalid_resource!(@line_item)
              end
            else
              super
            end
          end
        end
      end
    end
  end
end

::Spree::Api::LineItemsController.prepend ::Hollar::Spree::Api::Controllers::LineItemsControllerDecorator
