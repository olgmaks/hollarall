module Hollar
  module Spree
    module Api
      module Controllers
        module TaxonomiesControllerDecorator
          def self.prepended(base)
            base.skip_before_action :authenticate_user, only: [:index, :show, :fast_index]
          end

          private

          def taxonomies
            @taxonomies = ::Spree::Taxonomy.accessible_by(current_ability, :read).
                          published.
                          order('name').
                          includes(root: :children).
                          displayable_on(params[:app_platform]).
                          ransack(params[:q]).result.
                          page(params[:page]).per(params[:per_page])
          end
        end
      end
    end
  end
end

::Spree::Api::TaxonomiesController.prepend ::Hollar::Spree::Api::Controllers::TaxonomiesControllerDecorator
