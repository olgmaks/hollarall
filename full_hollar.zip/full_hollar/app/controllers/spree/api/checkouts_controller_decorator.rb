module Hollar
  module Spree
    module Api
      module Controllers
        module CheckoutsControllerDecorator
          # NOTE(cab): This is used for API < V3
          include CartValidations

          def self.prepended(base)
            base.before_action :verify_cart_errors, only: [:update, :complete]
            base.skip_before_action :authenticate_user, only: [:verify_address]

            base.rescue_from ::TaxCloud::Errors::ApiError do |exception|
              base.logger.error(::Spree.t("address_verification_failed"))
              base.logger.error exception.backtrace.join "\n"
              @order.errors.add(:base, ::Spree.t("state_zipcode_mismatch"))
              respond_with(@order, default_template: 'spree/api/orders/could_not_transition', status: 422)
            end
          end

          def complete
            authorize! :update, @order, order_token
            if !expected_total_ok?(params[:expected_total])
              respond_with(@order, default_template: 'spree/api/orders/expected_total_mismatch', status: 400)
            else
              update_channel_for_order(@order, params[:app_platform])
              @order.complete!
              respond_with(@order, default_template: 'spree/api/orders/show', status: 200)
            end
          rescue StateMachines::InvalidTransition => e
            logger.error("invalid_transition #{e.event} from #{e.from} for #{e.object.class.name}. Error: #{e.inspect}")
            logger.error e.backtrace.join "\n"
            respond_with(@order, default_template: 'spree/api/orders/could_not_transition', status: 422)
          end

          def update
            order = ::Spree::Order.find_by!(number: params[:id])

            if derived_version < 3
              errors = []

              order.line_items.each do |li|
                next if li.quantity == 0
                qty_error = error_for_adding_product(li.variant_id, li.quantity, current_api_user, order)

                if qty_error
                  order.errors.add(:base, qty_error[:long_message])
                  errors << qty_error[:long_message]
                end
              end

              min_error = error_for_min_checkout(order)

              if min_error
                order.errors.add(:base, min_error[:long_message])
                errors << min_error[:long_message]
              end

              unless errors.empty?
                respond_to do |format|
                  format.all do
                    render 'spree/api/orders/could_not_transition', status: :unprocessable_entity,
                                                                    locals: { order: order }
                  end
                end

                return
              end
            end
            update_channel_for_order(order, params[:app_platform])

            super
          end

          def verify_address
            address = USPS::Address.new address1: params[:address1], address2: params[:address2], city: params[:city],
                                        state: params[:state], zip: params[:zipcode]

            @response = { address_matched: false }

            begin
              USPS.username = Hollar::Config.usps_username
              usps_response = USPS::Request::AddressStandardization.new(address).send!
            rescue USPS::AddressNotFoundError
              @response[:error] = 'address_not_found'
              return
            rescue StandardError => e
              @response[:error] = e
              return
            end

            if usps_response[address]['return_text'] =~ /more information is needed/
              @response[:error] = 'address_incomplete'
            end

            # we only check if zip code is mismatched for now
            @response[:address_matched] = address.zip.strip == usps_response[address]['zip5'] ||
                                          address.zip.strip == "#{usps_response[address]['zip5']}-#{usps_response[address]['zip4']}"

            @response[:verified_address] = usps_response[address]
          end

          def advance
            authorize! :update, @order, order_token
            order_rules = ::OrderCheckoutRules.new(@order, current_api_user)
            errors = order_rules.verify_against_all_rules

            if errors.any?
              ::OrderCheckoutSolver.new(@order, errors).auto_solve
            end

            @order.contents.advance

            errors.each do |e|
              @order.errors.add(:base, e[:full_message])
            end

            respond_with(@order, default_template: 'spree/api/orders/show', status: 200)
          end

          private

          def update_channel_for_order(order, channel)
            channel = 'mobile' if channel.blank?
            order.update_attribute(:channel, channel)
          end

          def verify_cart_errors
            order = ::Spree::Order.find_by!(number: params[:id])

            if derived_version >= 3

              order_rules = ::OrderCheckoutRules.new(order, current_api_user)
              errors = order_rules.verify_against_all_rules

              if errors.any?
                ::OrderCheckoutSolver.new(@order, errors).auto_solve

                respond_to do |format|
                  format.all { render 'api/errors/show', status: :unprocessable_entity, locals: { errors: errors } }
                end

                return
              end
            end
          end
        end
      end
    end
  end
end

::Spree::Api::CheckoutsController.prepend ::Hollar::Spree::Api::Controllers::CheckoutsControllerDecorator
