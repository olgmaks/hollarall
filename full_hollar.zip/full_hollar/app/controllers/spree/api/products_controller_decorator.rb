module Hollar
  module Spree
    module Api
      module Controllers
        module ProductsControllerDecorator
          def self.prepended(base)
            base.skip_before_action :authenticate_user, only: [:index, :landing, :show, :liked_by_current_user,
                                                               :likes, :like]
            base.include SearchFilters
            base.include SearchMerchandising
          end

          def liked_by_current_user
            @user = current_spree_user || current_api_user
            respond_with(@user.try(:liked_products))
          end

          # Respond with JSON in the form {"id": count, "id": count...} for quick downloading/parsing
          def likes
            @products = ::Spree::Product.where(id: params[:product_ids]).select(:id, :user_likes_count)
            respond_with(Hash[@products.map { |p| [p.id, p.user_likes_count] }], location: likes_api_products_url)
          end

          def like
            @product = ::Spree::Product.find_by(id: params[:product_id])
            @user    = current_spree_user || current_api_user

            if @user
              @like = Like.find_or_initialize_by(user: @user, product: @product)
              @like.new_record? ? @like.save : @like.destroy
              respond_with(@product.reload) # There's a problem with the counter cache & dependent: destroy for HMT
            else
              render json: { status: 401 }, status: 401
            end
          end

          def landing
            @user = current_spree_user || current_api_user

            per_page = params[:per_page] || 36

            params[:product_recommendation_basis] = get_recommendation_basis(current_api_user)

            @searcher = index_searcher(@user, params)
            product_results = @searcher.retrieve_products
            product_ids = product_results.map(&:id)
            product_taxon_ids = relevant_taxon_ids_from_results(product_results)

            if params[:product_recommendation_basis]
              product_ids = shuffle_in_new_products_in_taxons(current_api_user, product_ids, product_taxon_ids,
                                                              params.merge(per_page: per_page - (2 * per_page) / 3))
            end

            @products = load_products(product_ids,
                                      params,
                                      [:product_properties],
                                      option_types: :option_values,
                                      classifications: { taxon:
                                                         [:images, :published_children] },
                                      variants: :images)
            respond_with(@products)
          end

          def index
            if params[:ids]
              return super
            end

            @user = current_spree_user || current_api_user

            search_params = params.except(:q, :order_params)

            if params[:q].present?
              search_params[:keywords] = params[:q][:name_cont]
            end

            if params[:order_params].present?
              search_params[:order_params] = format_order_params(@user, true, params)
            end

            @searcher = ::Spree::Config.searcher_class.new(search_params)
            @searcher.searchkick_options = { where: default_filter(params[:app_platform], params[:merchant_id]) }
            @products = @searcher.retrieve_products
            expires_in 15.minutes, public: true
            headers['Surrogate-Control'] = "max-age=#{15.minutes}"

            if derived_version < 2
              respond_with(@products)
            else
              render 'landing'
            end
          end

          def refresh_recommendations
            ::Spree::User.invalidate_product_recommendation_model
            render json: { status: 200 }
          end
        end
      end
    end
  end
end

::Spree::Api::ProductsController.prepend ::Hollar::Spree::Api::Controllers::ProductsControllerDecorator
