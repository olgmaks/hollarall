module Spree
  module Api
    class InvitesController < Spree::Api::BaseController
      # TODO: The choice of a string of string separated emails
      # is a weird design choice when it should be easy to send a list
      # of emails instead.

      def create
        if emails.empty?
          render json: { error: 'Missing parameters' }, status: 400
        else
          send_emails!
        end
      end

      def on_email_sent(emails)
        @credit_potential = moneyfy(Spree::Invite.credit_potential(current_api_user))
        @credit_received = moneyfy(Spree::Invite.credit_received(current_api_user))

        @invites = Spree::Invite.sent_by(current_api_user).sent_to(emails).map do |invite|
          Spree::InvitePresenter.new(invite)
        end

        @issues = Hollar::Invites::IssuesPresenter.decorate_collection(invite_errors)
      end

      def index
        @credit_potential = moneyfy(Spree::Invite.credit_potential(current_api_user))
        @credit_received = moneyfy(Spree::Invite.credit_received(current_api_user))
        @invites = Spree::Invite.sent_by(current_api_user).sorted.map do |invite|
          Spree::InvitePresenter.new(invite)
        end
      end

      private

      def emails
        @emails ||= begin
          string_of_emails = params[:email] || ''

          string_of_emails.split(',').map(&:strip)
        end
      end

      def apply_policies
        @apply_policies ||= begin
          policies = emails.map { |email| invite_policy(current_api_user, email) }

          policies.partition(&:invitable?)
        end
      end

      def invitable_emails
        @invitable_emails ||= apply_policies.first.map(&:email)
      end

      def invite_errors
        @invite_errors ||= apply_policies.last.group_by(&:error)
      end

      def invite_policy(user, email)
        Hollar::Invites::CanReceiveInvite.new(user: user, email: email)
      end

      def send_emails!
        invite_code_mailer.send_email(current_api_user,
                                      invitable_emails,
                                      params[:message])
      end

      def invite_code_mailer
        ::Hollar::Spree::InviteCodeMailer.new(self)
      end

      def moneyfy(amount)
        Spree::Money.new(amount,
                         currency: Spree::Config[:currency],
                         no_cents_if_whole: true).to_s
      end
    end
  end
end
