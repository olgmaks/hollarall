# coding: utf-8
module Spree
  module Api
    class GiftCardOrdersController < ::Spree::Api::OrdersController
      skip_before_action :authenticate_user, only: [:index]

      def index
        @gift_cards = Spree::GiftCardProduct.first
        @delivery_methods = ShippingMethod.gift_cards

        respond_with @gift_cards
      end

      def create
        authorize! :create, Order
        remove_all_gift_card_orders_user
        @order = Spree::Core::Importer::Order.import(determine_order_user, order_params)
        assign_order_user
        assign_gift_card_to_order
        if @order.errors.empty?
          accelerate_state_to('address')
          assign_shipping_method
          respond_with(@order, default_template: :show, status: 201)
        else
          invalid_resource!(@order)
        end
      end

      def update
        authorize! :update, @order, order_token

        if @order.contents.update_cart(order_params)
          gift_card.update_attributes(gift_card_params) if params[:gift_card]
          @order.update_attributes(state: 'address')
          address_to_payment
          respond_with(@order, default_template: :show)
        else
          invalid_resource!(@order)
        end
      end

      private

      def gift_card_params
        params.require(:gift_card).permit(:gift_message, :recipient_name, :recipient_email,
                                          :send_email_at, :purchaser_name, :amount)
      end

      def assign_gift_card_to_order
        card = Spree::VirtualGiftCard.new(gift_card_params).tap do |gc|
          gc.currency = 'USD'
          gc.redemption_code = ::Spree::RedemptionCodeGenerator.generate_redemption_code
          gc.purchaser_id = @order.user_id
          if params['gift_card']['delivery_date'].present?
            gc.send_email_at = Date.strptime(params['gift_card']['delivery_date'], "%d/%m/%Y")
          end
        end
        if card.save
          @order.line_items.first.gift_cards.clear
          @order.line_items.first.gift_cards << card
          @order.line_items.first.update_attribute(:price, card.amount)
          @order.gift_card = true
        else
          @order.errors[:base].push(*card.errors[:base])
        end
      end

      def gift_card
        @order.line_items.first.gift_cards.first
      end

      def remove_all_gift_card_orders_user
        user_id = params['order']['user_id']
        ::Spree::Order.incomplete.where(user_id: user_id).giftcards.destroy_all
      end

      def assign_order_user
        return true unless @order.user_id.nil?
        @order.update_attribute(:user_id, params['order']['user_id'])
      end

      def move_order_to_shipping
        @order.next if @order.state == 'cart'
      end

      def assign_shipping_method
        shipment = @order.shipments.first
        delivery_method_id = params['gift_card']['delivery_method_id']
        shipping_method = ShippingMethod.gift_cards.where(id: delivery_method_id).first
        Spree::ShippingRate.create!(shipment: shipment, shipping_method: shipping_method, selected: true)
      end

      def address_to_payment
        return true if !@order.contains_gift_card? && !pre_payment
        @order.assign_billing_to_shipping_address if !@order.ship_address
        accelerate_state_to('payment')
      end

      def pre_payment
        @order.state == 'address' || @order.state == 'cart'
      end

      def accelerate_state_to(state)
        return true if @order.state == state
        @order.next!
        accelerate_state_to(state)
      end
    end
  end
end
