module Spree
  module Api
    class SignInsController < BaseController
      skip_before_action :authenticate_user
      skip_before_action :load_user
      skip_before_action :load_user_for_roles

      def create
        Hollar::Spree::Api::Authenticator.new(self, params[:email], params[:password]).authenticate
      end

      def on_user_signed_up(user)
        @user = user
        render template: "spree/api/sign_ups/create"
      end

      def on_user_not_found
        render json: { error: 'Email not found' }, status: 404
      end

      def on_no_match
        render json: { error: 'Email and password does not match' }, status: 403
      end
    end
  end
end
