module Hollar
  module Spree
    module Api
      module Controllers
        module AddressBooksControllerDecorator
          def show
            @user_addresses = @user_addresses.to_a.uniq do |a|
              Hash[a.address.value_attributes.map { |k, v| [k, v.to_s] }]
            end

            super
          end
        end
      end
    end
  end
end

::Spree::Api::AddressBooksController.prepend ::Hollar::Spree::Api::Controllers::AddressBooksControllerDecorator
