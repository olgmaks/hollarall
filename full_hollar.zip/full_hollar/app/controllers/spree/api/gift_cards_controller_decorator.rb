module Hollar
  module Spree
    module Api
      module Controllers
        module GiftCardsControllerDecorator
          def redeem
            redemption_code = ::Spree::RedemptionCodeGenerator.format_redemption_code_for_lookup(params[:redemption_code] || "")
            @gift_card = ::Spree::VirtualGiftCard.active_by_redemption_code(redemption_code)

            if !@gift_card
              render status: :not_found, json: redeem_fail_response
            elsif !@gift_card.redeemable
              render status: 422, json: redeem_fail_response
            elsif @gift_card.redeem(@current_api_user)
              render status: :created, json: { amount: @gift_card.amount, formatted_amount: @gift_card.formatted_amount }
            else
              render status: 422, json: redeem_fail_response
            end
          end
        end
      end
    end
  end
end
::Spree::Api::GiftCardsController.prepend ::Hollar::Spree::Api::Controllers::GiftCardsControllerDecorator
