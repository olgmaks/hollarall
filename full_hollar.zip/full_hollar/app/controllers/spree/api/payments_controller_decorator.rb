module Hollar
  module Spree
    module Api
      module Controllers
        module PaymentsControllerDecorator
          def new
            @payment_methods = ::Spree::PaymentMethod.limit_platform('api').available
            @payment_methods << ::Spree::PaymentMethod.mobile_payment_method
            respond_with(@payment_method)
          end
        end
      end
    end
  end
end

::Spree::Api::PaymentsController.prepend ::Hollar::Spree::Api::Controllers::PaymentsControllerDecorator
