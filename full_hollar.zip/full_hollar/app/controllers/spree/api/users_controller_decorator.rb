module Hollar
  module Spree
    module Api
      module Controllers
        module UsersControllerDecorator
          def me
            raise ActiveRecord::RecordNotFound unless current_api_user

            @user = @object = current_api_user
            respond_with(@object, default_template: 'spree/api/users/show', status: 200)
          end
        end
      end
    end
  end
end

::Spree::Api::UsersController.prepend ::Hollar::Spree::Api::Controllers::UsersControllerDecorator
