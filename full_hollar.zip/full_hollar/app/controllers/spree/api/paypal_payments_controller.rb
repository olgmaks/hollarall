module Spree
  module Api
    class PaypalPaymentsController < BaseController
      respond_to :json
      before_filter :load_order

      def create
        ::PaypalPayment::Create.new(self, @order, params[:id]).call
      end

      def on_paypal_payment_created
        respond_with(order,
                     default_template: 'spree/api/orders/show',
                     status: 200)
      end

      def on_paypal_error
        respond_with(order,
                     default_template: 'spree/api/orders/could_not_transition',
                     status: 422)
      end

      private
      attr_accessor :order

      def load_order
        @order = Spree::Order.find_by!(number: params[:order_id])
      end


    end
  end
end
