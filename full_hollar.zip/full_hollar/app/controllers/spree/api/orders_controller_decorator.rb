module Hollar
  module Spree
    module Api
      module Controllers
        module OrdersControllerDecorator
          def self.prepended(base)
            base.skip_before_action :find_order, only: :can_add_product_to_cart
            base.skip_around_filter :lock_order, only: :can_add_product_to_cart
            base.skip_before_action :authenticate_user
            base.wrap_parameters false
            base.rescue_from ::TaxCloud::Errors::ApiError do |exception|
              base.logger.error(::Spree.t("address_verification_failed"))
              base.logger.error exception.backtrace.join "\n"
              @order.errors.add(:base, ::Spree.t("state_zipcode_mismatch"))
              respond_with(@order, default_template: 'spree/api/orders/could_not_transition', status: 422)
            end
          end

          def show
            authorize! :show, @order, order_token

            respond_with(@order)
          end

          def create
            authorize! :create, ::Spree::Order
            order_user = if order_params[:user_id]
                           ::Spree.user_class.find(order_params[:user_id])
                         else
                           current_api_user
                         end

            @order = ::Spree::Core::Importer::Order.import(order_user, order_params)
            update_channel_for_order(@order, params[:app_platform])
            respond_with(@order, default_template: :show, status: 201)
          end

          def update
            authorize! :update, @order, order_token
            update_channel_for_order(@order, params[:app_platform])

            super
          end

          def apply_coupon_code
            authorize! :update, @order, order_token
            update_channel_for_order(@order, params[:app_platform])
            if params[:coupon_code].strip.empty?
              @order.remove_coupon_code
              render json: {
                success: "The coupon code was successfully removed from your order.",
                error: nil,
                successful: true,
                status_code: "coupon_code_removed"
              }
            else
              super
            end
          end

          def complete
            ::PaypalPayment::Capture.new(self, order).call if order.payments.paypal_mobile.any?
            super
          end

          def current
            @order = current_api_user &&
                     current_api_user.last_incomplete_order_without_gift_cards(store: current_store)

            if @order
              respond_with(@order, default_template: :show, locals: { root_object: @order })
            else
              head :no_content
            end
          end

          private

          def update_channel_for_order(order, channel)
            channel = 'mobile' if channel.blank?
            order.update_attribute(:channel, channel)
          end
        end
      end
    end
  end
end

::Spree::Api::OrdersController.prepend ::Hollar::Spree::Api::Controllers::OrdersControllerDecorator
