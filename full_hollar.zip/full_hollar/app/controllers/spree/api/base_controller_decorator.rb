module Hollar
  module Spree
    module Api
      module Controllers
        module BaseControllerDecorator
          def self.prepended(base)
            base.before_action :update_user_access
          end

          def lock_order
            ::Spree::OrderMutex.with_lock!(@order) { yield }
          rescue ::Spree::OrderMutex::LockFailed => e
            render json: { error: e.message }, status: 409
          end

          private

          def update_user_access
            platform = request.headers['HTTP_APP_PLATFORM'] || params[:app_platform]
            version = request.headers['HTTP_APP_VERSION'] || params[:app_version]
            @current_api_user.update_user_access(platform, version) if @current_api_user && platform
          end
        end
      end
    end
  end
end

::Spree::Api::BaseController.prepend ::Hollar::Spree::Api::Controllers::BaseControllerDecorator
