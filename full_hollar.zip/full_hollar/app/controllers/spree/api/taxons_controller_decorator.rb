module Hollar
  module Spree
    module Api
      module Controllers
        module TaxonsControllerDecorator
          def self.prepended(base)
            base.skip_before_action :authenticate_user, only: [:index, :show, :products]

            base.include SearchFilters
            base.include SearchMerchandising
          end

          def index
            if taxonomy
              @taxons = taxonomy.root.children.published.accessible_by(current_ability, :read).
                        displayable_on(params[:app_platform])
            elsif params[:ids]
              @taxons = taxon_scope.where(id: params[:ids].split(','))
            else
              @taxons = taxon_scope.order(:taxonomy_id, :lft).ransack(params[:q]).result
            end

            @taxons = @taxons.page(params[:page]).per(params[:per_page])
            respond_with(@taxons)
          end

          def merchant
            taxon_ids = Searchkick::Query.new(::Spree::Product,
                                            body: { size: 0, query: { match_all: {} },
                                                    "from": 0, "sort":{},
                                                    "post_filter":{ "bool":{ "filter":[{ "term":{ "merchant_id": params[:merchant_id] } }] } },
                                                    aggs: { brand_count: { terms: { field: "taxon_ids" } } } }
                                           ).execute.response["aggregations"]["brand_count"]["buckets"]
            main_taxons = ::Spree::Taxon.where(parent_id: ::Spree::Taxon.find_by(permalink: "category").id).pluck(:id)
            taxon_ids = taxon_ids.map { |t| t["key"] unless main_taxons.include?(t["key"]) }.compact
            @taxons = ::Spree::Taxon.where(id: taxon_ids).where(parent_id: main_taxons).group(:parent_id)
            @taxons = @taxons.page(params[:page]).per(params[:per_page])
            render "index"
          end

          def products
            @user = current_spree_user || current_api_user

            @products = []
            extra_params = {}

            if params[:q].present?
              extra_params[:keywords] = params[:q][:name_cont]
            end

            if params[:q].blank?
              extra_params[:order_params] = { "taxon_#{taxon.id}_position".to_sym =>
                                              { order: :asc, unmapped_type: 'integer' } }
            end

            if params[:order_params].present?
              extra_params[:order_params] = format_order_params(@user, false, params)
            end

            searcher_params = params.except(:q, :id, :format, :controller, :action).merge(keywords: params[:q])
            searcher_params.merge!(extra_params)

            @searcher = ::Spree::Config.searcher_class.new(searcher_params)
            @searcher.searchkick_options = { where: default_filter(params[:app_platform], params[:merchant_id]).
                                           merge(taxon_ids: [taxon.id]) }
            @products = @searcher.retrieve_products

            if derived_version < 2
              render "spree/api/products/index"
            else
              render 'spree/api/products/taxon_products'
            end
          end

          private

          def taxon
            @taxon ||= begin
              if params[:id]
                @taxon = taxon_scope.find(params[:id])
              else
                @taxon = taxon_scope.find_by!(permalink: params[:permalink])
              end
            end
          end

          def taxon_scope
            @taxon_scope ||= begin
              if current_ability.can? :manage, ::Spree::Taxon
                ::Spree::Taxon.accessible_by(current_ability, :read).
                  displayable_on(params[:app_platform])
              else
                ::Spree::Taxon.published.accessible_by(current_ability, :read).
                  displayable_on(params[:app_platform])
              end
            end
          end

          def taxon_product_scope(taxon_id)
            cl_table_name = ::Spree::Classification.table_name.to_sym
            taxon_product_scope = product_scope.joins(:classifications).where(cl_table_name => { taxon_id: taxon_id })
            taxon_product_scope.order("#{cl_table_name}.position ASC")
          end

          def products_of_children(taxon, products)
            taxon.children.each do |child|
              next unless child.published
              next unless child.displayable_on?(params[:app_platform])

              products += taxon_product_scope(child.id).ransack(params[:q]).result
              products_of_children(child, products)
            end

            products
          end

          def first_level_taxon?
            taxon.parent_id.nil?
          end

          def paginate_array(array, page, per_page = 25)
            ::Kaminari.paginate_array(array).page(page).per(per_page)
          end
        end
      end
    end
  end
end

::Spree::Api::TaxonsController.prepend ::Hollar::Spree::Api::Controllers::TaxonsControllerDecorator
