module Hollar
  module Spree
    module Api
      module Controllers
        module StatesControllerDecorator

          private

          def scope
            finder_scope = super.where(active: true)

            case params[:address_type]
            when 'shipping'
              return finder_scope.where(shipping: true)
            when 'billing'
              return finder_scope.where(billing: true)
            else
              finder_scope
            end
          end

        end
      end
    end
  end
end

::Spree::Api::StatesController.prepend ::Hollar::Spree::Api::Controllers::StatesControllerDecorator
