module Spree
  module Api
    class TaxonGroupsController < Spree::Api::BaseController
      respond_to :json
      helper_method :taxon_groups

      private

      def taxon_groups
        @taxon_groups ||= Spree::TaxonGroup.includes(:taxons) + [ungrouped]
      end

      def ungrouped
        @ungrouped = Spree::Taxon.find_by(permalink: 'category').published_children.ungrouped
      end
    end
  end
end

