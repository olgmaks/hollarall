module Spree
  module Api
    class SignUpsController < ::Spree::Api::BaseController
      skip_before_action :authenticate_user
      skip_before_action :load_user
      skip_before_action :load_user_for_roles

      def create
        Hollar::Spree::Api::Registrar.new(self, user_params).create
      end

      def fb_create
        Hollar::Spree::Api::Registrar.new(self, fb_user_params).create_from_facebook
      end

      def on_user_creation_success(user)
        @user = user
        render :create
      end

      def on_facebook_signin(user)
        @user = user
        render :create
      end

      def on_user_creation_fail(message)
        render json: message, status: 401
      end

      private

      def user_params
        params.require(:user).permit(:first_name, :last_name, :email, :password, :gender)
      end

      def fb_user_params
        params
      end
    end
  end
end
