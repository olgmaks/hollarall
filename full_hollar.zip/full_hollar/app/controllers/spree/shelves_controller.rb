module Spree
  class ShelvesController < Spree::StoreController
    def index
      @shelves = Shelf.where(group: params[:group_id].to_i).all
    end
  end
end
