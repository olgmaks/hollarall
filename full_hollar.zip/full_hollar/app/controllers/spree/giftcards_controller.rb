module Spree
  class GiftcardsController < Spree::StoreController
    before_action :set_redirect, only: :redeem, unless: :spree_user_signed_in?

    def redeem
      if spree_current_user
        redirect_to account_path + '?redeem'
      end
    end

    def print
      @card = ::Spree::VirtualGiftCard.find_by(redemption_code: params['id'])
      redirect_to user_root_path if !@card || current_spree_user != @card.purchaser
    end

    def destroy
      # NOTE(cab): At this moment, there can only be one line_item per order of type gift_card.
      # This object will also always be a gift_card.
      giftcard_product = ::Spree::Product.find_by(slug: 'gift-card')
      @card = ::Spree::VirtualGiftCard.find(params['id'])
      @card.line_item.delete if @card.destroy
      redirect_to product_path(giftcard_product)
    end

    def toggle_redeemable
      @card = ::Spree::VirtualGiftCard.find(params[:id])
      redirect_to :back and return if @card.redeemed?

      @card.redeemable = !@card.redeemable

      if @card.update(@card.attributes)
        flash[:success] = 'Gift Card redeemable toggled successfully'
      else
        flash[:error] = 'Unable to toggle the redeemable property'
      end

      redirect_to :back
    end

    private

    def set_redirect
      store_location_for(:spree_user, gift_cards_redeem_url)
    end
  end
end
