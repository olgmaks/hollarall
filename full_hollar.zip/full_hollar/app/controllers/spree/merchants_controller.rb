module Spree
  class MerchantsController < Spree::StoreController
    include SearchFilters
    include SearchMerchandising

    def show
      @merchant = ::Merchant.friendly.find(params[:id])
      per_page = params[:per_page] || 36
      extra_params = { include_images: true, per_page: (2 * per_page) / 3 }
      if params[:order_params].present?
        extra_params[:order_params] = format_order_params(spree_current_user, true, params)
      end
      @searcher = build_searcher(params.merge(extra_params))
      @searcher.searchkick_options = { where: default_filter('web', params[:id]) }
      @products = @searcher.retrieve_products
      taxon_ids = Searchkick::Query.new(::Spree::Product,
                                        body: { size: 0, query: { match_all: {} },
                                                "from": 0, "sort": {},
                                                "post_filter": { "bool": { "filter": [
                                                  { "term": { "merchant_id": params[:id] } }
                                                ] } },
                                                aggs: { brand_count: { terms: { field: "taxon_ids" } } } }).
                  execute.response["aggregations"]["brand_count"]["buckets"]
      main_taxons = ::Spree::Taxon.where(parent_id: ::Spree::Taxon.find_by(permalink: "category").id).pluck(:id)
      taxon_ids = taxon_ids.map { |t| t["key"] unless main_taxons.include?(t["key"]) }.compact
      @taxons = ::Spree::Taxon.where(id: taxon_ids).where(parent_id: main_taxons)
    end
  end
end
