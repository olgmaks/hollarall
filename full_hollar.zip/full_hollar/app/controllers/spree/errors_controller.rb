module Spree
  class ErrorsController < ActionController::Base
    def show
      status_code = params[:code] || '500'

      if status_code == '500'
        render '500', status: status_code
      else
        render file: "#{Rails.root}/public/#{status_code}.html", status: status_code
      end
    end
  end
end
