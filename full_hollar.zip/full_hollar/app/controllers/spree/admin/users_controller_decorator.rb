module Hollar
  module Spree
    module Admin
      module Controllers
        module UsersControllerDecorator
          def edit
            @referer = ::Spree::User.where(invite_code: @user.referral_invite_code).first
            super
          end

          def one_time_password
            new_password = [*('a'..'z'), *('0'..'9')].sample(10).join
            @user.impersonatable_password = new_password
            @user.save!

            flash[:one_time_password] = new_password
            redirect_to edit_admin_user_path(@user, anchor: 'admin_user_edit_impersonatable')
          end

          private

          def user_params
            attributes = permitted_user_attributes
            if action_name == "create" || can?(:update_email, @user)
              attributes |= [:email]
            end

            if can? :manage, ::Spree::Role
              attributes += [{ spree_role_ids: [] }]
            end

            if params[:user] && params[:user][:password] && params[:user][:password].empty?
              params[:user].delete_if { |key| key =~ /password/i }
            end
            params.require(:user).permit(attributes)
          end
        end
      end
    end
  end
end

::Spree::Admin::UsersController.prepend ::Hollar::Spree::Admin::Controllers::UsersControllerDecorator
