module Spree
  module Admin
    class FeatureExperimentsController < ::Spree::Admin::ResourceController
      protected

      def build_resource
        feature_experiment = super
        feature_experiment.source = "Optimizely"
        feature_experiment.enabled = true
        feature_experiment
      end

      def model_class
        FeatureExperiment
      end
    end
  end
end
