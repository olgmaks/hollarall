module Spree
  module Admin
    class ShelfGroupsController < ::Spree::Admin::BaseController
      helper_method :shelf_group

      def new
        @shelf_group = ShelfGroup.new
      end

      def create
        @shelf_group = ShelfGroup.new(permitted_params)

        if @shelf_group.save
          flash[:success] = Spree.t(:successfully_created, resource: Spree.t(:shelf_group))
          redirect_to spree.admin_shelves_path
        else
          flash[:error] = @shelf_group.errors.full_messages.first
          render :new
        end
      end

      def update
        if shelf_group.update(permitted_params)
          redirect_to admin_shelves_path
        else
          flash[:error] = @shelf_group.errors.full_messages.first
          render :edit
        end
      end

      def destroy
        shelf_group.destroy

        head :no_content
      end

      protected

      def shelf_group
        @shelf_group = ShelfGroup.find(params[:id])
      end

      def permitted_params
        params.require(:shelf_group).permit(
          :name, :permalink, :menu_icon, :published,
          :position, :hex_code, :banner_image
        )
      end
    end
  end
end
