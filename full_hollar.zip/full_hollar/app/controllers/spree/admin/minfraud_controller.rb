module Spree
  module Admin
    class MinfraudController < Spree::Admin::BaseController
      def update
        Hollar::Config.set(minfraud_enabled: params[:minfraud_enabled])
        Hollar::Config.set(minfraud_threshold: params[:minfraud_threshold].to_f)
        Hollar::Config.set(minfraud_ip_address: params[:minfraud_ip_address])
        Hollar::Config.set(minfraud_use_ip: params[:minfraud_use_ip])

        flash[:success] = "Minfraud configuration has been successfully changed"
        redirect_to :back
      end
    end
  end
end
