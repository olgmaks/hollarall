module Spree
  module Admin
    class ShipmentsController < ::Spree::Admin::BaseController
      def clone
        shipment = ::Spree::Shipment.find_by(number: params[:id])
        cloned   = ::OrderCloningService.new(
          source:  shipment.order,
          items:   shipment.line_items,
          creator: try_spree_current_user
        ).perform

        redirect_to cart_admin_order_path(cloned)
      end
    end
  end
end
