module Spree
  module Admin
    class ShelfProductStylesController < ::Spree::Admin::BaseController
      helper_method :shelf_product_style, :shelf_product_styles

      def new
        @shelf_product_style = ::ShelfProductStyle.new
      end

      def create
        @shelf_product_style = ::ShelfProductStyle.new(permitted_params)

        if @shelf_product_style.save
          flash[:success] = Spree.t(:successfully_created, resource: Spree.t(:shelf_product_style))
          redirect_to spree.admin_shelf_product_styles_path
        else
          flash[:error] = @shelf_product_style.errors.full_messages.first
          render :new
        end
      end

      def destroy
        shelf_product_style.destroy
        redirect_to action: 'index'
      end

      def update
        shelf_product_style.update(permitted_params)
        redirect_to action: 'edit'
      end


      protected

      def shelf_product_style
        @shelf_product_style ||= ::ShelfProductStyle.find(params[:id])
      end

      def shelf_product_styles
        @shelf_product_styles ||= ::ShelfProductStyle.all
      end

      def permitted_params
        params.require(:shelf_product_style).permit(:product_id, :shelf_id, :image)
      end
    end
  end
end

