module Spree
  module Admin
    module Users
      class CommentsController < ::Spree::Admin::BaseController
        before_filter :load_user, only: [ :index ]
        before_filter :init_new_comment, only: [ :index ]

        def index
          @comments = ::Spree::Comment.where(user_id: user.id).order(created_at: :desc)
        end

        def create
          comment = ::Spree::Comment.new(comment_params
                                         .merge(user_id: params[:id],
                                                customer_service_id: current_spree_user.id))
          respond_to do |with|
            if comment.save
              with.js { render json: comment, status: 201 }
            else
              with.js { render json: { error: Spree.t('comments.creation.error') } , status: 422 }
            end
          end
        end

        private

        attr_reader :user

        def comment_params
          params.require(:comment).permit(:text, :channel, :comment_type, :reason, :detailed_reason)
        end

        def load_user
          @user = ::Spree::User.find(params[:user_id])
        end

        def init_new_comment
          @new_comment = repositories[:comment].new
        end
      end
    end
  end
end
