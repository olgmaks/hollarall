module Spree
  module Admin
    module Users
      class CreditCardsController < ::Spree::Admin::BaseController
        before_filter :load_user

        def index
          @credit_cards = @user.credit_cards.order(created_at: :desc).page(params[:page]).per(params[:per_page])
        end

        def destroy
          @credit_card = @user.credit_cards.find(params[:id])
          @credit_card.update_attribute(:user_id, nil)

          flash[:success] = 'Payment method has been deleted'

          respond_with(@credit_card) do |format|
            format.html { redirect_to admin_user_credit_cards_path(@user) }
            format.js  { render_js_for_destroy }
          end
        end

        private

        def load_user
          @user = ::Spree::User.find(params[:user_id])
        end
      end
    end
  end
end
