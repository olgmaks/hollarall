module Spree
  module Admin
    class PodsController < ResourceController
      def index
        session[:return_to] ||= request.url
        respond_with(@collection)
      end

      def show
        session[:return_to] ||= request.referer
        redirect_to action: :edit
      end

      def create
        invoke_callbacks(:create, :before)
        pod_creator.new(self, @object, permitted_resource_params).call
      end

      def on_pod_created(pod)
        @object = pod
        invoke_callbacks(:create, :after)
        respond_with(pod) do |format|
          format.html do
            flash[:success] = flash_message_for(@object, :successfully_created)
            redirect_to location_after_save
          end
          format.js { render layout: false }
        end
      end

      def on_pod_not_created(pod)
        @object = pod
        invoke_callbacks(:create, :fails)
        respond_with(pod) do |format|
          format.html do
            flash.now[:error] = @object.errors.full_messages.join(', ')
            redirect_to admin_pods_path
          end
          format.js { render layout: false }
        end
      end

      def update
        invoke_callbacks(:update, :before)
        reorder = @object.display_homepage.to_s != permitted_resource_params['display_homepage']
        pod_updator.new(self, @object, permitted_resource_params).call
        reorder_pods if reorder
      end

      def reorder_pods
        pods = Spree::Pod.where(display_homepage: true).order(:position)
        pods.each_with_index do |pod, idx|
          pod.update_attribute(:position, idx)
        end
      end

      def on_pod_updated(pod)
        @object = pod
        invoke_callbacks(:update, :after)
        respond_with(@object) do |format|
          format.html do
            flash[:success] = flash_message_for(@object, :successfully_updated)
            redirect_to location_after_save
          end
          format.js { render layout: false }
          format.json { head :ok }
        end
      end

      def on_pod_not_updated(pod)
        @object = pod
        invoke_callbacks(:update, :fails)
        respond_with(@object) do |format|
          format.html do
            flash.now[:error] = @object.errors.full_messages.join(', ')
            render_after_update_error
          end
          format.js { render layout: false }
        end
      end

      def update_positions
        JSON.parse(params[:pod_positions]).each do |pod_position|
          pod = Spree::Pod.find(pod_position['id'])
          pod.update_attribute(:position, pod_position['position'])
        end
        head :ok
      end

      protected

      def collection
        return @collection if @collection.present?
        params[:q] ||= {}
        params[:q][:deleted_at_null] ||= '1'
        params[:q][:s] ||= 'name asc'
        @collection = super
        if params[:q].delete(:deleted_at_null) == '0'
          @collection = @collection.with_deleted
        end
        # @search needs to be defined as this is passed to search_form_for
        @search = @collection.ransack(params[:q])
        @collection = @search.result.
                      page(params[:page]).
                      per(Spree::Config[:admin_products_per_page])

        @collection
      end

      def build_resource
        pod = Spree::Pod.new
        pod.build_image
        pod
      end

      def permitted_resource_params
        params.require(:pod).permit(:name,
                                    :viewable_name,
                                    :taxon_id,
                                    :taxon_destination_id,
                                    :display_homepage,
                                    :product_ids,
                                    :position,
                                    :url,
                                    image_attributes: [:alt, :attachment])
      end

      private

      def pod_creator
        Hollar::Spree::Pods::Create
      end

      def pod_updator
        Hollar::Spree::Pods::Update
      end
    end
  end
end
