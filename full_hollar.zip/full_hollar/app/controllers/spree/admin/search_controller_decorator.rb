module Hollar
  module Spree
    module Admin
      module SearchControllerDecorator
        def merchants
          if params[:ids]
            @merchants = Merchant.where(id: params[:ids].split(',').flatten)
          else
            @merchants = Merchant.ransack({
              m: 'or',
              name_start: params[:q]
            }).result.limit(10)
          end
        end
      end
    end
  end
end

::Spree::Admin::SearchController.prepend ::Hollar::Spree::Admin::SearchControllerDecorator
