module Hollar
  module Spree
    module Admin
      module Controllers
        module VariantsControllerParentDecorator
          def collection
            return parent.variants_including_master if parent_data.present?
            super
          end
        end
      end
    end
  end
end

::Spree::Admin::VariantsController.include ::Hollar::Spree::Admin::Controllers::VariantsControllerParentDecorator
