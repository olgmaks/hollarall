module Hollar
  module Spree
    module Admin
      module StoreCreditsControllerDecorator
        private

        def permitted_resource_params
          params.require(:store_credit).permit([:amount, :category_id, :memo, :expires_on]).
            merge(currency: ::Spree::Config[:currency], created_by: try_spree_current_user)
        end
      end
    end
  end
end

::Spree::Admin::StoreCreditsController.prepend ::Hollar::Spree::Admin::StoreCreditsControllerDecorator
