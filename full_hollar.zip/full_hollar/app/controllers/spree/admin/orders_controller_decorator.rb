module Hollar
  module Spree
    module Admin
      module Controllers
        module OrdersControllerDecorator
          def index
            query_present = params[:q]
            params[:q] ||= {}
            params[:q][:completed_at_not_null] ||= '1' if ::Spree::Config[:show_only_complete_orders_by_default]
            @show_only_completed = params[:q][:completed_at_not_null] == '1'
            params[:q][:s] ||= @show_only_completed ? 'completed_at desc' : 'created_at desc'

            # As date params are deleted if @show_only_completed, store
            # the original date so we can restore them into the params
            # after the search
            created_at_gt = params[:q][:created_at_gt]
            created_at_lt = params[:q][:created_at_lt]

            params[:q].delete(:inventory_units_shipment_id_null) if params[:q][:inventory_units_shipment_id_null] == "0"

            if params[:q][:created_at_gt].present?
              params[:q][:created_at_gt] = Time.zone.parse(params[:q][:created_at_gt]).beginning_of_day rescue ""
            end

            if params[:q][:created_at_lt].present?
              params[:q][:created_at_lt] = Time.zone.parse(params[:q][:created_at_lt]).end_of_day rescue ""
            end

            if @show_only_completed
              params[:q][:completed_at_gt] = params[:q].delete(:created_at_gt)
              params[:q][:completed_at_lt] = params[:q].delete(:created_at_lt)
            end

            @search = ::Spree::Order.not_risky.accessible_by(current_ability, :index).ransack(params[:q])

            # lazy loading other models here (via includes) may result in an invalid query
            # e.g. SELECT  DISTINCT DISTINCT "spree_orders".id, "spree_orders"."created_at" AS alias_0 FROM "spree_orders"
            # see https://github.com/spree/spree/pull/3919
            if query_present
              @orders = @search.
                          result(distinct: true).
                          page(params[:page]).
                          per(params[:per_page] || ::Spree::Config[:orders_per_page])
            else
              @orders = []
            end

            # Restore dates
            params[:q][:created_at_gt] = created_at_gt
            params[:q][:created_at_lt] = created_at_lt
          end

          def resend
            DelayedSend.perform_later(@order.email,
                                      ::EmailTemplateSelector.select_template(external_key['order_received']),
                                      mailer_attributes(@order))
            flash[:success] = ::Spree.t(:order_email_resent)

            redirect_to :back
          end

          def refresh_snapfulfil
            order = ::Spree::Order.find_by_number(params[:order_id])
            errors = []

            order.shipments.each do |shipment|
              updater = ::Snapfulfil::Shipment::Update.new(shipment)
              updater.update_shipping_details
              if updater.errors.any?
                errors << { number: shipment.number,
                            errors: updater.errors.join(' ') }
              end
            end

            if errors.empty?
              flash[:success] = ::Spree.t(:snapfulfil_update_sent)
            else
              flash[:error] = errors.map do |e|
                "Shipment #{e[:number]}: #{e[:errors]}"
              end.join '\n'
            end

            redirect_to :back
          end

          def risk_output
            @order = ::Spree::Order.find_by(number: params[:id])
            @assessment = @order.assessment
          end

          def release
            @order = ::Spree::Order.find_by(number: params[:id])
            @order.release(callee: try_spree_current_user)

            redirect_to :back
          end

          def approve
            # NOTE(cab): The admins are never using this buttons and they are
            # unsure what it does. Since we have changed the flow with Ratelinx
            # and Snapfulfil, it's safer to deactivate its behavior until they
            # tell us otherwise
            flash[:success] = 'This buttons does nothing!'
            redirect_to :back
          end

          def cancel
            if @order.has_picked_snapfulfil_shipment?
              flash[:error] = "One of the shipment is not cancellable / already picked."
            else
              @order.canceled_by(try_spree_current_user)
              ::Spree::Comment.create(user: try_spree_current_user, order: @order,
                                      customer_service: try_spree_current_user, channel: 'Customer Service',
                                      comment_type: 'Customer Service', reason: 'Cancel',
                                      text: "Order #{@order.number} canceled by #{try_spree_current_user.email}.")
              flash[:success] = ::Spree.t(:order_canceled)
            end
            redirect_to :back
          end

          private

          def mailer_attributes(order)
            ::Spree::OrderMailerAttributes.new(order, nil).build_attributes
          end

          def external_key
            @_external_key ||= ::Spree::BrontoConfiguration.account[store.code]
          end

          def store
            ::Spree::Store.current
          end
        end
      end
    end
  end
end

::Spree::Admin::OrdersController.prepend ::Hollar::Spree::Admin::Controllers::OrdersControllerDecorator
