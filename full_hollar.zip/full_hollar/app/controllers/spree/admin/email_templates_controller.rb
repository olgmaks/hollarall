module Spree
  module Admin
    class EmailTemplatesController < ResourceController
      def index
        respond_with(@collection)
      end

      def create
        @email_template = EmailTemplate.new(permitted_resource_params)
        unless @email_template.percentage.present?
          if EmailTemplate.exists?(reference: @email_template.reference)
            rest = 100 - EmailTemplate.where(reference: @email_template.reference).sum(:percentage)
            @email_template.percentage = rest > 0 ? rest : 0
          else
            @email_template.percentage = 100
          end
        end
        if @email_template.save
          redirect_to action: :edit, id: @email_template.id
        else
          flash[:error] = "Template could not be created"
          render :new
        end
      end

      def sublist
        @collection = EmailTemplate.where(reference: params[:reference]).
                      page(params[:page]).
                      per(Spree::Config[:admin_products_per_page])
        respond_with(@collection)
      end

      def update_percentage
        @template = EmailTemplate.find(params[:id])
        @template.update_attribute(:percentage, params[:email_template][:percentage].to_i)
        render json: { message: 'Percentage updated' }
      end

      def references
        @references = Spree::BrontoConfiguration.account['spree'].keys
      end

      def show
        redirect_to action: :edit
      end

      protected

      def collection
        return @collection if @collection.present?
        params[:q] ||= {}
        params[:q][:s] ||= 'position asc'
        @collection = super
        @search = @collection.ransack(params[:q])
        @collection = @search.result.
                      page(params[:page]).
                      per(Spree::Config[:admin_products_per_page])
        @collection
      end

      def permitted_resource_params
        params.require(:email_template).permit(:name,
                                               :reference,
                                               :bronto_key,
                                               :percentage)
      end
    end
  end
end
