module Spree
  module Admin
    class HomepagePodsController < ResourceController
      def index
        session[:return_to] ||= request.url
        gon.pods = @collection.reorder(position: :asc)
        respond_with(@collection)
      end

      private

      def model_class
        ::Spree::Pod
      end

      def collection
        return @collection if @collection.present?
        params[:q] ||= {}
        params[:q][:deleted_at_null] ||= '1'
        params[:q][:display_homepage_eq] = true
        params[:q][:s] ||= 'name asc'
        @collection = super
        if params[:q].delete(:deleted_at_null) == '0'
          @collection = @collection.with_deleted
        end
        # @search needs to be defined as this is passed to search_form_for
        @search = @collection.ransack(params[:q])
        @collection = @search.result
        @collection
      end
    end
  end
end
