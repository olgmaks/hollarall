module Spree
  module Admin
    class SitePreferencesController < ::Spree::Admin::BaseController
      helper_method :scalar_pref_keys

      def pref_keys_with_type
        Hollar::Config.defined_preferences.map do |pref_key|
          [pref_key, Hollar::Config.send("preferred_#{pref_key}_type")]
        end
      end

      def scalar_pref_keys
        pref_keys_with_type.select do |key_and_type|
          [:boolean, :decimal, :integer, :float, :string, :text, :password].include?(key_and_type.last)
        end
      end

      def update
        scalar_pref_keys.each do |key_and_type|
          pref_key, pref_type = key_and_type
          if params.key?(pref_key)
            Hollar::Config.set(pref_key => convert_preference_value(params[pref_key], pref_type))
          end
        end

        flash[:success] = "Site preferences has been successfully updated"
        redirect_to :back
      end

      private

      def convert_preference_value(value, type)
        case type
        when :string, :text
          value.to_s
        when :password
          value.to_s
        when :decimal
          BigDecimal.new(value.to_s)
        when :integer
          value.to_i
        when :boolean
          if !value || value.zero? ||
             value =~ /\A(f|false|0)\Z/i ||
             (value.respond_to? :empty? and value.empty?)
            false
          else
            true
          end
        when :array
          raise TypeError, "Array expected got #{value.inspect}" unless value.is_a?(Array)
          value
        when :hash
          raise TypeError, "Hash expected got #{value.inspect}" unless value.is_a?(Hash)
          value
        else
          value
        end
      end
    end
  end
end
