module Spree
  module Admin
    class ShelvesController < ::Spree::Admin::BaseController
      def homelist
        if params[:taxon_id].to_i != 0
          @taxon = ::Spree::Taxon.find(params[:taxon_id])
          @shelves = @taxon.shelves.includes(shelf_product_memberships: :product)
        else
          @taxon = nil
          @shelves = Shelf.displayed_on_homepage.includes(shelf_product_memberships: :product)
        end
      end

      def reload
        ::ShelvesReloadWorker.perform_now
        flash[:success] = Spree.t(:shelves_reloaded)
        redirect_to :back
      end

      def new
        @shelf = Shelf.new
      end

      def create
        params[:shelf][:product_ids] = params[:shelf][:product_ids].to_s.split(",").map(&:to_i)
        @shelf = Shelf.new(permitted_params)
        if @shelf.save
          flash[:success] = Spree.t(:successfully_created, resource: Spree.t(:shelf))
        end
        respond_to do |format|
          format.html { redirect_to spree.edit_admin_shelf_path(@shelf) }
        end
      end

      def destroy
        @shelf = Shelf.find(params[:id])
        @shelf.destroy

        head :no_content
      end

      def edit
        @shelf = Shelf.find(params[:id])
      end

      def update
        @shelf = Shelf.find(params[:id])

        if params[:shelf][:product_ids]
          params[:shelf][:product_ids] = params[:shelf][:product_ids].split(",").map(&:to_i)
        end

        @shelf.update_attributes(permitted_params) if params[:shelf]

        respond_to do |format|
          format.html { redirect_to action: "edit" }
          format.json { render json: @shelf, status: 200 }
        end
      end

      def show
        @shelf = Shelf.find(params[:id])
      end

      protected

      def permitted_params
        params.require(:shelf).permit(:name,
                                      :taxon_id,
                                      :display_homepage,
                                      :referenced_taxon_id,
                                      :hide_title,
                                      :group_id,
                                      :position,
                                      :fixed_position,
                                      :autoload,
                                      product_ids: [])
      end
    end
  end
end
