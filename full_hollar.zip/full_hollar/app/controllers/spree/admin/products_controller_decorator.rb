module Hollar
  module Spree
    module Admin
      module ProductsControllerDecorator
        def load_data
          super
          @bundle_units = ::Spree::Product.uniq.pluck(:bundle_unit).reject(&:blank?)
        end
      end
    end
  end
end

::Spree::Admin::ProductsController.prepend ::Hollar::Spree::Admin::ProductsControllerDecorator
