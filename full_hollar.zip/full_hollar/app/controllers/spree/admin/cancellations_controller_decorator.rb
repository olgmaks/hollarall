module Hollar
  module Spree
    module Admin
      module Controllers
        module CancellationsControllerDecorator
          def short_ship
            inventory_unit_ids = params[:inventory_unit_ids] || []
            inventory_units = ::Spree::InventoryUnit.where(id: inventory_unit_ids)

            if inventory_units.size != inventory_unit_ids.size
              flash[:error] = ::Spree.t(:unable_to_find_all_inventory_units)
              redirect_to admin_order_cancellations_path(@order)
            elsif inventory_units.empty?
              flash[:error] = ::Spree.t(:no_inventory_selected)
              redirect_to admin_order_cancellations_path(@order)
            else
              @order.cancellations.short_ship(inventory_units, whodunnit: whodunnit)

              @order.create_cancellation_comment(
                customer_service: try_spree_current_user,
                items:            inventory_units
              )

              flash[:success] = ::Spree.t(:inventory_canceled)
              redirect_to edit_admin_order_url(@order)
            end
          end
        end
      end
    end
  end
end

::Spree::Admin::CancellationsController.prepend ::Hollar::Spree::Admin::Controllers::CancellationsControllerDecorator
