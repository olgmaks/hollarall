module Spree
  module Admin
    class GroupsController < ResourceController
      def index
        respond_with(@collection)
      end

      def show
        redirect_to action: :edit
      end

      protected

      def collection
        return @collection if @collection.present?
        params[:q] ||= {}
        params[:q][:s] ||= 'position asc'
        @collection = super
        @search = @collection.ransack(params[:q])
        @collection = @search.result.
          page(params[:page]).
          per(Spree::Config[:admin_products_per_page])
        @collection
      end
    end
  end
end
