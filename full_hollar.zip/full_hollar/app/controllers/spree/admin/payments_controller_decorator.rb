module Hollar
  module Spree
    module Admin
      module Controllers
        module PaymentsControllerDecorator
          def create
            payment_method = ::Spree::PaymentMethod.find(params['payment']['payment_method_id'])

            # if paying with comp payment method, void existing payments with 'checkout' status
            if payment_method.type == 'CompPaymentMethod'
              @order.void_payments_with_checkout_state

              # adapted from ::Spree::Admin::PaymentsController#create
              # auto-capture comp payment when created
              @payment ||= @order.payments.build(object_params)

              begin
                if @payment.save
                  if @order.confirm? || @order.completed?
                    @payment.capture!
                  end

                  flash[:success] = flash_message_for(@payment, :successfully_created)
                  redirect_to admin_order_payments_path(@order)
                else
                  flash[:error] = ::Spree.t(:payment_could_not_be_created)
                  render :new
                end
              rescue ::Spree::Core::GatewayError => e
                flash[:error] = e.message.to_s
                redirect_to new_admin_order_payment_path(@order)
              end
            else
              super
            end
          end

          def mobile_paypal_refund
            return if request.get?

            refunded = @payment.payment_method.refund(@payment, params[:refund_amount])
            if refunded
              flash[:success] = ::Spree.t(:refund_successful, scope: 'paypal')
              redirect_to admin_order_payments_path(@order)
            else
              flash.now[:error] = ::Spree.t(:refund_unsuccessful, scope: 'paypal')
              render
            end
          end
        end
      end
    end
  end
end

::Spree::Admin::PaymentsController.prepend ::Hollar::Spree::Admin::Controllers::PaymentsControllerDecorator
