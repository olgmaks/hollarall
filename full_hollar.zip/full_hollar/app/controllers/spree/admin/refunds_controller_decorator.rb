module Hollar
  module Spree
    module Admin
      module RefundsControllerDecorator
        def create
          super
          ::Spree::Comment.create(user: try_spree_current_user, order: @object.payment.order,
                                  customer_service: try_spree_current_user, channel: 'Customer Service',
                                  comment_type: 'Customer Service', reason: 'Refund',
                                  text: "Refund issued for order #{@object.payment.order.number} by #{try_spree_current_user.email}.")
        end
      end
    end
  end
end

::Spree::Admin::RefundsController.prepend ::Hollar::Spree::Admin::RefundsControllerDecorator
