module Spree
  module Admin
    module Orders
      class CommentsController < ResourceController
        def index
          @order = repositories[:order].find_by_number(params[:order_id])
          @comments = repositories[:comment].find_all_by_order_id(@order.id)
          @new_comment = repositories[:comment].new
        end

        def create
          comment_creator.new(
            context: self,
            customer_service: current_spree_user,
            params: params,
            order_repository: repositories[:order],
            comment_repository: repositories[:comment]
          ).call
        end

        def on_comment_created(comment)
          flash[:success] = flash_message_for(comment, :successfully_created)
          redirect_to :back
        end

        def on_comment_not_created
          flash[:error] = Spree.t('comments.creation.error')
          redirect_to :back
        end

        def destroy
          comment_deletor.new(
            context: self,
            customer_service: current_spree_user,
            params: params,
            order_repository: repositories[:order]
          ).call
        end

        def on_comment_destroyed
          flash[:success] = Spree.t('comments.deletion.success')
          redirect_to :back
        end

        def on_comment_not_destroyed
          flash[:error] = Spree.t('comments.deletion.error')
          redirect_to :back
        end

        private

        def comment_creator
          ::Hollar::Spree::Orders::Comments::Create
        end

        def comment_deletor
          ::Hollar::Spree::Orders::Comments::Delete
        end
      end
    end
  end
end
