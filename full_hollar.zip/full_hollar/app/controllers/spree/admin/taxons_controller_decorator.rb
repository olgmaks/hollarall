module Hollar
  module Spree
    module Admin
      module TaxonsControllerDecorator
        def update_positions
          taxon = ::Spree::Taxon.find(params[:id])
          positions = JSON.parse(params[:positions])

          positions.each do |position|
            classification = taxon.classifications.find_by(product_id: position['id'].to_i)
            classification.update_attribute(:position, position['position']) if classification
          end

          head :ok
        end

        def move
          taxon = ::Spree::Taxon.find(params[:id])
          taxon.group_id = taxon_params[:group_id]

          if taxon.group_id
            taxon.insert_at(taxon_params[:ingroup_position].to_i)
          else
            taxon.remove_from_list
          end

          head :ok
        end

        private

        def permitted_taxon_attributes
          super.push *[:group_id, :ingroup_position]
        end
      end
    end
  end
end

::Spree::Admin::TaxonsController.prepend ::Hollar::Spree::Admin::TaxonsControllerDecorator
