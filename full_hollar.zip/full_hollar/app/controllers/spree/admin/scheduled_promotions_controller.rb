module Spree
  module Admin
    class ScheduledPromotionsController < ResourceController
      before_action :load_data, except: [:index, :generated_codes]

      def generated_codes
        @scheduled_promotion = ScheduledPromotion.find(params[:scheduled_promotion_id])
        @generated_scheduled_promotions = GeneratedScheduledPromotion.
                                          where(scheduled_promotion_id: params[:scheduled_promotion_id]).
                                          order(id: :desc).
                                          page(params[:page]).
                                          per(params[:per_page] || Spree::Config[:promotions_per_page])
      end

      private

      def model_class
        ScheduledPromotion
      end

      def collection
        return @collection if defined?(@collection)
        params[:q] ||= HashWithIndifferentAccess.new
        params[:q][:s] ||= 'id desc'

        @search = super.ransack(params[:q])
        @collection = @search.result(distinct: true).
                      page(params[:page]).
                      per(params[:per_page] || Spree::Config[:promotions_per_page])

        @collection
      end

      def load_data
        @non_generated_promotions = ::Spree::Promotion.
                                    includes(:generated_scheduled_promotions).
                                    where(generated_scheduled_promotions: { id: nil })
      end
    end
  end
end
