class Spree::Admin::TaxonGroupsController < ::Spree::Admin::BaseController; end
