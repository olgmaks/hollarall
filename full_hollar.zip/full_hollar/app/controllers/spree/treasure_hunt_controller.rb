module Spree
  class TreasureHuntController < Spree::StoreController
    def index
    end
  end
end
