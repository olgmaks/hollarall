module Spree
  class ShelfGroupsController < Spree::StoreController
    helper_method :shelf_group

    private

    def shelf_group
      @shelf_group ||= ShelfGroup.find_by(permalink: params[:permalink])
    end

    def accurate_title
      @shelf_group.try(:name)
    end
  end
end
