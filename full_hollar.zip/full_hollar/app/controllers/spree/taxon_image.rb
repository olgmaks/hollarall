module Spree
  class TaxonImage < Image
    has_attached_file :attachment, ATTACHMENT_CONFIG.merge(
      styles: {
        normal: '480x325>',
        featured: '980x440>',
        normal_retina: '720x487.5>',
        featured_retina: '1470x660>'
      },
      default_style: :normal
    )

    after_post_process :find_dimensions
  end
end
