module Hollar
  module Spree
    module Controllers
      module UserSessionsControllerDecorator
        # POST /resource/sign_in
        def create
          super
          session[:cart_items] = @current_order.products.ids if @current_order
        end
      end
    end
  end
end

::Spree::UserSessionsController.prepend ::Hollar::Spree::Controllers::UserSessionsControllerDecorator
