module Hollar
  module Spree
    module Controllers
      module HomeControllerDecorator
        def self.prepended(base)
          base.include SearchFilters
          base.include SearchMerchandising
        end

        def index
          per_page = params[:per_page] || 36

          @home_pods = ::Spree::Pod.displayed_on_homepage
          current_order(create_order_if_necessary: true)

          params[:product_recommendation_basis] = get_recommendation_basis(try_spree_current_user)

          @searcher = index_searcher(spree_current_user, params.merge(per_page: (2 * per_page) / 3))
          product_results = @searcher.retrieve_products
          product_ids = product_results.map(&:id)
          product_taxon_ids = relevant_taxon_ids_from_results(product_results)

          if params[:product_recommendation_basis]
            product_ids = shuffle_in_new_products_in_taxons(try_spree_current_user, product_ids, product_taxon_ids,
                                                            params.merge(per_page: per_page - (2 * per_page) / 3))

            @shelf = Shelf.fixed_position_homepage.first

            if @shelf
              product_ids = @shelf.pepper_products(product_ids, params[:page] || 1, per_page)
            end
          end

          @shelf  ||= Shelf.find_by(display_homepage: true, display_last: false)
          @products = load_products(product_ids, params)
          @taxonomies = ::Spree::Taxonomy.includes(root: :children)
        end
      end
    end
  end
end

::Spree::HomeController.prepend ::Hollar::Spree::Controllers::HomeControllerDecorator
