module Hollar
  module Spree
    module Controllers
      module CheckoutControllerDecorator
        # Settings for the credit for our timed checkout promotion
        module TimedPromotionCredit
          AMOUNT = 2
          MEMO = 'Timed-checkout promotion for order %s'.freeze
        end

        def self.prepended(base)
          base.before_action :disable_browser_caching
          base.after_action :tag_attribution, only: :update
        end

        private

        def before_address
          # override default behavior to assign user's address if not already set
          if try_spree_current_user && try_spree_current_user.bill_address && try_spree_current_user.ship_address
            @order.build_bill_address(try_spree_current_user.bill_address.attributes.except('id', 'created_at', 'updated_at')) if @order.bill_address.nil?
            @order.build_ship_address(try_spree_current_user.ship_address.attributes.except('id', 'created_at', 'updated_at')) if @order.ship_address.nil?
          end

          super
        end

        def disable_browser_caching
          response.headers["Cache-Control"] = "no-cache, no-store"
          response.headers["Pragma"] = "no-cache"
          response.headers["Expires"] = "Fri, 01 Jan 1990 00:00:00 GMT"
        end

        def tag_attribution
          return unless @order.try(:completed?) && attribution_cookie_name

          Hollar::Spree::Attributions::Create.new(
            self, @order, cookie: attribution_cookie_name
          ).call
        end

        def attribution_cookie_name
          @attribution_cookie_name ||=
            case
            when cookies[Rack::Utm::ORDER_COOKIE_NAME]
              Rack::Utm::ORDER_COOKIE_NAME
            when cookies[Rack::Utm::USER_COOKIE_NAME]
              Rack::Utm::USER_COOKIE_NAME
            end
        end

        def before_payment
          super

          if try_spree_current_user && try_spree_current_user.respond_to?(:payment_sources)
            @payment_sources = try_spree_current_user.payment_sources.
              joins(:payment_method).where('spree_payment_methods.type = ?', 'Solidus::Gateway::BraintreeGateway')
          end
        end

        def update
          request_time = Time.zone.now
          order = current_order
          redirect_to spree.cart_path and return unless order

          order_rules = OrderCheckoutRules.new(order, try_spree_current_user)
          errors = order_rules.verify_against_all_rules

          if errors.any?
            # NOTE(cab): We want to display those errors directly in the body
            # and not in the flash.  But we still want to be redirect to the
            # cart if there are any errors.
            errors.all.delete_if do |error|
              allowed_errors = [::ErrorCode::ORDER_MIN_QUANTITY_NOT_HIT]
              !allowed_errors.include?(error[:code])
            end
            flash[:error] = errors.first[:message] if errors.first.present?
            redirect_to cart_path
            return
          end

          super

          if @order.completed?
            if spree_current_user && spree_current_user.timed_promotion &&
               spree_current_user.timed_promotion.eligible?(@order, request_time)
              spree_current_user.timed_promotion.complete(request_time,
                                                          TimedPromotionCredit::AMOUNT,
                                                          TimedPromotionCredit::MEMO % @order.number)
            end

            @order.update(treasurable: true) if @order.contains_hidden_products?
          end
        end
      end
    end
  end
end

::Spree::CheckoutController.prepend ::Hollar::Spree::Controllers::CheckoutControllerDecorator
