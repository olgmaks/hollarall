module Hollar
  module Spree
    module OmniauthCallbacksControllerDecorator
      def self.prepended(base)
        base.after_action :check_share_code, only: [:facebook]
        base.after_action :assign_name, only: [:facebook]
      end

      def check_share_code
        invite_code = cookies[:invite_code]
        referee_email = auth_hash['info']['email']
        user = ::Spree::User.find_by_email(referee_email)

        if allowed_to_receive_store_credits?(invite_code, user)
          user.referral_invite_code = invite_code
          user.save!

          # Note(niko)
          # The referral_invite_code was not being loaded in the model
          # Therefore, I fully reloaded the user from the database.
          user = ::Spree::User.find_by_email(auth_hash['info']['email'])
          user.reload.register_invite_subscription!
          cookies.delete :invite_code
        end
      end

      def assign_name
        if first_and_last_name?
          user = ::Spree::User.find_by(email: auth_hash['info']['email'])
          if user
            user.update_from_omniauth(auth_hash['info'])
          end
        elsif name?
          user = ::Spree::User.find_by(email: auth_hash['info']['email'])
          if user
            decompose_name
            user.update_from_omniauth(auth_hash['info'])
          end
        end
        true
      end

      private

      def allowed_to_receive_store_credits?(invite_code, user)
        return false unless invite_code
        return false unless user
        return false if user.orders.any?
        return false if user.referral_invite_code
        true
      end

      def first_and_last_name?
        auth_hash['info'].include?('first_name') && auth_hash['info'].include?('last_name')
      end

      def name?
        auth_hash['info'].include?('name')
      end

      def decompose_name
        name = Namae.parse(auth_hash['info']['name']).first

        if name && name.given && name.family
          auth_hash['info']['first_name'] = name.given.split.first
          auth_hash['info']['last_name'] = name.family
        end
      end
    end
  end
end

::Spree::OmniauthCallbacksController.prepend ::Hollar::Spree::OmniauthCallbacksControllerDecorator
