module Spree
  module Giftcard
    class CheckoutController < ::Spree::CheckoutController
      def edit
        render 'spree/giftcard_checkout/edit'
      end

      def update
        if OrderUpdateAttributes.new(@order, update_params, request_env: request.headers.env).apply
          @order.gift_card = true
          success = if @order.state == 'confirm'
                      @order.complete
                    else
                      @order.next
                    end
          if !success
            flash[:error] = @order.errors.full_messages.join("\n")
            redirect_to(giftcard_checkout_state_path(@order.state)) && return
          end

          if @order.completed?
            @current_order = nil
            flash.notice = Spree.t(:order_processed_successfully)
            flash['order_completed'] = true
            redirect_to completion_route
          else
            redirect_to giftcard_checkout_state_path(@order.state)
          end
        else
          render 'spree/giftcard_checkout/edit'
        end
      end

      private

      def set_state_if_present
        if params[:state]
          redirect_to giftcard_checkout_state_path(@order.state) if @order.can_go_to_state?(params[:state]) && !skip_state_validation?
          @order.state = params[:state]
        end
      end

      def ensure_checkout_allowed
        unless @order.checkout_allowed?
          redirect_to '/products/gift-card'
        end
      end

      def ensure_order_not_completed
        redirect_to '/products/gift-card' if @order.completed?
      end

      def ensure_sufficient_stock_lines
        if @order.insufficient_stock_lines.present?
          flash[:error] = Spree.t(:inventory_error_flash_for_insufficient_quantity)
          redirect_to '/products/gift-card'
        end
      end

      def ensure_valid_state
        unless skip_state_validation?
          if (params[:state] && !@order.has_checkout_step?(params[:state])) ||
              (!params[:state] && !@order.has_checkout_step?(@order.state))
            @order.state = 'cart'
            redirect_to giftcard_checkout_state_path(@order.checkout_steps.first)
          end
        end

        # Fix for https://github.com/spree/spree/issues/4117
        # If confirmation of payment fails, redirect back to payment screen
        if params[:state] == "confirm" && @order.payment_required? && @order.payments.valid.empty?
          flash.keep
          redirect_to giftcard_checkout_state_path("payment")
        end
      end

      def verify_errors
        true
      end

      def load_order
        @order = current_gift_card_order
        redirect_to '/products/gift-card' and return unless @order
      end

      def rescue_from_spree_gateway_error(exception)
        flash.now[:error] = Spree.t(:spree_gateway_error_flash_for_checkout)
        @order.errors.add(:base, exception.message)
        render 'spree/giftcard_checkout/edit'
      end

      def check_authorization
        authorize!(:edit, current_gift_card_order, cookies.signed[:guest_token])
      end
    end
  end
end
