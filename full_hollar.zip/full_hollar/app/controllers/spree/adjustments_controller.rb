module Spree
  class AdjustmentsController < Spree::StoreController
    def destroy
      @order = Spree::Order.find(params[:order_id])
      adjustment = Spree::Adjustment.find_by(id: params[:id])
      PromotionHandler::Coupon.new(@order).remove(adjustment) if adjustment
      if %w{cart address}.include? @order.state
        redirect_to cart_path
      else
        redirect_to checkout_path
      end
    end
  end
end
