class ApplicationController < ActionController::Base
  # Prevent CSRF attacks by raising an exception.
  # For APIs, you may want to use :null_session instead.
  protect_from_forgery with: :exception

  helper Spree::PagesHelper
  helper Spree::CatalogueHelper
  helper Spree::ProductsHelper
  helper Spree::NavigationHelper

  def repositories
    {
      order: OrderRepository.new,
      comment: CommentRepository.new,
      pods: Spree::Pod
    }
  end

  before_action :set_experiments_from_optimizely

  private

  def set_experiments_from_optimizely
    buckets = {}

    if params[:optimizely_disable] != "true"
      json_buckets = decode_json_buckets(cookies["optimizelyBuckets"])

      if json_buckets
        buckets = json_buckets
      end
    end

    FeatureFlags.set_experiments(buckets)
  end

  def decode_json_buckets(json_content)
    json = JSON.parse(json_content.to_s)

    json.is_a?(Hash) ? json : nil
  rescue JSON::ParserError
    # treat not parseable as empty
    nil
  end

  def ssl_configured?
    !Rails.env.development? && !Rails.env.debug? && !Rails.env.test?
  end
end
