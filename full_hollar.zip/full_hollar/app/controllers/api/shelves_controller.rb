module Api
  class ShelvesController < Spree::Api::ResourceController
    def index
      if params[:taxon_id].to_i == 0
        scope = Shelf.displayed_on_homepage
      else
        scope = Shelf.for_taxon_id(params[:taxon_id])
      end
      @collection = @shelves = shelf_load(scope)
      respond_with(@collection)
    end

    def tree
      @collection = ShelfGroup.includes(:shelves) + [Shelf.ungrouped]
    end

    protected

    def model_class
      Shelf
    end

    def permitted_shelf_attributes
      [:id, :name, :display_homepage, :position]
    end

    def shelf_load(scope)
      scope = scope.accessible_by(current_ability, :read)
      scope.includes(shelf_product_memberships: :product)
    end
  end
end
