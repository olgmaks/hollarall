module Api
  class MerchantsController < Spree::Api::ResourceController
    protected

    def model_class
      Merchant
    end
  end
end
