module Api
  class ShelfProductMembershipsController < Spree::Api::ResourceController
    protected

    def model_class
      ShelfProductMembership
    end

    def permitted_shelf_product_membership_attributes
      [:id, :shelf_id, :product_id, :position]
    end
  end
end
