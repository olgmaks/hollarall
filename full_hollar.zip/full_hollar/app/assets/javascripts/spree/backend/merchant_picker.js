Spree.routes.merchant_search = Spree.pathFor('admin/search/merchants');

$.fn.merchantAutocomplete = function () {
  'use strict';

  function formatMerchant(merchant) {
    return Select2.util.escapeMarkup(merchant.name);
  }

  this.select2({
    minimumInputLength: 1,
    multiple: true,
    initSelection: function (element, callback) {
      $.get(Spree.routes.merchant_search, {
        ids: element.val()
      }, function (data) {
        callback(data.merchants);
      });
    },
    ajax: {
      url: Spree.routes.merchant_search,
      datatype: 'json',
      params: { "headers": { "X-Spree-Token": Spree.api_key } },
      data: function (term) {
        return {
          q: term,
          token: Spree.api_key
        };
      },
      results: function (data) {
        return {
          results: data.merchants
        };
      }
    },
    formatResult: formatMerchant,
    formatSelection: formatMerchant
  });
};

$(document).ready(function () {
  $('.merchant_picker').merchantAutocomplete();
});
