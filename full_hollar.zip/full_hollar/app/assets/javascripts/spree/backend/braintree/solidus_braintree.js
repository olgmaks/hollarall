//= require "vendor/braintree"

(function() {
  Spree.routes.payment_client_token_api = Spree.pathFor('api/payment_client_token');

  var creditCardPaymentMethodID = null;
  var braintreeForm = null;
  var formContainer;
  var paymentContainer;

  var BraintreeForm = function() {
    this.braintreeLoaded = false;
    this.hostedFieldsInstance = null;
    this.paypalFieldsInstance = null;
    this.usingPayPal = false;
    this.payPalCheckoutFlow = null;
  };

  BraintreeForm.prototype.getClientToken = function(onSuccess) {
    disablePaymentCardSelectors(true);

    return Spree.ajax({
      url: Spree.routes.payment_client_token_api,
      type: 'POST',
      data: {
        payment_method_id: this.creditCardPaymentMethodID
      },
      error: function(xhr, status) {
        console.error('ERROR: client token');
      },
      success: function(data) {
        onSuccess(data);
      }
    });
  };

  BraintreeForm.prototype.initialize = function(data) {
    var self = this;

    braintree.client.create({
      authorization: data.client_token
    }, function(clientErr, clientInstance) {
      if (clientErr) {
        self.handleClientError(clientErr);
        return;
      }

      var $source = $('.braintree-input-style');

      braintree.hostedFields.create({
        client: clientInstance,
        fields: {
          number: {
            selector: '#braintree_card_number',
            placeholder: '4111 1111 1111 1111'
          },
          cvv: {
            selector: '#braintree_card_code',
            placeholder: '123'
          },
          expirationDate: {
            selector: '#braintree_card_expiry',
            placeholder: '12 / 2020'
          }
        },
        styles: {
          input: {
            'font-family': $source.css('font-family'),
            'font-size': $source.css('font-size'),
            'color': '#5498DA',
            'height': $source.css('height')
          }
        }
      }, function(hostedFieldsErr, instance) {
        if (hostedFieldsErr) {
          self.handleClientError(hostedFieldsErr);
          return;
        }

        self.hostedFieldsInstance = instance;
        disablePaymentCardSelectors(false);
      });

      braintree.paypal.create({
        client: clientInstance
      }, function (paypalErr, paypalInstance) {
        if (paypalErr) {
          self.handleClientError(paypalErr);
          return;
        }

        self.paypalFieldsInstance = paypalInstance;

        var $paypalButton = $('.paypal-button');
        $paypalButton.prop('disabled', false);

        $paypalButton.off('click');
        $paypalButton.on('click', function (e) {
          // PayPal button clicked, pop-up displayed
          self.showPayPalOverlay();

          self.payPalCheckoutFlow = self.paypalFieldsInstance.tokenize({
            flow: 'vault'
          }, function (tokenizeErr, payload) {
            if (tokenizeErr) {
              if (tokenizeErr.code !== 'PAYPAL_POPUP_CLOSED') {
                self.handleClientError(tokenizeErr);
              }

              self.hidePayPalOverlay();
              self.usingPayPal = false;
              return;
            }

            // tokenization succeeded
            $paypalButton.prop('disabled', true);
            self.hidePayPalOverlay();
            $('#payment_method_nonce').val(payload.nonce);
            self.usingPayPal = true;

            $('#braintree-paypal-logged-in').removeClass('dn');
            $('#braintree-paypal-logged-out, .braintree-cc-input').addClass('dn');
            $('#bt-pp-email').text(payload.details.email);
            $('#bt-pp-cancel').prop('disabled', false);

            $('#bt-pp-cancel').one('click', function() {
              self.usingPayPal = false;
              $('#braintree-paypal-logged-in').addClass('dn');
              $('#braintree-paypal-logged-out, .braintree-cc-input').removeClass('dn');
              $paypalButton.prop('disabled', false);
              $('#payment_method_nonce').val('');
            })
          });
        });
      });
    });
  };

  BraintreeForm.prototype.showForm = function() {
    $('#payment-method-fields').show();
    $('#payment-methods').show();
    $('.existing-cc-radio').prop('disabled', true);

    if (!this.braintreeLoaded) {
      this.getClientToken(this.initialize.bind(this));
      this.braintreeLoaded = true;
    }

    var self = this;

    $('#new_payment').on('submit.braintree', function(e) {
      e.preventDefault();
      var form = this;

      if (!self.usingPayPal) {
        self.hostedFieldsInstance.tokenize({
          vault: true
        }, function (tokenizeErr, data) {
          if (tokenizeErr) {
            self.handleClientError(tokenizeErr);
            $('button.continue').prop('disabled', false);
            return;
          } else {
            $('#payment_method_nonce').val(data.nonce);
            form.submit();
          }
        });
      } else {
        form.submit();
      }
    });
  };

  BraintreeForm.prototype.hideForm = function() {
    $('#payment-method-fields').hide();
    $('#payment-methods').hide();
    $('.existing-cc-radio').prop('disabled', false);
    $('#new_payment').off('submit.braintree');
  };

  BraintreeForm.prototype.showPayPalOverlay = function() {
    var self = this;

    $('.bt-overlay').removeClass('dn');
    $('.bt-close-overlay').off('click');
    $('.bt-close-overlay').one('click', function() {
      self.hidePayPalOverlay();
      self.payPalCheckoutFlow.close();
      self.payPalCheckoutFlow = null;
    });

    $('.bt-paypal-continue').off('click');
    $('.bt-paypal-continue').on('click', function() {
      self.payPalCheckoutFlow.focus();
    });
  };

  BraintreeForm.prototype.hidePayPalOverlay = function() {
    $('.bt-overlay').addClass('dn');
    $('.bt-paypal-continue').off('click');
  };

  $(document).ready(function() {
    if ($('form.new_payment').length > 0) {
      braintreeForm = new BraintreeForm();
      creditCardPaymentMethodID = $('.payment_methods_radios', 'li[data-payment-method-type=Solidus\\:\\:Gateway\\:\\:BraintreeGateway]').val();

      paymentContainer = $('#payment_method_' + creditCardPaymentMethodID);
      formContainer = $('#card_form' + creditCardPaymentMethodID);
      $(formContainer).hide();

      if ($('.payment_methods_radios:checked').val() === creditCardPaymentMethodID &&
        ($('[name=card]:checked', paymentContainer).val() === 'new' || $('[name=card]', paymentContainer).length === 0)) {
        braintreeForm.showForm();
      }

      // register credit card selection event
      $('[name=card]', paymentContainer).on('change', function() {
        if ($('[name=card]:checked', paymentContainer).val() === 'new') {
          braintreeForm.showForm();
        } else {
          braintreeForm.hideForm();
        }
      });

      // register payment method selection event
      $('.payment_methods_radios').on('change', function() {
        if ($('.payment_methods_radios:checked').val() === creditCardPaymentMethodID) {
          if ($('[name=card]:checked', paymentContainer).val() === 'new' || $('[name=card]', paymentContainer).length === 0) {
            braintreeForm.showForm();
          }
        } else {
          braintreeForm.hideForm();
        }
      });
    }
  });

  function disablePaymentCardSelectors(disabled) {
    $('.payment_methods_radios').prop('disabled', disabled);
    $('[name=card]', paymentContainer).prop('disabled', disabled);
  };
})();
