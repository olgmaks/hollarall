(function() {
  Spree.routes.verify_address_api = Spree.pathFor('api/checkouts/verify_address');
  var addressForm = null;

  var AddressForm = function() {
    this.enteredAddress = null;
    this.suggestedAddress = null;
    this.registerFormSubmit();
  };

  AddressForm.prototype.registerFormSubmit = function() {
    $('#checkout_form_address').one('submit', this.onSubmit.bind(this));
  };

  AddressForm.prototype.onSubmit = function(e) {
    e.preventDefault();

    $('[type=submit]').prop('disabled', true);

    var idPrefix = ($('#order_use_billing').is(':checked') ? '#order_bill_' : '#order_ship_') + 'address_attributes_';

    this.enteredAddress = {
      address1: $(idPrefix + 'address1').val(),
      address2: $(idPrefix + 'address2').val(),
      city: $(idPrefix + 'city').val(),
      state: $(idPrefix + 'state_id option:selected').text(),
      zipcode: $(idPrefix + 'zipcode').val(),
    };

    var self = this;

    $.ajax(Spree.routes.verify_address_api, {
      method: 'POST',
      data: this.enteredAddress,
      success: function(data) {
        var a = data.verified_address;

        if (data.error) {
          var warningText;

          if (data.error === 'address_incomplete') {
            warningText = 'More information may be needed (such as an apartment, suite, or box number).'
          }

          self.showAddressNotFoundModal(warningText);
          return;
        }

        var fullZipcode = a.zip5;

        if (a.zip4) {
          fullZipcode += '-' + a.zip4;
        }

        self.suggestedAddress = {
          address1: a.address1,
          address2: a.address2,
          city: a.city,
          state: a.state,
          zipcode: fullZipcode
        };

        if (data.address_matched) {
          return $('#checkout_form_address').submit();
        }

        self.showVerifyModal();
      },
      timeout: 2500
    }).fail(function() {
      // error for whatever reason, skip verification
      $('#checkout_form_address').submit();
    });
  };

  AddressForm.prototype.onAcceptEntered = function(e) {
    e.preventDefault();

    $('.featherlight button').prop('disabled', true);
    $('#checkout_form_address').submit();
  };

  AddressForm.prototype.onAcceptSuggestions = function(e) {
    e.preventDefault();

    $('.featherlight button').prop('disabled', true);
    var stateID = $('#order_bill_address_attributes_state_id option:contains("' + this.suggestedAddress.state + '")').val();

    if ($('#order_use_billing').is(':checked')) {
      $('#order_bill_address_attributes_zipcode').val(this.suggestedAddress.zipcode);
    }

    $('#order_ship_address_attributes_zipcode').val(this.suggestedAddress.zipcode);

    $('.featherlight .button').prop('disabled', true);
    $('#checkout_form_address').submit();
  };

  AddressForm.prototype.showVerifyModal = function() {
    var self = this;

    this._showModal($('.address-verification-popup'), 'address-verification-featherlight', function() {
      $('.entered-address .address').text(self.enteredAddress.address1);
      $('.entered-address .address2').text(self.enteredAddress.address2);
      $('.entered-address .city').text(self.enteredAddress.city);
      $('.entered-address .state').text(self.enteredAddress.state);
      $('.entered-address .zip').text(self.enteredAddress.zipcode);

      $('.suggested-address .address').text(self.enteredAddress.address1);
      $('.suggested-address .address2').text(self.enteredAddress.address2);
      $('.suggested-address .city').text(self.enteredAddress.city);
      $('.suggested-address .state').text(self.enteredAddress.state);
      $('.suggested-address .zip').text(self.suggestedAddress.zipcode);

      $('.featherlight .accept-entered').on('mousedown', self.onAcceptEntered.bind(self));
      $('.featherlight .accept-suggested').on('mousedown', self.onAcceptSuggestions.bind(self));
    });
  };

  AddressForm.prototype.showAddressNotFoundModal = function(warningText) {
    var self = this;

    this._showModal($('.address-not-found-popup'), 'address-not-found-featherlight', function() {
      $('.original-address .address').text(self.enteredAddress.address1);
      $('.original-address .city').text(self.enteredAddress.city);
      $('.original-address .state').text(self.enteredAddress.state);
      $('.original-address .zip').text(self.enteredAddress.zipcode);

      if (warningText) {
        $('.address-not-found-popup .warning-text').text(warningText).show();
      } else {
        $('.address-not-found-popup .warning-text').text('').hide();
      }

      $('.featherlight .accept-entered').on('mousedown', self.onAcceptEntered.bind(self));
    });
  };

  AddressForm.prototype._showModal = function(el, featherlightClass, afterOpen) {
    var self = this;

    $.featherlight(el.clone(), {
      persist: true,
      variant: featherlightClass,
      otherClose: '.mobile-modal-close, .featherlight .edit',
      closeOnClick: '.mobile-modal-close',
      afterOpen: afterOpen,
      afterClose: function() {
        $('[type=submit]').prop('disabled', false);
        self.registerFormSubmit();
      }
    });
  };

  $(document).on('ready', function() {
    if ($('#checkout_form_address').length > 0 && window.FeatureFlags && window.FeatureFlags['address_verification']) {
      addressForm = new AddressForm();
    }
  });
})();
