//= require "vendor/braintree"

(function() {
  Spree.routes.payment_client_token_api = Spree.pathFor('api/payment_client_token');

  // credit card types sent by Braintree mapped to our css classes
  var ccMap = {
    'visa': 'visa',
    'master-card': 'mastercard',
    'american-express': 'amex',
    'discover': 'discover'
  };

  var ccClasses = $.map(ccMap, function(v) { return 'is-' + v; }).join(' ');

  var paymentId = null;
  var braintreeForm = null;

  var BraintreeForm = function() {
    this.braintreeLoaded = false;
    this.hostedFieldsInstance = null;
    this.paypalFieldsInstance = null;
    this.usingPayPal = false;
    this.payPalCheckoutFlow = null;
  };

  BraintreeForm.prototype.getClientToken = function(onSuccess) {
    disableCardSelector(true);

    return Spree.ajax({
      url: Spree.routes.payment_client_token_api,
      type: 'POST',
      data: {
        payment_method_id: paymentId
      },
      error: function(xhr, status) {
        console.error('ERROR: client token');
      },
      success: function(data) {
        onSuccess(data);
      }
    });
  };

  BraintreeForm.prototype.initialize = function(data) {
    var self = this;

    braintree.client.create({
      authorization: data.client_token
    }, function(clientErr, clientInstance) {
      if (clientErr) {
        self.handleClientError(clientErr);
        return;
      }

      var $source = $('.braintree-input-style');

      braintree.hostedFields.create({
        client: clientInstance,
        fields: {
          number: {
            selector: '#braintree_card_number',
            placeholder: '0000 0000 0000 0000'
          },
          cvv: {
            selector: '#braintree_card_code',
            placeholder: '000'
          },
          expirationDate: {
            selector: '#braintree_card_expiry',
            placeholder: 'MM / YYYY'
          }
        },
        styles: {
          input: {
            'font-family': $source.css('font-family'),
            'font-size': $source.css('font-size'),
            'color': '#ff5000',
            'height': $source.css('height')
          }
        }
      }, function(hostedFieldsErr, instance) {
        if (hostedFieldsErr) {
          self.handleClientError(hostedFieldsErr);
          return;
        }

        self.hostedFieldsInstance = instance;
        disableCardSelector(false);

        self.hostedFieldsInstance.on('cardTypeChange', function(e) {
          // credit card type indicator
          var card = e.cards[0];

          if (card) {
            $('.l-checkout-payment-cards').removeClass(ccClasses);
            var ccClass = ccMap[card.type];

            if (ccClass && !self.hostedFieldsInstance.getState().fields.number.isEmpty) {
              $('.l-checkout-payment-cards').addClass('is-' + ccClass);
            }
          }
        });
      });

      braintree.paypal.create({
        client: clientInstance
      }, function (paypalErr, paypalInstance) {
        if (paypalErr) {
          self.handleClientError(paypalErr);
          return;
        }

        self.paypalFieldsInstance = paypalInstance;

        var $paypalButton = $('.paypal-button');
        $paypalButton.prop('disabled', false);

        $paypalButton.off('click');
        $paypalButton.on('click', function (e) {
          // PayPal button clicked, pop-up displayed
          self.showPayPalOverlay();

          self.payPalCheckoutFlow = self.paypalFieldsInstance.tokenize({
            flow: 'vault'
          }, function (tokenizeErr, payload) {
            if (tokenizeErr) {
              if (tokenizeErr.code !== 'PAYPAL_POPUP_CLOSED') {
                self.handleClientError(tokenizeErr);
              }

              self.hidePayPalOverlay();
              self.usingPayPal = false;
              return;
            }

            // tokenization succeeded
            $paypalButton.prop('disabled', true);
            self.hidePayPalOverlay();
            $('#payment_method_nonce').val(payload.nonce);
            self.usingPayPal = true;

            $('#braintree-paypal-logged-in').removeClass('dn');
            $('#braintree-paypal-logged-out, .braintree-cc-input').addClass('dn');
            $('#bt-pp-email').text(payload.details.email);

            $('#bt-pp-cancel').one('click', function() {
              self.usingPayPal = false;
              $('#braintree-paypal-logged-in').addClass('dn');
              $('#braintree-paypal-logged-out, .braintree-cc-input').removeClass('dn');
              $paypalButton.prop('disabled', false);
              $('#payment_method_nonce').val('');
            })
          });
        });
      });
    });
  };

  BraintreeForm.prototype.showForm = function() {
    $('#payment-method-fields').show();
    $('#payment-methods').show();
    $('.existing-cc-radio').prop('disabled', true);

    if (!this.braintreeLoaded) {
      this.getClientToken(this.initialize.bind(this));
      this.braintreeLoaded = true;
    }
  };

  BraintreeForm.prototype.hideForm = function() {
    $('#payment-method-fields').hide();
    $('#payment-methods').hide();
    $('.existing-cc-radio').prop('disabled', false);
  };

  BraintreeForm.prototype.showPayPalOverlay = function() {
    var self = this;

    $('.bt-overlay').removeClass('dn');
    $('.bt-close-overlay').off('click');
    $('.bt-close-overlay').one('click', function() {
      self.hidePayPalOverlay();
      self.payPalCheckoutFlow.close();
      self.payPalCheckoutFlow = null;
    });

    $('.bt-paypal-continue').off('click');
    $('.bt-paypal-continue').on('click', function() {
      self.payPalCheckoutFlow.focus();
    });
  };

  BraintreeForm.prototype.hidePayPalOverlay = function() {
    $('.bt-overlay').addClass('dn');
    $('.bt-paypal-continue').off('click');
  };

  BraintreeForm.prototype.handleClientError = function(error) {
    var $errorsDiv = $('<div>', { class: 'm-errors' })
      .append($('<div>', { class: 'errorExplanation' })
        .append($('<p>', { text: 'There was a problem with your payment information. Please check your information and try again.' })));

    if (error.details && error.details.invalidFieldKeys) {
      var list = $('<ul>').appendTo($('.errorExplanation', $errorsDiv));
      $.each(error.details.invalidFieldKeys, function (i) {
        $('<li>', {
          text: error.details.invalidFieldKeys[i] + ' is required'
        }).appendTo(list);
      });
    }

    if ($('.m-errors').length == 0) {
      $errorsDiv.prependTo("#content");
    } else {
      $('.m-errors').replaceWith($errorsDiv);
    }
  };

  $(document).on('ready', function() {
    if ($('#payment-method-fields').find("input[type=radio][name='order[payments_attributes][][payment_method_id]']").length) {
      braintreeForm = new BraintreeForm();
      paymentId = $("form input[type=radio][name='order[payments_attributes][][payment_method_id]']:checked").val();

      if ($('[name=use_existing_card]').length > 0) {
        // register event
        $('[name=use_existing_card]').on('change', function() {
          if ($('[name=use_existing_card]:checked').val() === 'no') {
            braintreeForm.showForm();
          } else {
            braintreeForm.hideForm();
          }
        });

        if ($('[name=use_existing_card]:checked').val() === 'no') {
          // new card selected
          braintreeForm.showForm();
        }
      } else {
        // no existing cards, show new payment form
        braintreeForm.showForm();
      }

      $('#checkout_form_payment').on('submit', function(e) {
        e.preventDefault();
        var checkoutForm = this;

        if ($('[name=use_existing_card]:checked').val() !== 'yes' && !braintreeForm.usingPayPal) {
          // new credit card
          braintreeForm.hostedFieldsInstance.tokenize({
            vault: true
          }, function (tokenizeErr, data) {
            if (tokenizeErr) {
              braintreeForm.handleClientError(tokenizeErr);
              $('button.continue').prop('disabled', false);
              return;
            } else {
              $('#payment_method_nonce').val(data.nonce);
              checkoutForm.submit();
            }
          });
        } else {
          checkoutForm.submit();
        }
      });
    }
  });

  function disableCardSelector(disabled) {
    $('[name=use_existing_card]').prop('disabled', disabled);
    $('#paypal-button').toggle(!disabled);
  }
})();
