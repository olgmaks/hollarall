module ErrorHelper
  include ::ErrorMessageHelper

  def error_message_for(error_code, extra_details = nil)
    case error_code
    when ErrorCode::ORDER_PRODUCTS_REMOVED
      order_items_removed_error_message
    when ErrorCode::ORDER_PRODUCTS_ADJUSTED
      order_items_adjusted_error_message
    when ErrorCode::ORDER_MIN_QUANTITY_NOT_HIT
      order_minimum_quantity_error_message
    when ErrorCode::ORDER_MAX_PRODUCT_PER_CUSTOMER_HIT
      order_limit_per_customer_error_message(extra_details)
    when ErrorCode::ORDER_MAX_PRODUCT_PER_ORDER_HIT
      order_limit_per_order_error_message(extra_details)
    when ErrorCode::ORDER_MAX_PRODUCT_PER_GROUP_HIT
      order_limit_per_group_error_message(extra_details[:group_limit])
    end
  end
end
