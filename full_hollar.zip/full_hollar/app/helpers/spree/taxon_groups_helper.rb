module Spree
  module TaxonGroupsHelper
    def nav_group
      @nav_group ||= Spree::TaxonGroup.find_by(name: 'Navigation Menu')
    end
  end
end
