module Spree
  module HolidaysHelper
    def taxons
      ::Spree::Taxon.all.pluck(:name, :id)
    end
  end
end
