module Spree
  module Core
    module ControllerHelpers
      Order.module_eval do
        def current_order(options = {})
          options[:create_order_if_necessary] ||= false

          return @current_order if @current_order
          @current_order = find_order_by_token_or_user(options, true)

          if options[:create_order_if_necessary] && (@current_order.nil? || @current_order.completed?)
            @current_order = Spree::Order.new(current_order_params)
            @current_order.user ||= try_spree_current_user
            # See issue https://github.com/spree/spree/issues/3346 for reasons why this line is here
            @current_order.created_by ||= try_spree_current_user
            @current_order.save!
          end

          if @current_order
            @current_order.last_ip_address = ip_address
            return @current_order
          end
        end

        def current_gift_card_order
          incomplete_orders.giftcards.first
        end

        def set_current_order
          if try_spree_current_user && current_order
            try_spree_current_user.orders.incomplete.where('id != ?', current_order.id).each do |order|
              next if order.gift_card? || current_order.gift_card? || order.contains_gift_card? 
              current_order.merge!(order, try_spree_current_user)
            end
          end
        end

        private

        def find_order_by_token_or_user(options = {}, with_adjustments = false)
          options[:lock] ||= false
          # Find any incomplete orders for the guest_token
          if with_adjustments
            order = Spree::Order.incomplete.includes(:adjustments).lock(options[:lock]).find_by(current_order_params)
          else
            order = Spree::Order.incomplete.lock(options[:lock]).find_by(current_order_params)
          end

          if order.nil? && try_spree_current_user
            order = incomplete_orders.not_giftcards.first
          end

          order
        end

        def incomplete_orders
          Spree::Order.incomplete.where(user_id: current_order_params[:user_id]).order(created_at: :desc)
        end
      end
    end
  end
end
