module Spree
  module PodHelper
    def self.destination_url(view, pod, params)
      req_params = params.select { |p| p.starts_with? 'utm_' }.merge!(htm_source: 'hpcarousel')

      req_params[:htm_position] = pod.position unless pod.position.nil?

      begin
        if pod.url.present?
          pod_uri = URI.parse(pod.url)

          # merge in req_params into the query if this is local
          if pod_uri.host.nil?
            pod_uri.query = Rack::Utils.parse_query(pod_uri.query).merge(req_params).to_query
          end

          return pod_uri.to_s
        end
      rescue URI::InvalidURIError
        return pod.url # oh well, just do it
      end

      if pod.taxon_destination.present?
        req_params[:id] = pod.taxon_destination.permalink
        req_params[:htm_content] = pod.taxon_destination.permalink
        view.spree.nested_taxons_url(req_params)
      elsif pod.product_ids.count == 1
        product = Spree::Product.find(pod.product_ids.first)
        req_params[:id] = product
        req_params[:htm_content] = product.slug
        view.spree.product_url(req_params)
      else
        req_params[:id] = pod.id
        view.pod_url(req_params.symbolize_keys)
      end
    end
  end
end
