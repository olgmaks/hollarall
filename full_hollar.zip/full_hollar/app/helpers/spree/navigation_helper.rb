module Spree
  module NavigationHelper
    def user_dashboard
      if spree_current_user
        link_to "My Account", account_path
      else
        link_to "Sign In", login_path
      end
    end

    def taxonomy_list(name)
      list = footer_taxonomies.select { |taxonomy| taxonomy.name.casecmp(name) } if footer_taxonomies
      return OpenStruct.new(published_children: []) unless list && list[0]
      list[0].root
    end

    def shelf_groups
      @shelf_groups ||= ::ShelfGroup.includes(:shelves).published
    end

    def footer_taxonomies
      @taxonomies ||= ::Spree::Taxonomy.includes(root: :children)
    end

    def cache_key_for_homepage_products(user, with_recommendations)
      count = @products.count
      shelf = Shelf.homepage_for_user(user, with_recommendations)
      product_ids_hash = Digest::MD5.hexdigest(@products.map(&:id).join(','))
      max_updated_at = ([shelf && shelf.updated_at,
                         @products.map(&:updated_at).compact.max,
                         @products.map(&:available_on).compact.max].compact.max ||
                        DateTime.current).utc.to_s(:number)
      "#{I18n.locale}/#{current_currency}/spree/products/#{product_ids_hash}/all-#{params[:page]}-" +
        "#{max_updated_at}-#{count}" +
        feature_cache_keys(:product_likes, :quick_cart, :mobile_single_page,
                           :no_original_prices, :sort_and_filter, :dropdown_navigation).join("-")
    end

    def category_taxonomy
      ::Spree::Taxonomy.find_by name: "category"
    end
  end
end
