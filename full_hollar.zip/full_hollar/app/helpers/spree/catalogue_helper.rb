module Spree
  module CatalogueHelper
    INDEX_TAXONOMIES    = ['category'].freeze
    CARD_TAXONOMIES     = %w(gifts party holiday).freeze
    PARTY_TAXONOMY      = 'party'.freeze
    NEW_TAXONOMY_PERIOD = 10

    def thumbnail_url(preferred_style)
      preferred_style ? (preferred_style + "_retina").to_sym : :small
    end

    def variant_first_image(variant, style, classes)
      return unless variant.images.any?
      image_tag(variant.images.first.attachment.url(style), class: classes)
    end

    def taxon_listing_title(taxon)
      return taxon.name unless taxon.root?

      unless FeatureFlags[:dropdown_navigation].enabled?
        case taxon.permalink
        when 'gifts'
          return 'Shop Gifts'
        when 'party'
          return 'Shop Party'
        when 'category'
          return 'Shop by Category'
        end
      end

      if CARD_TAXONOMIES.include?(taxon.permalink) || INDEX_TAXONOMIES.include?(taxon.permalink)
        taxon.name
      end
    end

    def taxon_listing_class(taxon)
      class_name = taxon.root? ? "l-taxon--#{taxon.name.downcase}" : "l-taxon--sub"
      class_name += " " + class_name + (FeatureFlags[:sort_and_filter].enabled?(spree_current_user) ? "-taxopts" : "-notaxopts")
      class_name
    end

    def taxon_new_flag(taxon)
      if DateTime.now <= taxon.created_at + NEW_TAXONOMY_PERIOD.days
        true
      end
    end

    def subtaxons_tree(subtaxon, depth)
      if depth == 1
        parent = subtaxon
      elsif depth == 2
        parent = subtaxon.parent
      end

      subtaxon_collection = parent.published_children.unshift(parent)

      parent_title = content_tag(:h4, parent.name)

      subtaxon_children = content_tag :ul, class: 'l-taxon-subtaxons' do
        subtaxon_collection.map.each do |taxon|
          next unless taxon.display_web?
          css_class = (taxon == subtaxon) ? 'current' : nil
          content_tag :li, class: css_class do
            link_to(((taxon == parent) ? "All " : "") + taxon.name, seo_url(taxon))
          end
        end.join("\n").html_safe
      end

      parent_title.concat(subtaxon_children)
    end

    def format_price_cents(price)
      format('%#.2d', (price.frac * 100).round)
    end

    def format_variant_shipping(variant)
      if variant.product.merchant && !variant.product.merchant.is_marketplace
        "Eligible for free shipping"
      elsif !variant.shipping_price_standard
        "Shipping cost unknown"
      elsif variant.shipping_price_standard.to_f == 0.0
        "Free shipping"
      else
        format('%#.2f', variant.shipping_price_standard.to_f)
      end
    end
  end
end
