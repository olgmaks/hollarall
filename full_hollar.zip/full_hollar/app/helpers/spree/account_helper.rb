module Spree
  module AccountHelper
    def self.billing_address(user)
      return user.bill_address if user.bill_address.present?

      user.build_bill_address(country: Spree::Country.first)
    end

    def self.shipping_address(user)
      return user.ship_address if user.ship_address.present?

      Spree::Address.new(country: Spree::Country.first)
    end

    def self.have_states(address)
      return false unless address
      return false unless address.country

      address.country.states.any?
    end
  end
end
