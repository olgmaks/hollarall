::Spree::Api::ApiHelpers.module_eval do
  [:brand_new, :max_product_per_order, :max_product_per_customer, :out_of_stock].each do |a|
    product_attributes << a
  end

  [:max_product_per_order,
   :max_product_per_customer,
   :regular_price,
   :marketplace_shipping_price].each do |a|
    line_item_attributes << a
  end

  [:recurring_user, :invite_code].each do |a|
    user_attributes << a
  end

  [:saved_amount,
   :promo_total,
   :free_shipping,
   :gift_card].each do |a|
    order_attributes << a
  end

  class_variable_set(:@@error_attributes, [:status, :code, :message, :params])
  class_variable_set(:@@payment_method_attributes, [:id, :name, :description, :type])
  class_variable_set(:@@creditcard_attributes, [:id, :month, :year, :cc_type, :last_digits, :name, :email])
  class_variable_set(:@@merchant_attributes, [:id, :name, :shop_name, :description, :is_marketplace, :return_policy, :shipping_policy])

  mattr_reader :merchant_attributes

  def filter_out_incidental_errors(error_hash, context)
    {}.tap do |new_error_hash|
      error_hash.each do |element, errors|
        # don't include state-transition messages in show context
        next if element == :state && context == :show

        new_errors = errors.reject do |message|
          # don't include no-action-required errors
          [
            Spree.t(:ship_address_required),
            Spree.t("store_credit.errors.unable_to_fund")
          ].include?(message) && context == :show
        end

        if new_errors.present?
          new_error_hash[element] = new_errors
        end
      end
    end
  end

  def errors_to_messages(errors, context = :default)
    hash_errors = filter_out_incidental_errors(errors.to_hash, context)
    hash_errors.fetch(:base, []) + hash_errors.except(:base).map do |k, v|
      [k.to_s.humanize, v].join(" ")
    end
  end

  def code_for_message(_message)
    nil
  end

  def errors_to_coded_messages(errors, context = :default)
    errors_to_messages(errors, context).map do |m|
      { message: m }.tap do |h|
        code = code_for_message(m)
        if code
          h[:code] = code
        end
      end
    end
  end

  def cart_hollar_free_shipping_message(order)
    if order.free_shipping?
      "Congratulations! Shipping is FREE for Hollar items!"
    else
      display_amount = order.display_amount_remaining_for_free_shipping
      "#{display_amount} away from FREE shipping on Hollar items!"
    end
  end

  def cart_hollar_free_shipping_progress(order)
    (order.free_shipping_required_item_total - order.amount_remaining_for_free_shipping) /
      order.free_shipping_required_item_total.to_f
  end

  def mobile_client?
    %w(ios android).include?(params[:app_platform])
  end
end
