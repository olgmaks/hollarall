::Spree::Api::ApiHelpers.module_eval do
  def discount_table_attributes(product)
    return {} unless product.bundle_type_party? || product.bundle_type_case?

    {
      display_price_label: display_price_label(product),
      display_price:       display_price(product),
      discount_table:      discount_table(product)
    }
  end

  def discount_table(product)
    table = product.bundle_type_party? ? party_bundle_discount_table(product) : case_bundle_discount_table(product)
    table << { top_line: 'You Pay', bottom_line: number_to_price(product.price) }
  end

  def case_bundle_discount_table(product)
    [
      {
        top_line:    'Unit',
        bottom_line: number_to_price(product.bundle_unit_price)
      },
      {
        top_line:    'Qty',
        bottom_line: product.master.bundle_quantity.to_s
      }
    ]
  end

  def party_bundle_discount_table(product)
    [
      {
        top_line:    'Value',
        bottom_line: number_to_price(product.regular_price, no_cents: true)
      },
      {
        top_line:    'Discount',
        bottom_line: "#{(((product.regular_price - product.price) / product.regular_price) * 100).floor}%"
      }
    ]
  end

  def display_price(product)
    if product.bundle_type_party?
      number_to_price(product.price / product.master.bundle_quantity)
    else
      number_to_price(product.bundle_unit_price)
    end
  end

  def display_price_label(product)
    product.bundle_type_party? ? 'Per Guest' : 'Each'
  end
end
