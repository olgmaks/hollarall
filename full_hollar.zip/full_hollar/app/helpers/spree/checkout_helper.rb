module Spree
  module CheckoutHelper
    def checkout_states
      @order.checkout_steps
    end

    def checkout_progress
      states = checkout_states.reject { |key| key == 'delivery' }
      items = states.map do |state|
        css_classes = []
        current_index = states.index(@order.state)
        state_index = states.index(state)

        text = (state_index + 1).to_s + " " + Spree.t("order_state.#{state}").titleize

        if current_index && state_index < current_index
          css_classes << 'completed'
          text = link_to text, checkout_state_path(state)
        end

        css_classes << 'is-next' if current_index && state_index == current_index + 1
        css_classes << 'is-current' if state == @order.state
        css_classes << 'is-first' if state_index == 0
        css_classes << 'is-last' if state_index == states.length - 1

        extra_classes = ''
        extra_classes += ' b-col--shift-1' if state_index == 0
        # It'd be nice to have separate classes but combining them with a dash helps out for IE6,
        # which only sees the last class
        content_tag('li', content_tag('span', text),
                    class: 'l-checkout-step b-col--2' + ' ' + css_classes.join(' ') + extra_classes)
      end
      content_tag('ol', raw(items.join("\n")),
                  class: 'l-checkout-progress b-row', id: "checkout-step-#{@order.state}")
    end

    def available_store_credit_for_order(order)
      return 0 if order.nil? || order.user.nil? || order.user.store_credit_amount.nil?

      if order.user.store_credit_amount < order.outstanding_balance
        order.user.store_credit_amount
      else
        order.outstanding_balance
      end
    end
  end
end
