module Spree
  module Admin
    module ShelvesHelper
      def shelf_taxons
        Taxon.with_shelves
      end

      def shelves
        @shelves ||= Shelf.pluck(:name, :id)
      end

      def groups
        @groups ||= ShelfGroup.pluck(:name, :id)
      end

      def default_engine
        Rails.application.routes.url_helpers
      end
    end
  end
end
