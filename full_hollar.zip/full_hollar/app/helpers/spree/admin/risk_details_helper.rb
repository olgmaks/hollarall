module Spree
  module Admin
    module RiskDetailsHelper
      def traverse(hash)
        hash.map do |key, value|
          content = table_template(
            content: collection_traverse(value)
          ) if [Array, Hash].include?(value.class)

          row_template(header: key.to_s.humanize, content: content || value)
        end.join.html_safe
      end

      private

      def collection_traverse(collection)
        Array[collection].flatten.map(&method(:traverse)).join.html_safe
      end

      def table_template(content:)
        content_tag(:table) { content_tag(:tbody, content) }
      end

      def row_template(header:, content:)
        content_tag(:tr) { content_tag(:th, header) + content_tag(:td, content) }
      end
    end
  end
end
