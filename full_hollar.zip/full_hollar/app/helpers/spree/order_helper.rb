module Spree
  module OrderHelper
    def friendly_shipment_state(order)
      friendly_states = {'ready'=>'processing', 'pending'=>'processing', 'partial'=>'partially shipped'}
      friendly_states.fetch(order.shipment_state, order.shipment_state).try(:titleize)
    end
  end
end
