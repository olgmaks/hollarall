module Spree
  module CartFormHelper
    def option_array(option_values)
      option_values.map do |opt|
        [
          opt.name, opt.presentation.downcase,
          data: { "option-type-id" => opt.option_type.id, "option-value-id" => opt.id }
        ]
      end
    end

    def option_values(variant)
      values = {
        'data-price' => variant.price_in(current_currency).money,
        'data-options' => all_option_values_by_id(variant).map { |a| a.join("=") }.join(",")
      }

      variant.option_values.each do |ov|
        values["data-option-#{ov.option_type.id}"] = ov.id
      end

      values
    end

    def min_checkout_amount
      ::Spree::Order.minimum_checkout_amount
    end

    def display_savings(order)
      order.saved_amount
    end

    def master_sold_out(product)
      !product.available? || (!product.variants_and_option_values(current_currency).any? && product.total_on_hand < 1)
    end

    def all_option_values_by_id(variant)
      variant.option_values.sort_by { |ov| ov.option_type.id }.map { |ov| [ov.option_type.id, ov.id] }
    end
  end
end
