module ErrorMessageHelper
  # Order
  def order_minimum_quantity_error_message
    "A $#{::Spree::Order.minimum_checkout_amount} minimum order is required to checkout."
  end

  def order_items_removed_error_message
    "We're sorry, the following items have sold out:"
  end

  def order_items_adjusted_error_message
    "Due to insufficient stock, we've updated quantity for:"
  end

  def order_limit_per_order_error_message(product)
    "Limit #{product.max_product_per_order} per order"
  end

  def order_limit_per_group_error_message(limit)
    "The following items are limited to the combined total of #{limit} per order:"
  end

  def order_limit_per_customer_error_message(product)
    "The following item is limited to #{product.max_product_per_customer} per customer:"
  end
end
