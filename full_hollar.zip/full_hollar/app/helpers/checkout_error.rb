module CheckoutError
  extend ActiveSupport::Concern
  include ::ErrorHelper

  def insufficient_stock_error(error_code, variants)
    message = error_message_for(error_code)

    details = []
    variants.each do |variant|
      details << variant_details(variant)
    end

    { code: error_code, message: message, details: details,
      full_message: [message, variants.map(&:name)].join("\n") }
  end

  def max_product_per_group_reached_error(error_code, details)
    message = error_message_for(error_code, details)

    { code: error_code, message: message, details: group_details(details[:items]),
      full_message: [message, details[:items].map(&:variant).map(&:name)].join("\n") }
  end

  def max_product_reached_error(error_code, variant)
    message = error_message_for(error_code, variant.product)
    details = [variant_details(variant)]

    { code: error_code, message: message, details: details,
      full_message: [message, variant.name].join("\n") }
  end

  def minimum_quantity_error
    error_code = ::ErrorCode::ORDER_MIN_QUANTITY_NOT_HIT
    message = error_message_for(error_code)

    { code: error_code, message: message, full_message: message }
  end

  private

  def group_details(items)
    items.map { |i| { product_name: i.product.name, product_id: i.product.id } }
  end

  def variant_details(variant)
    product = variant.product
    { variant_id: variant.id, product_id: product.id,
      product_name: product.name }
  end
end
