module ApplicationHelper
  def render_notification(classes)
    snippet = render_snippet('/notification')
    return unless snippet
    "<div class='#{classes}'> #{markdownize(snippet)} </div>".html_safe
  end

  def markdownize(text)
    renderer = Redcarpet::Render::HTML.new({})
    markdown = Redcarpet::Markdown.new(renderer, autolink: true)

    markdown.render(text).html_safe
  end

  def taxon_hierarchy(taxon)
    h = [taxon]
    h << h.last.parent while h.last.parent
    h.reverse
  end

  FEATURE_CACHE_KEYS = {
    quick_cart: %w(nq qc),
    mobile_single_page: %w(nms msp),
    no_original_prices: %w(op nop),
    sort_and_filter: %w(nsf sf),
    dropdown_navigation: %w(nddn ddn)
  }.freeze

  def feature_cache_keys(*keys)
    keys.map do |k|
      key_classes = FEATURE_CACHE_KEYS.fetch(k, ["ff#{k}off", "ff#{k}on"])
      key_classes[FeatureFlags[k].enabled?(spree_current_user) ? 1 : 0]
    end
  end

  def rel_next_prev_link_tags(scope, options = {})
    if spree_current_user && FeatureFlags[:product_recommendations].enabled?(spree_current_user)
      options[:personalization] = spree_current_user.product_recommendation_basis.to_s
    end
    super(scope, options)
  end

  private

  def inline_svg(path)
    file_path = Rails.root.join('app', 'assets', 'images', path)
    file = File.open(file_path, 'rb')
    raw file.read
  end
end
