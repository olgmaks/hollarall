class PrimaryProductWorker < ActiveJob::Base
  queue_as :medium_priority

  def perform(variant)
    @variant = variant
    @duplicate_variants = ::Spree::Variant.where('vendor_upc = ? OR vendor_item_number = ?',
                                                 variant.vendor_upc, variant.vendor_item_number)
    update_primary
  end

  def update_primary
    products_ids = @duplicate_variants.map(&:product_id).uniq
    duplicates = ::Spree::Product.where(primary_product_id:  products_ids)
    if !duplicates.empty?
      duplicate = duplicates.first
      if !duplicate.primary_product_id.nil?
        make_duplicate(duplicate.primary_product_id, @variant.product_id)
      elsif !(id = duplicates.index { |d| d.sold_by_hollar? == true }).nil?
        make_primary(duplicates[id])
        make_duplicate(duplicates[id], @variant.product_id)
      else
        make_primary(duplicate.id)
        make_duplicate(duplicate.id, @variant.product_id)
      end
    elsif !@duplicate_variants.empty?
      primary = @duplicate_variants.first.product_id
      make_primary(primary)
      make_duplicate(primary, @variant.product_id)
    else
      make_primary(@variant.product_id)
    end
  end

  def make_primary(primary_id)
    make_duplicate(primary_id, primary_id)
  end

  def make_duplicate(primary_id, dup_id)
    product = ::Spree::Product.find(dup_id)
    product.update_attribute(:primary_product_id, primary_id.to_i)
  end
end
