class ShelvesReloadWorker < ActiveJob::Base
  queue_as :high_priority

  def perform
    shelves.each { |shelf| reload!(shelf) }
  end

  private

  def reload!(shelf)
    service.call(source: shelf)
  end

  def service; ShelfReloadService; end

  def shelves
    @shelves ||= Shelf.autoloaded
  end
end
