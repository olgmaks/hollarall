# Actually just a predefinition of Searchkick::ReindexV2Job
# to make Searchkick's reindex_async use it
require 'searchkick/reindex_v2_job'

# And override the queue for this job
module Searchkick
  class ReindexV2Job
    queue_as :low_priority
  end
end

# pro forma definition
class SearchkickWorker < Searchkick::ReindexV2Job
end
