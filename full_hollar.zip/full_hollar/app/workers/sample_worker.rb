class SampleWorker < ActiveJob::Base
  queue_as :low_priority

  def perform(s)
    puts s
  end
end
