class AssessmentsWorker < ActiveJob::Base
  queue_as :high_priority

  attr_reader :order

  def perform(params)
    @order = ::Spree::Order.find(params[:order_id])
    return order.cartonize_shipments unless params[:ip_address]

    shipping_params = addressable_params(:shipping).merge(delivery_speed: :standard)
    billing_params  = addressable_params(:billing)

    client = ::Minfraud::Assessments.new(
      device:        ::Minfraud::Components::Device.new(params),
      event:         ::Minfraud::Components::Event.new(event_params),
      email:         ::Minfraud::Components::Email.new(email_params),
      billing:       ::Minfraud::Components::Billing.new(billing_params),
      shipping:      ::Minfraud::Components::Shipping.new(shipping_params),
      order:         ::Minfraud::Components::Order.new(order_params),
      credit_card:   ::Minfraud::Components::CreditCard.new(credit_card_params),
      shopping_cart: ::Minfraud::Components::ShoppingCart.new(shopping_cart_params)
    )

    finalize(client.insights.body) do
      order.create_quarantine(reason: 'minFraud score is above the threshold')
      order.virtual_gift_card.update(redeemable: false) if order.contains_gift_card?
      order.create_assessment_comment(
        quarantine:       true,
        customer_service: ::Spree::User.find_by(email: SUPPORT_EMAIL),
      )
    end unless finalize(client.score.body)
  rescue ::Minfraud::BaseError => e
    Rails.logger.warn("Minfraud Exception: #{e.message}")
  end

  private

  def event_params
    {
      transaction_id: order.number,
      shop_id:        order.store_id,
      time:           order.completed_at.to_datetime.rfc3339,
      type:           (order.user && !order.user.first_order?) ? :recurring_purchase : :purchase
    }
  end

  def email_params
    email = (order.user || order).email
    {
      address: email,
      domain:  Mail::Address.new(email).domain
    }
  end

  def addressable_params(key)
    address = order.send("#{key}_address")
    {
      first_name:   address.firstname,
      last_name:    address.lastname,
      company:      address.company,
      address:      address.address1,
      address_2:    address.address2,
      city:         address.city,
      country:      address.country.iso,
      postal:       address.zipcode,
      phone_number: address.phone
    }
  end

  def credit_card_params
    payment = order.payments.valid.try(:first)
    return {} unless payment && payment.source.is_a?(Spree::CreditCard)
    {
      issuer_id_number: payment.number,
      last_4_digits:    payment.source.last_digits
    }
  end

  def order_params
    {
      amount:   order.total.to_f,
      currency: order.currency
    }
  end

  def shopping_cart_params
    order.line_items.map(&method(:shopping_cart_item_params))
  end

  def shopping_cart_item_params(item)
    {
      item_id:  item.id,
      quantity: item.quantity,
      price:    item.price.to_f
    }
  end

  def finalize(response)
    order.assessment ||= order.create_assessment
    order.assessment.update(
      risk_score: response.risk_score,
      details:    response.except(:risk_score, :warnings, :queries_remaining, :funds_remaining)
    )

    return order.cartonize_shipments unless response.risk_score.to_f > Hollar::Config.minfraud_threshold
    yield if block_given?
  end

  SUPPORT_EMAIL = 'support@hollar.com'.freeze
end
