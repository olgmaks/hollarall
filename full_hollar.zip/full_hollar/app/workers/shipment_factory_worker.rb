class ShipmentFactoryWorker < ActiveJob::Base
  queue_as :medium_priority

  def perform(order_id)
    @order = ::Spree::Order.find(order_id)
    return if @order.quarantine

    # NOTE(cab): We want to have the possibility to disable the
    # Ratelinx workflow if anything goes wrong.
    #
    # If deactivated, it would send everything directly to Snapfulfil like it
    # was previously doing.
    @order.shipments.each do |shipment|
      next if shipment.ready? || shipment.stock_location.dropship?

      if ratelinx_life_cycle?
        ratelinx_service = Ratelinx::RatelinxService.new(shipment)
        ratelinx_service.process_cartonization
      else
        Rails.logger.info("Not running ratelinx service, since Ratelinx is turned off")
      end
    end

    # NOTE(cab): Since the above may split shipments to many different other
    # shipments, we have to re-loop against all the shipments of the order.
    @order.shipments.each do |shipment|
      unless shipment.stock_location.dropship?
        snap_service = Snapfulfil::SnapfulfilService.new(shipment)
        snap_service.send_shipment_to_wms
        snap_service.send_attachment_to_wms
      end

      shipment.ready
    end

    # NOTE(cab): There seem to have a problem with missing callbacks, when
    # changing all the shipments of an order to "ready", the
    # order.shipment_state method still returns "pending".
    #
    # For this not to happen, we force it to recheck the states of the order
    # and change it if need be.
    @order.update!
  end

  private

  attr_reader :order

  def ratelinx_life_cycle?
    ENV.fetch('RATELINX_ENABLED', false) != 'false'
  end
end
