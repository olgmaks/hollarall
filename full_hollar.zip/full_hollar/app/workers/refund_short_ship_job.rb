class RefundShortShipJob < ActiveJob::Base
  queue_as :medium_priority
  SHORT_SHIP_CREDIT = 2.0

  rescue_from(Spree::Core::GatewayError) do
    retry_job queue: :low_priority, wait: 1.hour
    raise
  end

  def perform(order, shipment)
    @order = order
    @shipment = shipment
    @refunded = 0
    @adjustments = @shipment.get_short_ship_adjustments
    @amount = @adjustments.map(&:amount).sum.abs
    @reason = Spree::RefundReason.find_by(name: "Out of Stock")
    @payments = @order.payments.
                where(state: "completed").
                where('amount > 0.00').
                where(source_type: ["Spree::PaypalExpressCheckout", "Spree::CreditCard",
                                    "Spree::PaypalApiCheckout"]).
                order(:amount)
    @payments += @order.payments.
                 where(state: "completed").
                 where('amount > 0.00').
                 where(source_type: "Spree::StoreCredit").
                 order(:amount)
    refund_payments
    finalize if @refund
  end

  def finalize
    if @order.user
      @order.user.store_credits.create!(category_id: Spree::StoreCreditCategory.find_by(name: "Out of Stock").id,
                                        created_by_id: Spree::User.find_by(email: 'support@hollar.com').id,
                                        currency: @order.currency, amount: SHORT_SHIP_CREDIT,
                                        type_id: Spree::StoreCreditType.first.id)
      @order.send_short_ship_refund_email(@shipment)
      create_comment
    end
    @order.shipments.reload
    @order.update!
  end

  def paypal?(payment)
    payment.payment_method.type == 'Spree::Gateway::PayPalExpress'
  end

  def create_comment
    items = []
    @shipment.get_short_shipped_items.each { |i| items << i.variant.product.name }
    Spree::Comment.new(user_id: @order.user ? @order.user.id : nil,
                       customer_service_id: Spree::User.find_by(email: 'support@hollar.com').id,
                       text: "Items short-shipped: #{items.join(', ')}. " +
                       "Refunded #{Spree::Money.new(@refunded, currency: @order.currency)}." +
                       " Applied store credit of #{Spree::Money.new(SHORT_SHIP_CREDIT, currency: @order.currency)}",
                       comment_type: "Outbound",
                       channel: "Email",
                       reason: "OOS",
                       detailed_reason: "Short Ship",
                       order: @order).save
  end

  def refund_payments
    if @order.payment_state != "credit_owed"
      return @refund = @order.refunds.where(refund_reason_id: @reason.id).last
    end
    main_payment = @payments.shift
    refunds = @order.refunds.where(payment_id: main_payment.id)
    balance = main_payment.amount - refunds.map(&:amount).sum.abs
    balance = main_payment.amount if balance < 0
    if balance < (@amount - @refunded)
      if paypal?(main_payment)
        @refund = main_payment.payment_method.refund(main_payment, balance)
      else
        @refund = Spree::Refund.create!(payment: main_payment, refund_reason_id: @reason.id, amount: balance)
      end
      @refunded += balance
      refund_payments while @refunded < @amount
    else
      remaining_amount = @amount - @refunded
      if paypal?(main_payment)
        @refund = main_payment.payment_method.refund(main_payment, remaining_amount)
      else
        @refund = Spree::Refund.create!(payment: main_payment, refund_reason_id: @reason.id, amount: remaining_amount)
      end
      @refunded += remaining_amount
    end
  end
end
