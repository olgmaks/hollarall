Deface::Override.new(
  virtual_path: 'spree/admin/pages/_form',
  name:         'page_admin_standalone',
  insert_bottom: '[data-hook="admin_page_form_right"]',
  partial:      'spree/admin/pages/standalone_option'
)
