Deface::Override.new(virtual_path: 'spree/admin/stock_locations/_form',
                     name: 'stock_location_dropship',
                     insert_before: "[data-hook='stock_location_backorderable_default']",
                     partial: 'spree/admin/stock_locations/form_dropship_field')
