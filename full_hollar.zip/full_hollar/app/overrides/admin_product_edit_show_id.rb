Deface::Override.new(virtual_path: 'spree/admin/products/_form',
                     name: 'add_product_id_field',
                     insert_after: "[data-hook='admin_product_form_promotionable']",
                     partial: 'spree/admin/shared/product_id_field')

Deface::Override.new(virtual_path: 'spree/admin/products/_form',
                     name: 'add_bundle_fields',
                     insert_after: "[data-hook='admin_product_form_tax_cloud_tic']",
                     partial: 'spree/admin/shared/product_bundle_fields')
