Deface::Override.new(virtual_path: 'spree/admin/products/_form',
                     name: 'max_product_per_order',
                     insert_after: "[data-hook='admin_product_form_available_on']",
                     partial: 'spree/admin/products/max_product_per_order')

