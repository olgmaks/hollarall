Deface::Override.new(
  virtual_path:  "spree/admin/shared/_configuration_menu",
  name:          "flipper_admin_configurations_menu",
  insert_bottom: "[data-hook='admin_configurations_sidebar_menu']",
  text:          "\n        <%= configurations_sidebar_menu_item Spree.t('admin.flipper'), '/admin/features' %>"
)

Deface::Override.new(
  virtual_path:  "spree/admin/shared/_configuration_menu",
  name:          "admin_minfraud_configuration",
  insert_bottom: "[data-hook='admin_configurations_sidebar_menu']",
  text:          "\n<%= configurations_sidebar_menu_item Spree.t('admin.minfraud_configuration'), edit_admin_minfraud_path %>"
)

Deface::Override.new(
  virtual_path:  "spree/admin/shared/_configuration_menu",
  name:          "admin_site_preferences_configuration",
  insert_bottom: "[data-hook='admin_configurations_sidebar_menu']",
  text:          "\n<%= configurations_sidebar_menu_item 'Site Preferences', edit_admin_site_preferences_path %>"
)

Deface::Override.new(
  virtual_path:  "spree/admin/shared/_configuration_menu",
  name:          "feature_experiments_admin_configurations_menu",
  insert_bottom: "[data-hook='admin_configurations_sidebar_menu']",
  text:          "\n        <%= configurations_sidebar_menu_item Spree.t('admin.feature_experiments'), " +
                 "'/admin/feature_experiments' %>"
)
