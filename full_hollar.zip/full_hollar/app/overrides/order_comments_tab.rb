Deface::Override.new(virtual_path: 'spree/admin/shared/_order_submenu',
                     name: 'add_order_comments_tab',
                     insert_bottom: "[data-hook='admin_order_tabs']",
                     partial: 'spree/admin/shared/order_comment_tab')
