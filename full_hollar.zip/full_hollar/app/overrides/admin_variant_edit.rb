Deface::Override.new(virtual_path: 'spree/admin/variants/_form',
                     name: 'add_variant_bundle_fields',
                     insert_after: "[data-hook='admin_variant_form_additional_fields']",
                     partial: 'spree/admin/shared/variant_bundle_fields')
