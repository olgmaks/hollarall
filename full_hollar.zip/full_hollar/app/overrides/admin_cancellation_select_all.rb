Deface::Override.new(
  virtual_path:      "spree/admin/cancellations/index",
  name:              "select-all",
  replace_contents:  ".stock-contents th:last",
  text:              "Cancel<div><%= link_to 'Select All', 'javascript:;', class: 'js-select-all' %></div>"
)
