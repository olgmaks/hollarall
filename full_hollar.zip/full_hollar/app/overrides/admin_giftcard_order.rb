Deface::Override.new(virtual_path: 'spree/admin/orders/edit',
                     name: 'add_order_giftcard_details',
                     insert_after: "[data-hook='admin_order_edit_header']",
                     partial: 'spree/admin/orders/gift_card_details')
