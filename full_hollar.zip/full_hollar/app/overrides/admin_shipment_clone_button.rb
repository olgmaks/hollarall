Deface::Override.new(virtual_path: 'spree/admin/orders/_shipment',
                     name: 'clone-order-button',
                     insert_after: ".show-tracking",
                     text: %Q{
                     <% unless order.gift_card? %>
                       <tr class='button-only'>
                         <td colspan='5'>
                           <%= link_to 'Clone as New Order', clone_admin_shipment_path(shipment),
                           class: 'fa fa-clone button right', method: :post %>
                         </td>
                       </tr>
                     <% end %>
                    })
