Deface::Override.new(virtual_path: 'spree/admin/taxonomies/_form',
                     name: 'add_image_to_taxonomy',
                     insert_bottom: "[data-hook='admin_inside_taxonomy_form']",
                     partial: 'spree/admin/taxonomies/image_fields')
