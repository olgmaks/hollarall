Deface::Override.new(virtual_path: 'spree/admin/taxons/_form',
                     name: 'add_occacion_fields',
                     insert_bottom: "[data-hook='admin_inside_taxon_form']",
                     partial: 'spree/admin/taxons/occasions_fields')
