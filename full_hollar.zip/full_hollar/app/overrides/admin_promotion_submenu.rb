Deface::Override.new(virtual_path: 'spree/admin/shared/_promotion_sub_menu',
                     name: 'add_scheduled_promotions',
                     insert_bottom: "[data-hook='admin_promotion_sub_tabs']",
                     partial: 'spree/admin/scheduled_promotions/submenu')
