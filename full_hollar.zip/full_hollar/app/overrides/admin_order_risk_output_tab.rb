Deface::Override.new(virtual_path: 'spree/admin/shared/_order_submenu',
                     name: 'admin_order_risk_output',
                     insert_bottom: "[data-hook='admin_order_tabs']",
                     partial: 'spree/admin/shared/order_risk_output_tab')

