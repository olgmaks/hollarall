Deface::Override.new(virtual_path: 'spree/admin/shared/_order_summary',
                     name: 'add_order_creator_email',
                     insert_bottom: ".additional-info",
                     partial: 'spree/admin/orders/creator_email')
