Deface::Override.new(
  virtual_path:  "spree/admin/shared/_product_sub_menu",
  name:          "admin_product_groups",
  insert_bottom: "[data-hook='admin_product_sub_tabs']",
  text:          "\n<%= configurations_sidebar_menu_item Spree.t('admin.groups'), admin_groups_path %>"
)
