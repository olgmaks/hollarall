Deface::Override.new(virtual_path: 'spree/admin/products/_form',
                     name: 'parent',
                     insert_after: "[data-hook='admin_product_form_available_on']",
                     partial: 'spree/admin/products/product_parent')


Deface::Override.new(virtual_path: 'spree/admin/products/_form',
                     name: 'is_hidden',
                     insert_before: "[data-hook='admin_product_form_parent']",
                     partial: 'spree/admin/products/is_hidden')
