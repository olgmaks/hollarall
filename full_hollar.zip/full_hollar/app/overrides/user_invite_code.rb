Deface::Override.new(virtual_path: 'spree/admin/users/edit',
                     name: 'add_invite_code',
                     insert_after: "[data-hook='admin_user_edit_general_settings']",
                     partial: 'spree/admin/users/invite_code')
