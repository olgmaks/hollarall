Deface::Override.new(virtual_path: 'spree/admin/products/_form',
                     name: 'add_regular_price',
                     insert_after: "[data-hook='admin_product_form_price']",
                     partial: 'spree/admin/products/regular_price')
