Deface::Override.new(virtual_path: 'spree/admin/orders/edit',
                     name: 'snap_update_button',
                     insert_after: "[data-hook='admin_order_edit_header']",
                     partial: 'spree/admin/orders/snap_button')
