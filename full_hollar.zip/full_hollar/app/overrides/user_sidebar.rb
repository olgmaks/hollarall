Deface::Override.new(virtual_path: 'spree/admin/users/_sidebar',
                     name: 'add_credit_cards_to_user_sidebar',
                     insert_bottom: "[data-hook='admin_user_tab_options']",
                     partial: 'spree/admin/shared/user_credit_cards_tab')

Deface::Override.new(virtual_path: 'spree/admin/users/_sidebar',
                     name: 'add_notes_to_user_sidebar',
                     insert_bottom: "[data-hook='admin_user_tab_options']",
                     partial: 'spree/admin/shared/user_comment_tab')
