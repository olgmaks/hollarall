Deface::Override.new(virtual_path: "spree/admin/taxons/_form",
                     name: "taxon_icon_field_removal",
                     remove: "erb[loud]:contains(':icon')",
                     closing_selector: "erb[silent]:contains('end')")
