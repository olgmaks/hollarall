module SmartyStreets
  class Lookup
    BASE_URL = 'https://api.smartystreets.com'
    AUTH_ID = ENV['SMARTYSTREETS_AUTH_ID']
    AUTH_TOKEN = ENV['SMARTYSTREETS_AUTH_TOKEN']

    def lookup address
      url = url(URI.encode(address))
      resp = connection.get do |req|
        req.url url
      end

      addresses = JSON.parse(resp.body)
    rescue
      []
    end

    def url encoded_address
      url = "/street-address"
      url << "?street=#{encoded_address}"
      url << "&auth-id=#{AUTH_ID}"
      url << "&auth-token=#{AUTH_TOKEN}"
      url
    end

    private

    def connection
      Faraday.new(url: BASE_URL) do |faraday|
        faraday.request :url_encoded
        faraday.adapter Faraday.default_adapter
      end
    end

  end
end
