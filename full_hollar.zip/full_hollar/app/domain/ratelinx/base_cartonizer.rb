module Ratelinx
  class BaseCartonizer
    def initialize
    end

    private

    def webservice_url
      ENV.fetch('RATELINX_CARTONIZER_HOST')
    end
  end
end
