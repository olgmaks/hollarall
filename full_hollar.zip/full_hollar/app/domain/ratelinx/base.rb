module Ratelinx
  class Base
    def initialize
    end

    class << self
      def client_id
        ENV.fetch('RATELINX_CLIENT_ID', 'Hollar')
      end

      def location_id
        ENV.fetch('RATELINX_LOCATION_ID', '3239')
      end

      def username
        ENV.fetch('RATELINX_USERNAME', 'HollarTester')
      end

      def password
        ENV.fetch('RATELINX_PASSWORD', 'test')
      end
    end

    private

    def webservice_url
      fail(NotImplementedError,
           "Need to define webservice_url for #{self} class")
    end
  end
end
