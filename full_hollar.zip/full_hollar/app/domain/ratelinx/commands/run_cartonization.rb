module Ratelinx
  module Commands
    class RunCartonization < BaseCartonizer
      def initialize(shipment)
        @client = Savon.client(default_options)
        @shipment = shipment
      end

      def perform
        response = @client.call(:run_cartonization, message: content)
        build_response_object(response)
      end

      def content
        "#{parcel_xml}#{shipment_items_xml}"
      end
      alias_method :to_xml, :content

      def parcel_xml(shipment = @shipment)
        generated_xml = escape_content(generate_parcel(shipment))

        node_name = "sXMLData"
        "<#{node_name}>#{generated_xml}</#{node_name}>"
      end

      def shipment_items_xml(shipment = @shipment)
        inventory_units = shipment.inventory_units
        generated_xml = generate_shipment_items(inventory_units)

        node_name = "lShipmentItems"
        "<#{node_name}>#{generated_xml}</#{node_name}>"
      end

      private

      def generate_parcel(shipment)
        @_parcel_template ||= begin
          ::Ratelinx::Templates::Shared::Parcel.new(shipment).to_xml
        end
      end

      def generate_shipment_items(inventory_units)
        @_shipment_items_template ||= begin
          xml_array = []
          inventory_units.group_by(&:variant).each do |group|
            item = group.first
            quantity = group.second.count
            xml_array << ::Ratelinx::Templates::Cartonization::Nodes::ShipmentItem.new(item, quantity).to_xml
          end
          xml_array.join('')
        end
      end

      def escape_content(content)
        # NOTE(cab): Required else what we send is wrong.
        CGI.escapeHTML(content)
      end

      def default_options
        { wsdl: webservice_url,
          log: true, log_level: :debug,
          namespace_identifier: nil,
          convert_request_keys_to: :none }
      end

      def build_response_object(response)
        result = response.body[:run_cartonization_response][:run_cartonization_result]
        Ratelinx::Models::Response.init_from_xml(result)
      end
    end
  end
end
