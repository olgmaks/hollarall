module Ratelinx
  module Models
    class Response
      include Virtus.model
      attribute :packages, [Package]
      attribute :shipping_type, String
      attribute :error_code, String
      attribute :error_description, String

      def error?
        error_code != '0'
      end

      class << self
        def init_from_xml(result)
          xml_result = Nokogiri::XML(result)
          error_code = xml_result.at_css('ErrorNum').content
          error_description = xml_result.at_css('ResultDesc').content
          shipping_type = xml_result.at_css('ShipVia').children.first.content

          packages = build_packages(xml_result)
          new(packages: packages, shipping_type: shipping_type,
              error_code: error_code, error_description: error_description)
        end

        private

        def build_packages(xml)
          packages_node = xml.at_css('Packages')
          packages = []
          return nil if packages_node.nil?

          packages_node.children.each do |package|
            package_id = package.at_css('PackageID').content
            item_list = package.xpath(".//ID[contains(text(), 'BoxContents')]").first.parent.children[1].content
            parcel_id = package.xpath(".//ID[contains(text(), 'BoxID')]").first.parent.children[1].content

            packages << ::Ratelinx::Models::Package.new(package_id: package_id,
                                                        items: split_items(item_list),
                                                        parcel_id: parcel_id)
          end

          packages
        end

        def split_items(item_list)
          items = []
          item_list.split(',').each do |tuple|
            an_item = tuple.split(' ')
            item = {}
            item[:item_number] = an_item[1]
            item[:count] = an_item[0]
            items << item
          end

          items
        end
      end
    end
  end
end
