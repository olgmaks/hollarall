module Ratelinx
  module Models
    class Package
      include Virtus.model

      attribute :package_id, String
      attribute :items, Array[Hash[Symbol => String]]
      attribute :parcel_id, String
    end
  end
end
