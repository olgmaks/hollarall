module Ratelinx
  module Templates
    module Shared
      module Nodes
        class Package
          def initialize(variant)
            @variant = variant
          end

          def to_xml
            build_xml.to_xml(save_with: Nokogiri::XML::Node::SaveOptions::AS_XML | Nokogiri::XML::Node::SaveOptions::NO_DECLARATION).strip
          end

          private

          def build_xml
            Nokogiri::XML::Builder.new do |xml|
              # NOTE(cab): Possible test value DOM and INTL
              xml.Package do
                xml.ActualWeight Ratelinx::Helpers::Converter.ounces_to_lbs(@variant.weight).to_s
              end
            end
          end
        end
      end
    end
  end
end
