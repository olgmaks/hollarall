module Ratelinx
  module Templates
    module Shared
      module Nodes
        class Address
          def initialize(address)
            @address = address
          end

          def to_xml
            build_xml.to_xml(save_with: Nokogiri::XML::Node::SaveOptions::AS_XML | Nokogiri::XML::Node::SaveOptions::NO_DECLARATION).strip
          end

          private

          def build_xml
            @_xml ||= begin
              Nokogiri::XML::Builder.new do |xml|
                xml.Address do
                  xml.Address1 @address.address1
                  xml.Address2 @address.address2
                  xml.City @address.city
                  xml.AddressType address_type
                  xml.Country @address.state.country.iso
                  xml.State @address.state.abbr
                  xml.Zip @address.zipcode
                  xml.Phone @address.phone
                end
              end
            end
          end

          def address_type
            # NOTE(cab): From the doc:
            # https://www.assembla.com/spaces/hollar-development/documents/aoFJZ42Zar5yOCacwqjQXA/download/aoFJZ42Zar5yOCacwqjQXA
            # Page 45
            #
            # Possible RateLinx Values: BILLTO, SHIPTO, RETURN, EXPORTER,
            #                           IMPORTER, ULTIMATE CONSIGNEE.
            # You can use your own values as well.
            'SHIPTO'
          end
        end
      end
    end
  end
end
