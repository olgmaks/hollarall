module Ratelinx
  module Templates
    module Shared
      module Nodes
        class Packages
          # NOTE(cab): We would pass what we want here
          # AKA: the variant or the order.
          def initialize(line_items)
            @line_items = line_items
          end

          def to_xml
            build_xml.to_xml(save_with: Nokogiri::XML::Node::SaveOptions::AS_XML | Nokogiri::XML::Node::SaveOptions::NO_DECLARATION).strip
          end

          private

          def build_xml
            Nokogiri::XML::Builder.new do |xml|
              xml.Packages do
                packages.each do |package|
                  xml.parent << package.to_xml
                end
              end
            end
          end

          def packages
            @_packages ||= begin
              all_packages = []

              @line_items.each do |line_item|
                variant = line_item.variant
                quantity = line_item.quantity

                # NOTE(cab): There is no quantity field.
                # We have to create a package per variant
                quantity.times do
                  all_packages << ::Ratelinx::Templates::Shared::Nodes::Package.new(variant)
                end
              end

              all_packages
            end
          end
        end
      end
    end
  end
end
