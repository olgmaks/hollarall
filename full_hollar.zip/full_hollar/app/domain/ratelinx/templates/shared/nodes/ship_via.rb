module Ratelinx
  module Templates
    module Shared
      module Nodes
        class ShipVia
          def initialize
          end

          def to_xml
            build_xml.to_xml(save_with: Nokogiri::XML::Node::SaveOptions::AS_XML | Nokogiri::XML::Node::SaveOptions::NO_DECLARATION).strip
          end

          private

          def build_xml
            Nokogiri::XML::Builder.new do |xml|
              # NOTE(cab): Possible test value DOM and INTL
              xml.ShipVia "DOM"
            end
          end
        end
      end
    end
  end
end
