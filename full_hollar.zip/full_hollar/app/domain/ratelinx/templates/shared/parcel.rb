module Ratelinx
  module Templates
    module Shared
      class Parcel
        def initialize(shipment)
          @shipment = shipment
        end

        def to_xml
          build_xml.to_xml(save_with: Nokogiri::XML::Node::SaveOptions::AS_XML | Nokogiri::XML::Node::SaveOptions::NO_DECLARATION).strip
        end

        private

        attr_reader :shipment

        def build_xml
          ship_via_node = ::Ratelinx::Templates::Shared::Nodes::ShipVia.new
          packages = ::Ratelinx::Templates::Shared::Nodes::Packages.new(shipment.line_items)
          @_xml ||= begin
            address = ::Ratelinx::Templates::Shared::Nodes::Address.new(shipment.address)

            Nokogiri::XML::Builder.new do |xml|
              # NOTE(cab): Required field per their doc at page 41
              # https://bigfiles.assembla.com/spaces/hollar-development/documents/download/aoFJZ42Zar5yOCacwqjQXA
              xml.RateLinx do
                xml.ClientID   ::Ratelinx::Base.client_id
                xml.Username   ::Ratelinx::Base.username
                xml.Password   ::Ratelinx::Base.password
                xml.LocationID ::Ratelinx::Base.location_id
                xml.ShipDate   ::Ratelinx::Helpers::Converter.format_date(DateTime.current)
                xml.ShipmentID shipment.order_id
                xml.ExpectedCount expected_count
                xml.ShipVia ship_via_node.to_xml
                xml.Addresses do
                  xml.parent << address.to_xml
                end
              end
            end
          end
        end

        def expected_count
          # NOTE(cab): This is required to be 1 at all time for cartonizer
          1
        end
      end
    end
  end
end
