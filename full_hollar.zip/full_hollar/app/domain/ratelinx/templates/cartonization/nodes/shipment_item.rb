module Ratelinx
  module Templates
    module Cartonization
      module Nodes
        class ShipmentItem
          def initialize(item, quantity)
            @item = item
            @quantity = quantity
          end

          def to_xml
            build_xml.to_xml(save_with: Nokogiri::XML::Node::SaveOptions::AS_XML | Nokogiri::XML::Node::SaveOptions::NO_DECLARATION).strip
          end

          private

          def build_xml
            Nokogiri::XML::Builder.new do |xml|
              xml.rlbShipmentItem do
                xml.Length @item.depth.to_s
                xml.Width @item.width.to_s
                xml.Height @item.height.to_s
                xml.IsFoldable @item.product.foldable == true ? 'Y' : 'N'
                xml.Qty @quantity
                xml.Weight Ratelinx::Helpers::Converter.ounces_to_lbs(@item.weight).to_s
                xml.Class 50.0 # NOTE(cab): No idea what this means
                xml.ItemNumber @item.product.item_number
              end
            end
          end
        end
      end
    end
  end
end
