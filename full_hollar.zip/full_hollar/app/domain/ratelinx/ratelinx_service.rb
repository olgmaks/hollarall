module Ratelinx
  class RatelinxService
    class RatelinxError < StandardError
    end

    def initialize(shipment)
      @shipment = shipment
    end

    def process_cartonization
      # NOTE(cab): We don't want to resend to ratelinx if it has already been
      # processed by Ratelinx.
      if shipment.split?
        Rails.logger.info("Cartonization for this shipment #{shipment.number} was already complete / Shipment already splitted")
        return
      end

      Rails.logger.info("Running the cartonization for shipment #{shipment.number}")
      cartonization_obj = ::Ratelinx::Commands::RunCartonization.new(shipment)
      ratelinx_response = cartonization_obj.perform

      if ratelinx_response.error?
        raise RatelinxError, "Unable to retrieve cartonization data ERROR: #{ratelinx_response.error_description} for shipment: #{shipment.number}"
      end

      packaging_service = ::Ratelinx::ShipmentPackagingService.new(shipment, ratelinx_response)
      packaging_service.recompose_shipments
    end

    private

    attr_reader :shipment
  end
end
