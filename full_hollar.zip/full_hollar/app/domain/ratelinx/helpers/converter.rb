module Ratelinx
  module Helpers
    module Converter
      extend ActionView::Helpers::NumberHelper

      class << self
        def format_date(date)
          # NOTE(cab): The date format must be formated to
          # MM/DD/YYYY
          date.strftime("%m/%d/%Y")
        end

        def ounces_to_lbs(float)
          float / 16
        end
      end
    end
  end
end
