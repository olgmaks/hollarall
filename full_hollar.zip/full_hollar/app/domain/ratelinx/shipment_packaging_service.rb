module Ratelinx
  class ShipmentPackagingService
    def initialize(shipment, response_obj)
      @original_shipment = shipment
      @response = response_obj
      @variants = shipment.order.line_items.map(&:variant)
      @shipping_method = find_shipping_method(response_obj.shipping_type)
    end

    def recompose_shipments
      if response.packages.length == 1
        Rails.logger.info("Nothing to split, Ratelinx tells us that this
                          shipment is fine as it is.")
        set_shipment_split_at(original_shipment)

        original_shipment.parcel_id = response.packages.first.parcel_id
        original_shipment.save
        return true
      end

      Rails.logger.info("Splitting the packages")
      response.packages.each do |package|
        new_shipment = split_shipment(package)
        set_shipment_shipping_method(new_shipment)
        set_shipment_split_at(new_shipment)
      end

      # NOTE(cab): We split the shipment to x other shipments, we want to
      # make sure to delete the original shipment
      original_shipment.destroy
    end

    private

    attr_reader :variants, :response, :shipping_method, :original_shipment

    def split_shipment(package)
      new_shipment = ::Spree::Shipment.create
      new_shipment.stock_location = original_shipment.stock_location
      new_shipment.order = original_shipment.order
      new_shipment.address = original_shipment.address
      new_shipment.parcel_id = package.parcel_id

      package.items.each do |item|
        new_shipment = transfer_shipment(item[:item_number], item[:count].to_i, new_shipment)
      end

      new_shipment
    end

    def transfer_shipment(item_number, count, new_shipment)
      original_shipment.pend
      new_shipment.pend

      product = ::Spree::Product.find_by(item_number: item_number)
      raise 'Unable to find the correct product associated with the shipment' if product.nil?

      variant = variants.detect { |v| v.product.id == product.id }
      raise 'Unable to find the correct variant associated with the product' if variant.nil?

      original_shipment.transfer_to_shipment(variant, count, new_shipment)

      new_shipment
    end

    def find_shipping_method(shipping_type)
      shipping_code = shipping_type_to_shipping_code(shipping_type)
      method = ::Spree::ShippingMethod.find_by(code: shipping_code)
      raise "Unable to find the shipping method #{shipping_code} associated with the ratelinx code #{shipping_type}" if method.nil?

      method
    end

    def shipping_type_to_shipping_code(shipping_type)
      Snapfulfil::Shipment.ratelinx_to_hollar_code(shipping_type)
    end

    def set_shipment_shipping_method(shipment)
      current_shipment_method = shipment.shipping_rates.find_by(selected: true)
      if current_shipment_method
        current_shipment_method.shipping_method = shipping_method
      else
        shipment.add_shipping_method(shipping_method, true)
      end
    end

    def set_shipment_split_at(shipment)
      shipment.split_at = DateTime.current
      shipment.save
    end
  end
end
