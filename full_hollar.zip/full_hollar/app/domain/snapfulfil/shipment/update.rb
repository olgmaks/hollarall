module Snapfulfil
  module Shipment
    class Update
      def initialize(shipment)
        @conn = Snapfulfil::Connection.new
        @shipment = shipment
        @errors = []
      end

      attr_reader :errors

      def cancel
        update_state Status::CANCELLED
      end

      def valid
        update_state Status::VALID
      end

      def postpone
        update_state Status::POSTPONED
      end

      def suspend
        update_state Status::SUSPENDED
      end

      def hold_credit
        update_state Status::CREDIT_HOLD
      end

      def update_shipping_details
        return unless shipment_infos
        if picked?(shipment_infos['Stage'])
          errors << "The Shipment is already picked"
          return
        end

        previous_address = shipment_infos['ShipAddress'].try(:first)
        if previous_address && previous_address.any?
          previous_address_id = previous_address['AddressId']
        end

        address = rebuild_ship_address(shipment.order.ship_address,
                                       shipment_infos['ShipmentId'],
                                       previous_address_id)
        update_shipment(shipment_infos, {"ShipAddress" => address})
      end

      def update_reference_text(text)
        return unless shipment_infos
        if picked?(shipment_infos['Stage'])
          errors << "The Shipment is already picked"
          return
        end
        update_shipment(shipment_infos, {"CustomerRef" => text.to_s})
      end

      private

      attr_accessor :conn, :shipment

      def picked?(stage)
        return false unless stage

        stage = stage.to_i
        return true if stage >= 20 # Pick Stage
        false
      end

      def update_state(state)
        return unless shipment_infos

        update_shipment(shipment_infos, {Status: state})
      end

      def shipment_infos
        @_shipment_infos ||= Retrieve.new.by_id(shipment.number).try(:first)
      end

      def update_shipment shipment_infos, updated_details
        body = shipment_infos.merge(updated_details)
        conn.put("/api/shipments/#{shipment.number}", body.to_json)
      end

      def rebuild_ship_address(address, shipment_reference, previous_address_id)
        [{
          'Table': 'SHH',
          'ShipmentId': shipment_reference,
          'AddressId': (previous_address_id || address.id.to_s),
          'Name': address.full_name,
          'City': address.city,
          'State': address.state.try(:abbr),
          'Postcode': address.zipcode,
          'Country': address.country.iso
        }.merge(Snapfulfil::Address.new(address).adjust_address)]
      end
    end
  end
end
