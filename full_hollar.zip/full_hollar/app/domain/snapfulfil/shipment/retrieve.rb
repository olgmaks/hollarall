module Snapfulfil
  module Shipment
    class Retrieve
      def initialize
        @conn = Snapfulfil::Connection.new
      end

      def by_id(id)
        filter = URI.escape("ShipmentId eq '#{id}'")
        http_response = conn.get("/api/shipments?$filter=#{filter}")
        JSON.parse http_response.body
      rescue
        false
      end

      def by_search(field, leftstring, sort)
        filter = URI.escape("startswith((#{field},'#{leftstring}')")
        http_response = conn.get("/api/shipments?$filter=#{filter}&orderby=#{sort}")
        JSON.parse http_response.body
      rescue
        false
      end

      private

      attr_accessor :conn
    end
  end
end
