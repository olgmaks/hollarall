module Snapfulfil
  module Shipment
    class Create
      def initialize(order, shipment)
        @conn = Snapfulfil::Connection.new
        @order = order
        @shipment = shipment
        @shipping_type_id = shipping_type_id
      end

      def perform
        conn.post('/api/shipments', body)
      end

      private

      attr_accessor :order, :shipping_type_id, :shipment, :conn

      def body
        shipment_reference = shipment.number

        hash = {}
        hash['ShipmentId'] = shipment_reference
        hash['Status'] = '00'
        hash['OrderType'] = 'S01'
        hash['OrderClass'] = 'CUS'
        hash['CustomerId'] = order.ship_address.id.to_s
        hash['CustomerName'] = order.ship_address.full_name
        hash['ShippingAddressId'] = order.ship_address.id.to_s
        hash['InvoiceAddressId'] = (order.bill_address || order.ship_address).id.to_s
        hash['Site'] = '0001'
        hash['Warehouse'] = 'DC1'
        hash['OwnerId'] = 'HOLLAR'
        hash['StockStatus'] = '00'
        hash['CustomerRef'] = add_reference_text(order.line_items)
        hash['CarrierTrackingNumber'] = nil
        hash['ShippingLane'] = 'GO-01'
        hash['DateDueOut'] = shipment.created_at.iso8601
        hash['Stage'] = '00'
        hash['ShipmentLines'] = add_line_items(shipment,
                                               shipment_reference)
        hash['ShipAddress'] = add_ship_address(order.ship_address,
                                               shipment_reference)
        hash['ShipContacts'] = add_ship_contact(order, order.ship_address, shipment_reference)

        hash['CarrierId'],
        hash['ShippingMethod'] = add_shipping_code(shipment.shipping_method.code, hash['CustomerRef'])

        hash.to_json
      end

      def add_line_items(shipment, shipment_reference)
        line_items = []
        shipment.inventory_units.group_by(&:variant).each do |group|
          variant = group.first
          quantity = group.second.count
          line_items << { 'ShipmentId': shipment_reference,
                          'Line': group.second.first.line_item_id,
                          'SKUId': variant.sku,
                          'UnitOfMeasure': 'EA',
                          'QtyOrdered': quantity,
                          'QtyRequired': quantity,
                          'QtyAllocated': 0.00,
                          'QtyTasked': 0.00,
                          'QtyPicked': 0.00,
                          'QtyShipped': 0.00,
                          'QtyDelivered': 0.00,
                          'QtyDueOut': 0.00,
                          'SOLineId': quantity,
                          'Price': variant.price.to_f,
                          'SiteId': '0001',
                          'Warehouse': 'DC1',
                          'OwnerId': 'HOLLAR',
                          'StockStatus': '00',
                          'Stage': '00' }
        end

        line_items
      end

      def add_ship_address(address, shipment_reference)
        [{
          'Table': 'SHH',
          'ShipmentId': shipment_reference,
          'AddressId': address.id.to_s,
          'Name': address.full_name,
          'City': address.city,
          'State': address.state.try(:abbr),
          'Postcode': address.zipcode,
          'Country': address.country.iso
        }.merge(Snapfulfil::Address.new(address).adjust_address)]
      end

      def add_ship_contact(order, address, shipment_reference)
        [{
          'Table': 'SHH',
          'ShipmentId': shipment_reference,
          'LineId': address.id.to_s,
          'Email': order.email,
          'Phone': address.phone
          }]
      end

      def add_shipping_code(ship_code, reference_text)
        # force Parcel Lightweight for RedBox-only shipments and 1-item-only shipments
        # use First Class Mail if only USPS available
        if reference_text.include?('RBOX') || reference_text.include?('SPIM')
          shipping_override = Spree::ShippingMethod.find_by(code: 'NEWGISTICS_LT') ||
                                Spree::ShippingMethod.find_by(code: 'USPS_FIRST_CLASS')
          shipping_rate = shipment.shipping_rates[0]
          shipping_rate.shipping_method = shipping_override
          shipping_rate.save

          return Snapfulfil::Shipment.hollar_to_snap_code(shipping_override.code)
        end

        shipping_code = Snapfulfil::Shipment.hollar_to_snap_code(ship_code)
        if ratelinx_enabled?
          # NOTE(cab): From the Snapfulfil doc, when the data is coming from
          # Ratelinx, we have to set the CarrierID to 'RATELINX'

          shipping_code = shipping_code.dup # shipping_code is likely an immutable array
          shipping_code[0] = CarrierId::RATELINX
        end

        shipping_code
      end

      def add_reference_text(line_items)
        references = []

        total_qty = 0
        variant_ids = line_items.collect{|li|
          total_qty += li.quantity
          li.variant_id
        }

        # tag shipments that only have certain variants, e.g. digital movie downloads only
        # e.g. {:HOLD=>[], :GOT=>[25477, 25478, 25479, 25480, 25481]}
        tags = eval(Hollar::Config.wms_shipment_tags || {})
        tags.keys.each do |key|
          if (variant_ids - tags[key]).empty?
            references << key.to_s
          end
        end

        # tag shipments based on quantity count
        if total_qty == 1
          references << 'SPIM'
        elsif total_qty <= 3
          references << 'SPIR'
        elsif total_qty <= 14
          references << 'SPI'
        elsif total_qty <= 39
          references << 'SPIB'
        else
          references << 'SPIXL'
        end

        # tag shipments with consignment products
        line_product_ids = Spree::Variant.where(id: variant_ids).pluck(:product_id)
        consignment_property = Spree::Property.find_by(name: 'consignment')
        if Spree::ProductProperty.exists?(property_id: consignment_property.try(:id), product_id: line_product_ids)
          references << 'CONS'
        end

        references.join(',')[0..19]
      end

      def ratelinx_enabled?
        ENV.fetch('RATELINX_ENABLED', true) != 'false'
      end
    end
  end
end
