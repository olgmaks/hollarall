module Snapfulfil
  module Shipment
    class Delete
      def initialize(shipment)
        @conn = Snapfulfil::Connection.new
        @shipment = shipment
      end

      def perform
        conn.delete("/api/shipments/#{shipment.number}")
      end

      private

      attr_accessor :shipment, :conn
    end
  end
end
