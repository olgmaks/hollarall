module Snapfulfil
  class SnapfulfilService
    class NotSentToSnap < StandardError
    end

    def initialize(shipment)
      @shipment = shipment
      @order = shipment.order
    end

    def send_shipment_to_wms
      if shipment.sent_shipment_to_wms?
        Rails.logger.info("Shipment #{shipment.number} already been sent to Snapfulfil")
      else
        Rails.logger.info("Send shipment #{shipment.number} to Snapfulfil")
        ::Snapfulfil::Shipment::Create.new(order, shipment).perform

        if shipment_correctly_saved?(shipment)
          shipment.sent_shipment_to_wms_at = DateTime.current
          shipment.save
        else
          raise NotSentToSnap, "Shipment #{shipment.number} was supposed to be created in snapfulfil but wasn't"
        end
      end
    end

    def send_attachment_to_wms
      if shipment.parcel_id.nil?
        Rails.logger.info("Not sending attachment for #{shipment.number} -- not parcel id found")
        Rails.logger.info("  Reason: Ratelinx might be turned off!")
        return
      end

      if shipment.sent_attachment_to_wms?
        Rails.logger.info("Shipment attachment for shipment #{shipment.number} already been sent to Snapfulfil")
      else
        Rails.logger.info("Send attachment for shipment #{shipment.number} to Snapfulfil")
        ::Snapfulfil::Attachment::Create.new(shipment.number, shipment.parcel_id).perform

        if attachment_correctly_saved?(shipment)
          shipment.sent_attachment_to_wms_at = DateTime.current
          shipment.save
        else
          raise NotSentToSnap, "Attachment for shipment #{shipment.number} was supposed to be created in snapfulfil but wasn't"
        end
      end
    end

    private

    attr_reader :order, :shipment

    def shipment_correctly_saved?(shipment)
      ::Snapfulfil::Shipment::Retrieve.new.by_id(shipment.number).present?
    end

    def attachment_correctly_saved?(shipment)
      ::Snapfulfil::Attachment::Retrieve.new.by_ratelinx_fields(shipment.number).present?
    end
  end
end
