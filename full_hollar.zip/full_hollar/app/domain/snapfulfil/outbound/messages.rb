module Snapfulfil
  module Outbound
    class Messages

      def call
        logger.info "Messages processed on: #{DateTime.now}"
        messages.each do |message|
          begin
            process_message message
          rescue ProcessShipment::NOT_HANDLED
            logger.error '-' * 20
            logger.error 'This message cannot be handled'
            logger.error 'Message:'
            logger.error message
            logger.error 'Shipment:'
            logger.error retrieve_shipment_from message
          end
        end
      end

      private

      def messages
        @_messages ||= Snapfulfil::Outbound::List.new.call
      end

      def process_message message
        number = message['Shipment']
        logger.info "Processing #{number}"

        case message['Transaction']
        when 'DESPATCH'
          snap_shipment = retrieve_shipment_from message
          spree_shipment = retrieve_spree_shipment number
          ps = process_shipment(snap_shipment, spree_shipment)
          acknowledge(message) if ps && ps.do_ack
        when 'MOVE_STOCK'
          process_stock_movement
        else
          logger.info 'Action not defined for the transaction type'
          false
        end
      end

      def acknowledge message
        logger.info "Acknowledging #{message['XDoc']}"
        Snapfulfil::Outbound::Acknowledge.new(message['XDoc']).call
      end

      def retrieve_shipment_from message
        Snapfulfil::Shipment::Retrieve.new.by_id(message['Shipment'])
      end

      def retrieve_spree_shipment(number)
        Spree::Shipment.find_by(number: number)
      end

      def process_shipment snap_shipment, spree_shipment
        ps = Snapfulfil::Outbound::ProcessShipment.new(spree_shipment)
        ps.call(snap_shipment)
        ps
      end

      def process_stock_movement
        #TODO LATER
        true
      end

      def logger
        ::Logger.new('log/snapfulfil_messages.log')
      end

    end
  end
end
