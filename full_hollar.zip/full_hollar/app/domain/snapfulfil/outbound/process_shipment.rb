module Snapfulfil
  module Outbound
    class ProcessShipment
      class NOT_HANDLED < Exception; end

      STAGE_FULFILLED = 90
      STAGE_CANCELLED = 91

      # 50 = Pick Now And Back Order
      # 51 = Pick When Due And Back Order
      BACKORDER_PICK_CODES = [50, 51].freeze

      attr_accessor :do_ack

      def initialize(spree_shipment)
        @spree_shipment = spree_shipment
        @do_ack = false
      end

      def call(snap_shipment)
        execute_shipment(snap_shipment[0])
      end

      private

      attr_accessor :spree_shipment

      def execute_shipment(snap_shipment)
        return if wait_for_prime_shipment?(snap_shipment)

        if do_not_process?(snap_shipment) || nothing_to_process?(snap_shipment)
          @do_ack = true
          return
        end

        @spree_shipment ||= retrieve_backorder_shipment_if_any(snap_shipment)

        case
        when canceled?(snap_shipment)
          if prime?(snap_shipment)
            # full order cancel
          else
            short_variances_if_any(snap_shipment)
            RefundShortShipJob.perform_later(spree_shipment.order, spree_shipment)
          end

        when fulfilled?(snap_shipment)
          if backordered_mode?(snap_shipment)
            backorder_variances_if_any(snap_shipment)
          else
            short_variances_if_any(snap_shipment)
          end

          attach_tracking_number(snap_shipment)
          set_shipment_as_shipped(snap_shipment)
          set_shipped_at(snap_shipment)

        else
          raise NOT_HANDLED
        end

        @do_ack = true
      end

      def retrieve_backorder_shipment_if_any(snap_shipment)
        if spree_shipment.nil? && !prime?(snap_shipment)
          spree_shipment = ::Spree::Shipment.find_by(number: get_backorder_number(snap_shipment))
          spree_shipment.update_attribute(:number, snap_shipment['ShipmentId']) if spree_shipment
        end
        spree_shipment
      end

      def short_variances_if_any(snap_shipment)
        units_to_cancel = []

        snap_shipment['ShipmentLines'].each do |line|
          short_quantity = line['QtyRequired'].to_i - line['QtyShipped'].to_i
          next unless short_quantity > 0

          variant = ::Spree::Variant.find_by_sku(line['SKUId'])
          line_item = spree_shipment.line_items.detect { |li| li.variant_id == variant.id }
          short_units = line_item.inventory_units.where(shipment_id: spree_shipment.id, state: 'on_hand').
                        limit(short_quantity)

          short_units.each do |su|
            units_to_cancel << su
          end
        end

        order.cancellations.short_ship(units_to_cancel) unless units_to_cancel.empty?
      end

      def backorder_variances_if_any(snap_shipment)
        shipment_to_backorder = nil

        snap_shipment['ShipmentLines'].each do |line|
          variant = ::Spree::Variant.find_by_sku(line['SKUId'])
          line_item = spree_shipment.line_items.detect { |li| li.variant_id == variant.id }
          backorder_quantity = line_item.inventory_units.where(shipment_id: spree_shipment.id,
                                                               state: 'on_hand'
                                                              ).count - line['QtyShipped'].to_i
          next unless backorder_quantity > 0

          shipment_to_backorder ||= create_backordered_shipment(snap_shipment, order)
          backorder_units = line_item.inventory_units.where(shipment_id: spree_shipment.id, state: 'on_hand').
                            limit(backorder_quantity)

          backorder_units.each do |bu|
            bu.update_attribute(:shipment_id, shipment_to_backorder.id)
          end
        end
      end

      def create_backordered_shipment(snap_shipment, order)
        ::Spree::Shipment.find_by(number: get_backorder_number(snap_shipment)) ||
          create_shipment_from(order, get_backorder_number(snap_shipment), 'ready')
      end

      def create_shipment_from(order, number, state)
        shipment = ::Spree::Shipment.create(number: number,
                                            order: order,
                                            address: spree_shipment.address,
                                            state: state,
                                            sent_shipment_to_wms_at: spree_shipment.sent_shipment_to_wms_at,
                                            stock_location: spree_shipment.stock_location)
        shipment.shipping_rates.create(shipping_method_id: spree_shipment.shipping_method.id,
                                       cost: 0, selected: true)
        shipment.save
        order.shipments << shipment

        shipment
      end

      def get_backorder_number(snap_shipment)
        snap_shipment['Prime'] + '-B'
      end

      def set_shipment_as_shipped(_snap_shipment)
        Spree::OrderShipping.new(order).ship_shipment(spree_shipment)
      end

      def set_shipped_at(snap_shipment)
        carton = spree_shipment.reload.cartons.first
        shipped_at = snap_shipment['DateClosed']
        return unless shipped_at
        date = shipped_at.in_time_zone
        spree_shipment.shipped_at = date
        if carton
          carton.shipped_at = date
          carton.save!
        end
        spree_shipment.save!
      end

      def attach_tracking_number(snap_shipment)
        # update shipping method if modified at the warehouse
        actual_ship_code = Snapfulfil::Shipment.snap_to_hollar_code([
                                            snap_shipment['CarrierId'],
                                            snap_shipment['ShippingMethod']
                                          ])
        if actual_ship_code != spree_shipment.shipping_method.code
          shipping_rate = spree_shipment.shipping_rates.first
          shipping_rate.shipping_method = Spree::ShippingMethod.find_by(code: actual_ship_code)
          shipping_rate.save
        end

        # update tracking number
        tracking = snap_shipment['CarrierTrackingNumber']
        /\w+=([^=,]+),*/.match(tracking).tap do |md|
          # extract first number if multi-tracking-number detected
          tracking = md[1].strip if md
        end
        spree_shipment.update_attribute(:tracking, tracking)
      end

      def do_not_process?(snap_shipment)
        !snap_shipment || snap_shipment['DateClosed'].nil? ||
          ![STAGE_FULFILLED, STAGE_CANCELLED].include?(snap_shipment['Stage'].to_i) ||
          (!spree_shipment && prime?(snap_shipment)) ||
          (spree_shipment && spree_shipment.shipped?) ||
          (spree_shipment && spree_shipment.canceled?)
      end

      def nothing_to_process?(snap_shipment)
        snap_shipment['ShipmentLines'].each do |line|
          return false if line['QtyRequired'].to_i > 0
        end
        true
      end

      def wait_for_prime_shipment?(snap_shipment)
        !prime?(snap_shipment) &&
          !::Spree::Shipment.find_by(number: get_backorder_number(snap_shipment))
      end

      def fulfilled?(snap_shipment)
        snap_shipment['Stage'].to_i == STAGE_FULFILLED
      end

      def canceled?(snap_shipment)
        snap_shipment['Stage'].to_i == STAGE_CANCELLED
      end

      def backordered_mode?(snap_shipment)
        BACKORDER_PICK_CODES.include?(snap_shipment['ShortageCode'].to_i)
      end

      def prime?(snap_shipment)
        snap_shipment['ShipmentId'] == snap_shipment['Prime']
      end

      def order
        @order ||= spree_shipment.order
      end

      def shipment_retriever
        @_shipment_retriever ||= Snapfulfil::Shipment::Retrieve.new
      end
    end
  end
end
