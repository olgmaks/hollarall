module Snapfulfil
  module Outbound
    class Acknowledge
      def initialize xdoc_id
        @xdoc_id = xdoc_id
        @conn = Snapfulfil::Connection.new
      end

      def call
         conn.put("/api/snapoutbound/#{xdoc_id}")
      end

      private

      attr_accessor :conn, :xdoc_id
    end
  end
end
