module Snapfulfil
  module Outbound
    class List

      NO_MESSAGE = 'No Outstanding Messages'

      def initialize
        @conn = Snapfulfil::Connection.new
      end

      def call
        http_response = conn.get("/api/snapoutbound")
        response = http_response.body
        return [] if response == NO_MESSAGE

        build_messages JSON.parse(response)
      end

      private

      def build_messages json
        json.map {|m| m.merge(deserialize_key(m['Key']))}
      end

      def deserialize_key raw_key
        output = {}
        raw_key.split('" ').each do |tuple|
          kv =tuple.split('=')
          k = kv[0]
          v = kv[1]
          v[0]= '' if v[0] == '"'
          v[v.size-1]= '' if v[v.size-1] == '"'
          output[k] = v
        end
        output
      end

      attr_accessor :conn
    end
  end
end
