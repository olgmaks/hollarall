module Snapfulfil
  class Base
    def conn
      @_conn || Snapfulfil::Connection.new
    end
  end
end
