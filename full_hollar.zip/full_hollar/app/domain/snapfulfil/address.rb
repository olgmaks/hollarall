module Snapfulfil
  class Address
    ADDRESS_LINE_LIMIT = 30 # snapfulfil limitation

    def initialize spree_address
      @spree_address = spree_address
    end

    def adjust_address
      return hash_base unless spree_address
      return { 'Line1' => spree_address.address1,
               'Line2' => spree_address.address2 } if address_fit?

      lines = concatenate_address_lines spree_address
      full_lines = concatenate_full_address_lines spree_address

      usps_address = SmartyStreets::Lookup.new.lookup(full_lines).first
      return format_address_fallback(lines) unless usps_address_fit?(usps_address)
      format_usps_address(usps_address)
    end

    private

    attr_accessor :spree_address

    def hash_base
      { 'Line1' => '',
        'Line2' => '',
        'Line3' => ''
      }
    end

    def usps_address_fit? usps_address
      return true if usps_address &&
                     usps_address['delivery_street1'] &&
                     usps_address['delivery_street1'] <= ADDRESS_LINE_LIMIT
      false
    end


    def address_fit?
      (spree_address.address1.try(:length) || 0) < ADDRESS_LINE_LIMIT &&
        (spree_address.address2.try(:length) || 0) < ADDRESS_LINE_LIMIT
    end

    def format_address_fallback concatenated_lines
      hash = hash_base
      words = concatenated_lines.split(' ')

      words.each do |word|
        if hash['Line1'].length + word.length < ADDRESS_LINE_LIMIT
          hash['Line1'] << word
          hash['Line1'] << ' '

        elsif hash['Line2'].length + word.length < ADDRESS_LINE_LIMIT
          hash['Line2'] << word
          hash['Line2'] << ' '

        else
          hash['Line3'] << word
          hash['Line3'] << ' '
        end
      end
      hash.values.each(&:strip!)
      hash
    end


    def concatenate_address_lines address
      lines = ''
      lines << address.address1 if address.address1
      lines << ', ' if lines.length > 0
      lines << address.address2  if address.address2
      lines
    end

    def concatenate_full_address_lines address
      lines = concatenate_address_lines address
      lines << ', ' if lines.length > 0
      lines << address.city
      lines << ', ' if lines.length > 0
      lines << address.state.try(:abbr)
      lines << ' ' if lines.length > 0
      lines << address.zipcode
      lines << ' ' if lines.length > 0
      lines
    end

    def format_usps_address usps_address
      { 'Line1' => usps_address['delivery_line1'],
        'Line2' => usps_address['delivery_line2'] }
    end
  end
end
