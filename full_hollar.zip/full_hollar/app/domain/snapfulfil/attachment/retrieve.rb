module Snapfulfil
  module Attachment
    class Retrieve
      def initialize
        @conn = Snapfulfil::Connection.new
      end

      def by_ratelinx_fields(shipment_number)
        table = 'SHH'
        key = shipment_number
        key_line = ''
        line_id = ''
        http_response = conn.get("/api/attachments/#{table}/#{key}/#{key_line}/#{line_id}")
        JSON.parse http_response.body
      rescue
        false
      end

      private

      attr_accessor :conn
    end
  end
end
