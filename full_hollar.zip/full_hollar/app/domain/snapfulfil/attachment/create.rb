module Snapfulfil
  module Attachment
    class Create
      def initialize(shipment_reference, parcel_id)
        @conn = Snapfulfil::Connection.new
        @shipment_reference = shipment_reference
        @parcel_id = parcel_id
      end

      def perform
        conn.post('/api/attachments', body)
      end

      private

      attr_accessor :conn, :parcel_id, :shipment_reference

      def body
        hash = {}
        hash['Table'] = 'SHH'       # NOTE(cab): Must always stay the same
        hash['Type']  = 'PACKAGING'   # NOTE(cab): Must always stay the same
        hash['Key']   = shipment_reference
        hash['KeyLine'] = ''
        hash['LineId']  = ''
        hash['AttachmentText'] = parcel_id

        hash.to_json
      end
    end
  end
end
