module Snapfulfil
  class Connection
    BASE_URL = ENV.fetch('SP_BASE_URL',
                         'https://hollartestapi.snapfulfil.net')
    USER = ENV.fetch('SP_USER', 'HOLAPI')
    PASSWORD = ENV.fetch('SP_PASSWORD', 'HOLAPI1')

    def connection
      Faraday.new(url: BASE_URL) do |faraday|
        faraday.request :url_encoded
        faraday.use Faraday::Request::BasicAuthentication, USER, PASSWORD
        faraday.adapter Faraday.default_adapter
      end
    end

    def post(url, body)
      response = connection.post do |req|
        req.url url
        req.headers['Content-Type'] = 'application/json'
        req.body = body
      end
      log_and_return url, body, response
    end

    def delete(url)
      response = connection.delete do |req|
        req.url url
        req.headers['Content-Type'] = 'application/json'
      end
      log_and_return url, nil, response
    end

    def put(url, body = nil)
      response = connection.put do |req|
        req.url url
        req.headers['Content-Type'] = 'application/json'
        req.body = body if body
      end
      log_and_return url, body, response
    end

    def get(url)
      response = connection.get do |req|
        req.url url
        req.headers['Content-Type'] = 'application/json'
      end
      log_and_return url, nil, response
    end

    def log_and_return url, body, response
      Rails.logger.info '--- BEGIN SNAPFULFIL REQUEST ---'
      Rails.logger.info BASE_URL + url
      Rails.logger.info body
      Rails.logger.info response.body
      Rails.logger.info '--- END SNAPFULFIL REQUEST ---'

      response
    end
  end
end
