module Snapfulfil
  module Stock
    class Retrieve < Snapfulfil::Base
      def initialize sku
        @sku = sku
      end

      def call
        http_response = conn.get "/api/stocktotals/#{sku}"
        JSON.parse http_response.body
      end

      private

      attr_accessor :sku
    end
  end
end
