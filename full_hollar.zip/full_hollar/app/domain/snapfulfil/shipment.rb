module Snapfulfil
  module Shipment
    module Status
      VALID = '00'
      CANCELLED = '01'
      POSTPONED = '02'
      CREDIT_HOLD = '03'
      SUSPENDED = '04'
      RECREATE_PACK_TASK = '10'
      INTERFACE_ERROR = '80'
    end

    module CarrierId
      USPS = 'ENDICIA'
      FEDEX = 'FEDEX'
      WILLCALL = 'WILLCALL'
      RATELINX = 'RATELINX'
      NEWGISTICS = 'SHIPPO'
    end

    module ShippingMethod
      module USPS
        FIRST_CLASS_MAIL = '71'
        PRIORITY_MAIL = '72'
        PRIORITY_MAIL_FLAT = 'P08P'
      end
      module FedEx
        STANDARD_OVERNIGHT = '11'
        GROUND = '15'
        HOME_DELIVERY = "16"
        SMART_POST = '26'
      end
      module WillCall
        PICK_UP = '99'
      end
      module Newgistics
        FIRST_CLASS = "SH_NEWFC"
        PRIORITY_MAIL = 'SH_NEWPR'
        PARCEL_SELECT = 'SH_NEWSL'
        PARCEL_SELECT_LIGHTWEIGHT = "SH_NEWLT"
      end
    end

    HOLLAR_SNAP_CODES = {
      'FEDEX_STANDARD_OVERNIGHT': [CarrierId::FEDEX, ShippingMethod::FedEx::STANDARD_OVERNIGHT],
      'FEDEX_GROUND': [CarrierId::FEDEX, ShippingMethod::FedEx::GROUND],
      'FEDEX_HOME_DELIVERY': [CarrierId::FEDEX, ShippingMethod::FedEx::HOME_DELIVERY],
      'FEDEX_SMART_POST': [CarrierId::FEDEX, ShippingMethod::FedEx::SMART_POST],
      'USPS_FIRST_CLASS': [CarrierId::USPS, ShippingMethod::USPS::FIRST_CLASS_MAIL],
      'USPS_PRIORITY': [CarrierId::USPS, ShippingMethod::USPS::PRIORITY_MAIL],
      'USPS_PRIORITY_FLAT': [CarrierId::USPS, ShippingMethod::USPS::PRIORITY_MAIL_FLAT],
      'NEWGISTICS_FC': [CarrierId::NEWGISTICS, ShippingMethod::Newgistics::FIRST_CLASS],
      'NEWGISTICS_PR': [CarrierId::NEWGISTICS, ShippingMethod::Newgistics::PRIORITY_MAIL],
      'NEWGISTICS_PS': [CarrierId::NEWGISTICS, ShippingMethod::Newgistics::PARCEL_SELECT],
      'NEWGISTICS_LT': [CarrierId::NEWGISTICS, ShippingMethod::Newgistics::PARCEL_SELECT_LIGHTWEIGHT],
      'WILLCALL_PICK_UP': [CarrierId::WILLCALL, ShippingMethod::WillCall::PICK_UP]
    }.stringify_keys

    HOLLAR_RATELINX_CODES = {
      'FEDEX_GROUND': ShippingMethod::FedEx::GROUND,
      'FEDEX_HOME_DELIVERY': ShippingMethod::FedEx::HOME_DELIVERY,
      'FEDEX_SMART_POST': ShippingMethod::FedEx::SMART_POST,
      'USPS_FIRST_CLASS': ShippingMethod::USPS::FIRST_CLASS_MAIL,
      'USPS_PRIORITY': ShippingMethod::USPS::PRIORITY_MAIL,
      'USPS_PRIORITY_FLAT': ShippingMethod::USPS::PRIORITY_MAIL_FLAT,
      'NEWGISTICS_PS': ShippingMethod::Newgistics::PARCEL_SELECT,
      'NEWGISTICS_LT': ShippingMethod::Newgistics::PARCEL_SELECT_LIGHTWEIGHT
    }.stringify_keys

    def self.hollar_to_snap_code(ship_code)
      HOLLAR_SNAP_CODES[ship_code] || raise("Ship code #{ship_code} is not supported!")
    end

    def self.snap_to_hollar_code(ship_code_pair)
      HOLLAR_SNAP_CODES.invert[ship_code_pair] || raise("Ship code #{ship_code_pair} is not supported!")
    end

    def self.ratelinx_to_hollar_code(ship_code)
      HOLLAR_RATELINX_CODES.invert[ship_code] || raise("Ship code #{ship_code} is not supported!")
    end
  end
end
