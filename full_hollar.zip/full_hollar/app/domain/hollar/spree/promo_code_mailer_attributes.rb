module Hollar
  module Spree
    class PromoCodeMailerAttributes
      def initialize(promo)
        @promo = promo
        @attrs = {}
      end

      def build_attributes
        build_message_tags
        attrs
      end

      private

      attr_reader :promo, :attrs

      def build_message_tags
        attrs[:prize] = promo.name
        attrs[:promo_code] = promo.codes.first.value
        attrs[:promo_code_expire_date] = (promo.expires_at - 2.days).strftime('%B %e, %Y')
      end
    end
  end
end
