module Hollar
  module Spree
    class MarketplaceApplicationMailerAttributes
      def initialize(fields)
        @fields = fields
        @attrs = {}
      end

      def build_attributes
        attrs[:company] = fields[:company]
        attrs[:website_url] = fields[:website_url]
        attrs[:name] = fields[:name]
        attrs[:title] = fields[:title]
        attrs[:phone_number] = fields[:phone_number]
        attrs[:email] = fields[:email]
        attrs[:annual_revenue] = fields[:annual_revenue]
        attrs[:seller_type] = fields[:seller_type]
        attrs[:skus_under_10] = fields[:skus_under_10]
        attrs[:categories] = fields[:categories].join(' / ') if fields[:categories]
        attrs[:other_categories] = fields[:other_categories]
        attrs[:other_marketplaces] = fields[:other_marketplaces]
        attrs[:use_third_party] = fields[:use_third_party]
        attrs[:third_party_input] = fields[:third_party_input]
        attrs[:comments] = fields[:comments]

        attrs
      end

      private

      attr_reader :fields, :attrs
    end
  end
end
