module Hollar
  module Spree
    class GiftCardRedeemMailerAttributes
      def initialize(order, gift_card)
        @order = order
        @gift_card = gift_card
        @attrs = {}
      end

      def build_attributes
        build_gift_card_tags
        build_address_tags('bill')
        attrs
      end

      private

      attr_reader :order, :attrs, :gift_card

      def build_gift_card_tags
        attrs[:recipientName] = gift_card.recipient_name
        attrs[:deliveredTo] = gift_card.recipient_email
        attrs[:message] = gift_card.gift_message
        attrs[:amount] = gift_card.amount
        attrs[:orderDate] = gift_card.order.completed_at.strftime('%m/%d/%Y')
        attrs[:deliveryMethod] = gift_card.print_delivery? ? 'Hand Delivery' : 'Email Delivery'
      end

      def build_address_tags(type)
        attrs[:"#{type}Name"] = "#{address_for(type).firstname} #{address_for(type).lastname}"
        address_street_block(type)
        address_city_block(type)
        attrs[:"#{type}Zip"] = address_for(type).zipcode
      end

      def address_street_block(type)
        attrs[:"#{type}StreetAddress"] = address_for(type).address1
        return unless address_for(type).address2
        attrs[:"#{type}StreetAddress"] += "\n #{address_for(type).address2}"
      end

      def address_city_block(type)
        attrs[:"#{type}CityLine"] = "#{address_for(type).city}"
        return unless address_for(type).state
        attrs[:"#{type}CityLine"] = "#{address_for(type).city} #{address_for(type).state.abbr}"
      end

      def address_for(type)
        order.send(:"#{type}_address")
      end
    end
  end
end
