module Hollar
  module Spree
    module Orders
      module Comments
        class Create
          def initialize(args)
            @customer_service = args[:customer_service]
            @params = args[:params]
            @context = args[:context]
            @order_repository = args[:order_repository]
            @comment_repository = args[:comment_repository]
          end

          def call
            comment = comment_repository.new
            comment.user_id = params[:user_id]
            comment.customer_service_id = customer_service.id
            comment.text = params[:comment][:text]
            comment.comment_type = params[:comment][:comment_type]
            comment.channel = params[:comment][:channel]
            comment.reason = params[:comment][:reason]
            comment.line_item_id = params[:comment][:line_item_id]
            comment.sku = comment.line_item.sku if comment.line_item
            comment.detailed_reason = params[:comment][:detailed_reason]
            comment.order = order_repository.find_by_number(params[:order_id])

            if comment.save
              context.on_comment_created comment
            else
              context.on_comment_not_created
            end
          end

          private

          attr_accessor :context, :customer_service, :params,
                        :order_repository, :comment_repository
        end
      end
    end
  end
end
