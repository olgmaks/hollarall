module Hollar
  module Spree
    module Orders
      module Comments
        class Delete
          def initialize(args)
            @customer_service = args[:customer_service]
            @params = args[:params]
            @context = args[:context]
            @order_repository = args[:order_repository]
          end

          def call
            comment = ::Spree::Comment.find(params[:id])

            if comment && comment.destroy
              context.on_comment_destroyed
            else
              context.on_comment_not_destroyed
            end
          end

          private

          attr_accessor :context, :customer_service, :params,
                        :order_repository, :comment_repository
        end
      end
    end
  end
end
