module Hollar
  module Spree
    class PromoCodeMailer
      def initialize(promo, user)
        @promo = promo
        @user = user
      end

      def send_promo_code
        mailer_attributes = PromoCodeMailerAttributes.new(promo)
        DelayedSend.perform_later(@user.email,
                                  ::EmailTemplateSelector.select_template('carnival_prize_received'),
                                  mailer_attributes.build_attributes)
      end

      private

      attr_reader :promo
    end
  end
end
