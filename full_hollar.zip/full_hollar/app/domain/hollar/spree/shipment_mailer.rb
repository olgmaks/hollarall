module Hollar
  module Spree
    class ShipmentMailer
      def initialize(shipment)
        @shipment = shipment
      end

      def shipment_shipped
        mailer_attributes = ShipmentShippedMailerAttributes.new(shipment)
        if shipment.order.has_pending_items?
          DelayedSend.perform_later(shipment.order.email,
                                    ::EmailTemplateSelector.select_template('order_shipped_multi_bo'),
                                    mailer_attributes.build_attributes)
        else
          DelayedSend.perform_later(shipment.order.email,
                                    ::EmailTemplateSelector.select_template('order_shipped_multi'),
                                    mailer_attributes.build_attributes)
        end
      end

      private

      attr_reader :shipment
    end
  end
end
