module Hollar
  module Spree
    module Api
      # The Registrar is responsible of registering new users in the system
      # It handles both classic registration and facebook registration.
      class Registrar
        def initialize(context, params)
          @context = context
          @params = params
        end

        def create
          user = ::Spree::User.new(params)
          user.generate_spree_api_key
          if user.save
            context.on_user_creation_success(user)
          else
            context.on_user_creation_fail(notice: user.errors.messages)
          end
        rescue StandardError => e
          context.on_user_creation_fail(notice: 'An error occured preventing the user of being created',
                                        error: e.message)
        end

        def create_from_facebook
          facebook_uid = retrieve_facebook_uid
          user = ::Spree::User.where(facebook_uid: facebook_uid).first
          if user
            return context.on_facebook_signin(user)
          end

          existing_user = ::Spree::User.where(email: memoized_fb_me['email']).first
          if existing_user
            return context.on_facebook_signin(existing_user)
          end

          user = ::Spree::User.new
          user.password = ::Devise.friendly_token[0, 20]
          user.facebook_uid = facebook_uid
          user.email        = memoized_fb_me['email']
          user.first_name   = memoized_fb_me['first_name']
          user.last_name    = memoized_fb_me['last_name']

          if user.save!
            context.on_user_creation_success(user)
          else
            context.on_user_creation_fail(notice: user.errors.messages.to_s)
          end
        rescue StandardError => e
          context.on_user_creation_fail(notice: 'An error occured preventing the user of being created',
                                        error: e.message)
        end

        private

        attr_accessor :context, :params

        def retrieve_facebook_uid
          @_fb_uid = memoized_fb_graph.get_object('me')['id']
        end

        def memoized_fb_me
          @_memoized_fb_me ||= memoized_fb_graph.get_object('me', fields: %w(first_name last_name email))
        end

        def memoized_fb_graph
          @_graph ||= ::Koala::Facebook::API.new(fb_auth_token)
        end

        def fb_auth_token
          @_fb_auth_token ||= params[:fb_auth_token]
        end
      end
    end
  end
end
