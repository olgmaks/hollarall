module Hollar
  module Spree
    module Api
      class Authenticator
        def initialize context, email, password
          @context = context
          @email = email
          @password = password
        end

        def authenticate
          user = ::Spree::User.find_by_email(email)
          return context.on_user_not_found unless user
          return context.on_user_signed_up(user) if user.valid_password?(password)
          return context.on_no_match
        end

        private

        attr_accessor :context, :email, :password
      end
    end
  end
end
