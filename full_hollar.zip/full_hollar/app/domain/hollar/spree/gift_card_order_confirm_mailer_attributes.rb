module Hollar
  module Spree
    class GiftCardOrderConfirmMailerAttributes
      def initialize(order, gift_card)
        @order = order
        @gift_card = gift_card
        @attrs = {}
      end

      def build_attributes
        build_gift_card_tags
        build_address_tags('bill')
        attrs
      end

      private

      attr_reader :order, :attrs, :gift_card

      def build_gift_card_tags
        ordered_at = (gift_card.order ? gift_card.order.completed_at : gift_card.created_at)
        attrs[:recipientName] = gift_card.recipient_name
        attrs[:message] = gift_card.gift_message
        attrs[:amount] = gift_card.amount
        attrs[:orderDate] = ordered_at.strftime('%m/%d/%Y')
      end

      def build_address_tags(type)
        attrs[:"#{type}Name"] = "#{address_for(type).firstname} #{address_for(type).lastname}"
        address_street_block(type)
        address_city_block(type)
      end

      def address_street_block(type)
        attrs[:"#{type}StreetAddress"] = address_for(type).address1
        return unless address_for(type).address2
        attrs[:"#{type}StreetAddress"] += "\n #{address_for(type).address2}"
      end

      def address_city_block(type)
        attrs[:"#{type}CityLine"] = "#{address_for(type).city}, #{address_for(type).zipcode}"
        return unless address_for(type).state
        attrs[:"#{type}CityLine"] = "#{address_for(type).city}, #{address_for(type).state.name}," +
                                    " #{address_for(type).zipcode}"
      end

      def address_for(type)
        order.send(:"#{type}_address")
      end
    end
  end
end
