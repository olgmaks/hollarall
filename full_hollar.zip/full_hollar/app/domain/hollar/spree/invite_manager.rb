module Hollar
  module Spree
    # The InviteManager class is responsible to observing or retrieve the events
    # of subscription and purchase of referees. Then it attributes the credits
    # accordingly.
    class InviteManager
      def register_invite(referee_email, referer)
        create_invite(referee_email, referer)
      end

      def subscribe(referee)
        invite_code = referee.referral_invite_code
        if invite_code
          referer = referer(invite_code)
          record_subscription(referer, referee)
        else
          record_subscription_from_elsewhere(referee)
        end
      end

      def purchase(referee)
        invite = ::Spree::Invite.subscribed.refered_to(referee).first
        return unless invite

        invite.purchase!
      end

      def credit_referer(invite)
        referer = invite.referer
        referee = invite.referee
        add_store_credit_to_referer(invite,
                                    referer,
                                    referee,
                                    ::Spree::Invite::INVITE_REWARD)
      end

      def on_referee_converted(invite)
        invite_code_mailer.send_referee_converted(invite)
      end

      private

      def referer(invite_code)
        ::Spree::User.where(invite_code: invite_code).first
      end

      def create_invite(referee_email, referer)
        ::Spree::Invite.create!(
          referee_email: referee_email,
          date_sent: DateTime.now,
          referer_id: referer.id)
      end

      def record_subscription_from_elsewhere(referee)
        invites = ::Spree::Invite.where(referee_email: referee.email)
        invites.each(&:sign_from_elsewhere)
      end

      def record_subscription(referer, referee)
        return unless referer
        return unless referee
        return unless referee.referral_invite_code

        invite = ::Spree::Invite.where(
          referer_id: referer.id,
          referee_email: referee.email).first_or_create
        invite.update_attribute(:referee_id, referee.id)
        invite.subscribe!

        add_store_credit_to_referee(invite,
                                    referer,
                                    referee,
                                    ::Spree::Invite::INVITE_REWARD)
      end

      def add_store_credit_to_referee(invite, referer, referee, amount)
        store_credit = add_store_credit(referer, referee, amount)
        invite.referee_store_credit = store_credit
        invite.save
      end

      def add_store_credit_to_referer(invite, referer, referee, amount)
        store_credit = add_store_credit(referee, referer, amount)
        invite.referer_store_credit = store_credit
        invite.save
      end

      def add_store_credit(reference, receiver, amount)
        category = ::Spree::StoreCreditCategory.where(name: 'Referral').first_or_create
        type = ::Spree::StoreCreditType.where(name: 'Non-expiring').first_or_create
        return unless receiver

        receiver.store_credits.create!(
          amount: amount,
          category_id: category.id,
          type_id: type.id,
          currency: ::Spree::Config[:currency],
          created_by: reference)
      end

      def invite_code_mailer
        ::Hollar::Spree::InviteCodeMailer.new(self)
      end
    end
  end
end
