module Hollar
  module Spree
    class VariantLimiter
      def initialize(user, variant)
        @user = user
        @variant = variant
      end

      def compute
        return 0 if !user
        compute_max_amount
      end

      private

      attr_reader :user, :variant

      def compute_max_amount
        return no_limit if !max_limit_per_customer_available? && !max_limit_per_order_available?
        return no_order_limit if max_limit_per_customer_available? && !max_limit_per_order_available?
        return no_customer_limit if !max_limit_per_customer_available? && max_limit_per_order_available?
        return no_customer_limit if max_limit_per_order <= max_limit_per_customer
        no_order_limit
      end

      def max_limit_per_order
        variant.product.max_product_per_order
      end

      def max_limit_per_customer
        variant.product.max_product_per_customer
      end

      def max_limit_per_customer_available?
        max_limit_per_customer != nil && max_limit_per_customer > 0
      end

      def max_limit_per_order_available?
        max_limit_per_order != nil && max_limit_per_order > 0
      end

      def purchased_items
        user.orders.complete.map(&:line_items).flatten
      end

      def purchasing_items
        user.orders.last.line_items
      end

      def count_for(line_items)
        line_items.select { |li| li.variant_id == variant.id }.map(&:quantity).reduce(&:sum) || 0
      end
       
      def no_limit
        999
      end

      def no_order_limit
        max_limit_per_customer - count_for(purchased_items)
      end

      def no_customer_limit
        max_limit_per_order - count_for(purchasing_items)
      end
    end
  end
end
