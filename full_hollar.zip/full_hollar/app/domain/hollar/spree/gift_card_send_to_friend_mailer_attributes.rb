module Hollar
  module Spree
    class GiftCardSendToFriendMailerAttributes
      def initialize(gift_card)
        @gift_card = gift_card
        @attrs = {}
      end

      def build_attributes
        build_gift_card_tags
        attrs
      end

      private

      attr_reader :order, :attrs, :gift_card

      def build_gift_card_tags
        attrs[:recipientName] = gift_card.recipient_name
        attrs[:purchaserName] = gift_card.purchaser_name
        attrs[:message] = gift_card.gift_message
        attrs[:amount] = gift_card.amount
        attrs[:redeemCode] = gift_card.redemption_code
        attrs[:cardImageURL] = gift_card.main_image_url
        attrs[:redeem_url] = ::Spree::Core::Engine.routes.url_helpers.gift_cards_redeem_url
      end
    end
  end
end
