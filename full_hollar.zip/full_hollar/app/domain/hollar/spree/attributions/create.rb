module Hollar
  module Spree
    module Attributions
      class Create
        attr_reader :context, :taggable, :cookie

        def initialize(context, taggable, options = {})
          @context = context
          @taggable = taggable
          @cookie = options.fetch(:cookie, Rack::Utm::USER_COOKIE_NAME).to_sym
        end

        def call
          create_attribution
          delete_cookie
        end

        private

        def data
          @data ||= JSON.load(cookies[cookie])
        end

        def attributes
          data.slice(*Rack::Utm::ATTRIBUTES)
        end

        def create_attribution
          taggable.attributions.create(attributes)
        end

        def delete_cookie
          cookies.delete(cookie)
        end

        def cookies
          @cookies ||= context.send(:cookies)
        end
      end
    end
  end
end
