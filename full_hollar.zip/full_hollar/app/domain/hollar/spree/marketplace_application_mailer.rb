module Hollar
  module Spree
    class MarketplaceApplicationMailer
      MARKETPLACE_EMAIL = 'marketplace@hollar.com'.freeze

      def initialize(fields)
        @fields = fields
      end

      def send_application
        mailer_attributes = MarketplaceApplicationMailerAttributes.new(fields)
        DelayedSend.perform_later(MARKETPLACE_EMAIL,
                                  ::EmailTemplateSelector.select_template('marketplace_application'),
                                  mailer_attributes.build_attributes)
      end

      private

      attr_reader :fields
    end
  end
end
