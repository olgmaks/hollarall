module Spree
  module StoreHelper
    def cache_key_for_taxons
      max_updated_at = @taxons.maximum(:updated_at).to_i
      parts = [@taxon.try(:id), max_updated_at].compact.join("-")
      "#{I18n.locale}/taxons/#{parts}" +
        feature_cache_keys(:quick_cart, :mobile_single_page, :no_original_prices,
                           :sort_and_filter, :dropdown_navigation).join("-")
    end
  end
end
