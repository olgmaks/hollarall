require 'tilt'
require 'flavour_saver'

module Spree
  module ProductsHelper
    LAST_UNSUPPORTED_IOS_VERSION = Gem::Version.new('1.0.3')
    LAST_UNSUPPORTED_ANDROID_VERSION = Gem::Version.new('1.0.10')
    LAST_UNSUPPORTED_API_VERSION = Gem::Version.new('1')

    def product_description(product)
      product_description = handlebars_transform_links(product.description)

      if product.ca_prop_65?
        ul_end_index = product_description.rindex('</ul>')
        prop_65_html = 'CA Residents: click <a target="CaProp65" href="/california-proposition-65">here</a> ' +
                       'for Proposition 65 Notice'

        if ul_end_index
          product_description.insert(ul_end_index, "<li>#{prop_65_html}</li>")
        else
          product_description += "<p>#{prop_65_html}</p>"
        end
      end

      if ::Spree::Config[:show_raw_product_description]
        raw(product_description)
      else
        raw(product_description.gsub(/(.*?)\r?\n\r?\n/m, '<p>\1</p>'))
      end
    end

    def featherlight_product_url(url)
      url + '?display_layout=false'
    end

    def handlebars_transform_links(description)
      register_product_link_helper
      register_taxon_link_helper

      template = Tilt['handlebars'].new { description }
      template.render
    rescue
      description
    end

    private

    def register_product_link_helper
      variant_model = ::Spree::Variant
      spree_module = spree
      helper = self
      is_mobile_app = !params['app_platform'].blank?

      disable_links = false
      disable_links = !supported_app_version? if is_mobile_app

      FS.register_helper(:productlink) do |sku, text|
        product = variant_model.includes(:product).find_by(sku: sku).try(:product)
        return text if product.nil? || disable_links

        if is_mobile_app
          protocol = 'hollar'
          protocol += Rails.env.to_s unless Rails.env.production?
          url = "#{protocol}:/#{spree_module.product_path(product)}"

          helper.link_to(text, url)
        else
          mobile_link_options = {
            'class': 'is-mobileProductModal on-mobile',
            'data-featherlight': spree_module.product_path(product, display_layout: 'mobile_modal')
          }

          desktop_link_options = {
            'class': 'is-productModal on-desktop',
            'data-featherlight': spree_module.product_path(product, display_layout: 'false')
          }

          helper.link_to(text, spree_module.product_path(product), mobile_link_options) +
            helper.link_to(text, spree_module.product_path(product), desktop_link_options)
        end
      end
    end

    def register_taxon_link_helper
      helper = self
      is_mobile_app = !params['app_platform'].blank?

      disable_links = false
      disable_links = !supported_app_version? if is_mobile_app

      FS.register_helper(:taxonlink) do |permalink, text|
        return text if disable_links

        if is_mobile_app
          protocol = 'hollar'
          protocol += Rails.env.to_s unless Rails.env.production?

          helper.link_to(text, "#{protocol}://t/#{permalink}")
        else
          helper.link_to(text, "/t/#{permalink}")
        end
      end
    end

    def supported_app_version?
      app_version = Gem::Version.new(params['app_version'])
      api_version = Gem::Version.new('1')
      api_version = Gem::Version.new(params['api_version']) unless params['api_version'].blank?

      !((api_version <=> LAST_UNSUPPORTED_API_VERSION).zero? &&
        ((params['app_platform'].casecmp('ios').zero? && ((app_version <=> LAST_UNSUPPORTED_IOS_VERSION) <= 0)) ||
        ((params['app_platform'].casecmp('android').zero? &&
          ((app_version <=> LAST_UNSUPPORTED_ANDROID_VERSION) <= 0)))))
    end

    def featured_item_countdown?(product)
      product.property("featured_item_countdown_to").present?
    end

    def featured_item_countdown(product)
      countdown_time = product.property("featured_item_countdown_to")

      if countdown_time.present?
        seconds_left = (Time.zone.parse(countdown_time).utc - Time.now.utc).to_i
        return seconds_left if seconds_left > 0
      end

      nil
    rescue ArgumentError # invalid date in String#to_datetime
      nil
    end
  end
end
