module Hollar
  module Spree
    class GiftCardMailer
      def initialize(order, gift_card)
        @order = order
        @gift_card = gift_card
      end

      def redeem_email
        mailer_attributes = GiftCardRedeemMailerAttributes.new(order, gift_card)
        DelayedSend.perform_later(gift_card.purchaser.email,
                                  ::EmailTemplateSelector.select_template('gift_card_redeemed'),
                                  mailer_attributes.build_attributes)
      end

      def order_confirm_email
        mailer_attributes = GiftCardOrderConfirmMailerAttributes.new(order, gift_card)
        DelayedSend.perform_later(gift_card.purchaser.email,
                                  ::EmailTemplateSelector.select_template('gift_card_order_confirm'),
                                  mailer_attributes.build_attributes)
      end

      def print_email
        mailer_attributes = GiftCardPrintMailerAttributes.new(order, gift_card)
        DelayedSend.perform_later(gift_card.recipient_email,
                                  ::EmailTemplateSelector.select_template('gift_card_print'),
                                  mailer_attributes.build_attributes)
      end

      def send_to_friend_email
        mailer_attributes = GiftCardSendToFriendMailerAttributes.new(gift_card)
        DelayedSend.perform_later(gift_card.recipient_email,
                                  ::EmailTemplateSelector.select_template('gift_card_send_to_friend'),
                                  mailer_attributes.build_attributes)
      end

      private

      attr_reader :order, :gift_card
    end
  end
end
