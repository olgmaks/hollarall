module Hollar
  module Spree
    # TODO: This object does too much even the comment agrees with me :P
    #
    # This class is responsible of sending Invites via Bronto, and also invoking
    # the registration of the invite in the Invite table.
    class InviteCodeMailer
      def initialize(context)
        @context = context
      end

      def send_email(user, emails, message)
        send_and_register_invite(emails, user, message)

        context.on_email_sent(emails)
      end

      def send_referee_converted(invite)
        referer = invite.referer
        referee = invite.referee
        name = referee.full_name
        name = referee.email if name.strip.empty?
        DelayedSend.perform_later(referer.email,
                                  ::EmailTemplateSelector.select_template(external_key['invite_referee_converted']),
                                  reward: ::Spree::Invite::INVITE_REWARD,
                                  name: name)
      end

      def valid_email?(email)
        EmailValidator.valid?(email)
      end

      private

      attr_accessor :context

      def send_and_register_invite(emails, user, message)
        emails.uniq.each do |email|
          delay_create_contact(email)
          delay_send_email(user, email, message)
          invite_manager.register_invite(email, user)
        end
        true
      end

      def delay_create_contact(email)
        BrontoContactAdd.perform_later(email,
                                       'spree',
                                       funnel_status: 'invited')
      end

      def delay_send_email(user, email, message)
        DelayedSend.perform_later(email,
                                  ::EmailTemplateSelector.select_template(external_key['share_invite_code']),
                                  mailer_attributes(user, email, message))
      end

      def mailer_attributes(user, referee_email, message)
        {
          referer_name: referer_name(user),
          referer_email: user.email,
          message: message_or_default(message),
          invite_code: user.invite_code,
          invite_code_url: invite_code_url(user, referee_email)
        }
      end

      def invite_code_url(user, referee_email)
        ::Spree::Core::Engine.routes.url_helpers.share_url(
          id: user.invite_code,
          referee_email: referee_email,
          host: ENV['HOST'])
      end

      def external_key
        ::Spree::BrontoConfiguration.account['spree']
      end

      def invite_manager
        ::Hollar::Spree::InviteManager.new
      end

      def referer_name(user)
        return "Your Friend" if user.full_name.empty?
        user.full_name
      end

      def message_or_default(message)
        return I18n.t('spree.invite.email.default_message') if !message || message.empty?
        message
      end
    end
  end
end
