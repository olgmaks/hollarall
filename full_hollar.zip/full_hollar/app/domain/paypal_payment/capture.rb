module PaypalPayment
  class Capture < ::PaypalPayment::Base

    def initialize context, authorization_id, amount
      @context = context
      @amount = amount
      @authorization_id = authorization_id
    end

    def call
      response = authorization.capture({ 'amount' => { 'total' => ('%.2f' % amount),
                                            'currency' => 'USD' },
                                            'is_final_capture' => true })
      Rails.logger.info "Response for PayPal capture is: #{response}"
      if response.success?
        context.on_paypal_payment_captured capture_id
      else
        Rails.logger.info response.error.inspect
        context.on_paypal_payment_not_captured response.error.inspect
      end
    rescue => error
      Rails.logger.info error.message
      Rails.logger.info error.backtrace.inspect
      context.on_paypal_payment_not_captured(error.message)
    end

    private

    attr_accessor :authorization_id, :amount

    def capture_id
      payment_id = authorization.parent_payment
      @_payment ||= ::PayPal::SDK::REST::DataTypes::Payment.find(payment_id)
      transactions = @_payment.transactions
      related_resources = transactions.try(:first).try(:related_resources)
      return nil unless related_resources
      related_resources.select {|r| r.try(:capture).try(:state) == 'completed' }.
        first.
        try(:capture).
        try(:id)
    end

    def authorization
      @_authorization ||= ::PayPal::SDK::REST::DataTypes::Authorization.find(authorization_id)
    end
  end
end
