require 'paypal-sdk-rest'

module PaypalPayment
  class Create< ::PaypalPayment::Base

    def initialize context, order, paypal_authorization_id
      @context = context
      @order = order
      @authorization_id = paypal_authorization_id
    end

    def call
      order.payments.delete_all
      order.payments.create!(
        {
          source: Spree::PaypalApiCheckout.create(
            {
              authorization_id: authorization_id
            }),
            amount: order.total,
            payment_method: payment_method
        })
      order.next!
      context.on_paypal_payment_created
    rescue => e
      Rails.logger.info e
      context.on_paypal_error
    end

    private

    attr_accessor :authorization_id


  end
end
