require 'paypal-sdk-rest'

module PaypalPayment
  class Base
    include ::PayPal::SDK::REST

    def call
      raise NotImplementedError
    end

    private

    def payment_method
      ::Spree::PaymentMethod.find_by_type("Spree::Gateway::MobilePaypal")
    end

    attr_accessor :context, :order
  end
end
