module Importer
  class Images
    include ::Importer::FileSystem::FileSystemHelper

    def initialize(archive)
      ::Importer::Base.create_archive_dir if archive
      @archive = archive
      @image_files = get_images_from_folder
      @success = 0
      @failure = 0
      @image_count = @image_files.count
      @completed_images = []
    end

    def perform
      IMPORT_LOGGER.info("BEGIN -- Importing #{@image_count} images")
      @image_files.each do |file|
        # NOTE(cab): The filename must be the SKU number
        # NOTE(cab): We do some parsing here since we can have multiple image_files
        #            for the same product (Front and Back picture).
        #            Those pictures are denoted with '_b' or '_c'.
        # We have to remove that part in order to only get the SKU.
        sku = File.basename(file, '.*').split('_')[0]
        product = Spree::Variant.find_by(sku: sku)
        next unless product.present?

        image = Spree::Image.create(attachment: File.open(file),
                                    viewable: product)
        product.images << image
        save(product, file)
      end


      display_stats
    end

    private

    def get_images_from_folder
      file_location = ::Importer::Base::LOCAL_IMPORT_LOCATION_IMAGES
      files = Dir.glob("#{file_location}/*.{jpg,jpeg,gif,png}").sort

      IMPORT_LOGGER.info('There are no image_files to import') if files.count == 0

      files
    end

    # TODO(cab): A little bit of code cleanup
    def save(product, file)
      if product.save
        @success += 1
        @completed_images << file
        archive(file) if @archive
        IMPORT_LOGGER.info("[IMAGE] - #{product.sku} - Imported!")
      else
        @failure += 1
        IMPORT_LOGGER.error("[IMAGE] - #{product.sku} - Importation failed! #{product.errors.full_messages}")
      end
    end

    def display_stats
      @failure = @image_count - @success
      @not_processed = @image_count - @failure - @success
      IMPORT_LOGGER.info("TOTAL: #{@image_count}, SUCCESS: #{@success}, FAILURE: #{@failure}, NOT PROCESSED: #{@not_processed}")
      IMPORT_LOGGER.info("END -- Finished importing #{@image_count} image_files")
    end
  end
end
