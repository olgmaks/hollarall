require 'csv'

module Importer
  module CSV
    module CSVHelper
      def archive_all(files)
        files.each do |file|
          archive(file)
        end
      end

      def archive(file)
        renamed_file = format_filename(file)
        archive_location = ::Importer::Base::LOCAL_IMPORT_ARCHIVE_PATH

        FileUtils.move(file, "#{archive_location}/#{renamed_file}")
      end

      def create_archive_dir
        ::Importer::Base.create_archive_dir
      end

      private

      def read_from_csv(full_path)
        rows = []
        ::CSV.foreach(full_path) do |row|
          rows << row
        end

        rows.flatten
      end

      def format_filename(file)
        base = File.basename(file, '.*')
        ext = File.extname(file)
        date = DateTime.now.strftime('%Y%m%d')
        filename = "#{base}#{date}#{ext}"
      end
    end
  end
end

