module Importer
  module Product
    module Taxon
      # NOTE(cab): Right now there is no way to have multiple taxonomies for a
      # product.  Which means that a product can't be in both the GIFT and the
      # CATEGORY taxonomies.
      def process_taxon(base_product, product)
        IMPORT_LOGGER.info("#{product} - Importing the taxon")

        # NOTE(cab): We should always find the Taxon, else it means the taxon
        # of the website is not up to date. For the first iteration, we have
        # decided not to import the Taxon if not found.
        taxon = Spree::Taxon.find_by_name(product.category)

        unless taxon
          # NOTE(cab): We are now creating a fake taxonomy to put all the
          # product that does not have an existing taxon. This is only for a
          # litle while. 

          # TODO(cab): Remove that and return an error when we have the
          # confirmation that we have all the data.
          temp_taxonomy = 'fake-taxonomy'
          temp_taxon = 'fake-taxon'
          taxon = Spree::Taxon.find_by_name(temp_taxon)
          unless taxon
            taxonomy = Spree::Taxonomy.new(name: temp_taxonomy)
            taxon = Spree::Taxon.new(name: temp_taxon, taxonomy: taxonomy)
          end

          IMPORT_LOGGER.info("--- FAKE-SKIP #{product}")
          IMPORT_LOGGER.info("We have an unknown taxon \'#{product.category}\',
                               Parent is: \'#{product.department}\'.
                               Inserting that product in '#{temp_taxonomy}'")
        end

        add_taxon_to_product(base_product, taxon)
      end

      private

      def add_taxon_to_product(base_product, taxon)
        base_product.taxons.clear
        base_product.taxons << taxon

        base_product
      end
    end
  end
end
