module Importer
  module Product
    class ProductFactory
      include Image
      include Taxon
      include Variant

      def initialize
        @tax_category = Spree::TaxCategory.find_or_create_by!(name: 'Default')
        @shipping_category = Spree::ShippingCategory.find_or_create_by!(name: 'Default')
      end

      def construct(product)
        base_product = Spree::Product.with_deleted.find_by(item_number: product.item_number)
        if !product.variant? || base_product.nil?
          build_product(base_product, product)
        else
          build_variant(base_product, product)
        end
      end

      private

      # NOTE(cab): Import a base_product
      def build_product(base_product, product)
        IMPORT_LOGGER.info("#{product} - Importing the product")
        base_product = Spree::Product.new if base_product.nil?
        base_product.attributes = product_attrs(product)

        base_product = process_variant(base_product, product, true)
        return nil if base_product.nil?

        base_product = process_taxon(base_product, product)
        return nil if base_product.nil?

        # NOTE(cab): The client this has not decided how the real image will
        # work on the filemaker server. We are waiting for his feedback before
        # pulling the image data. For now we import the image manually.
        # base_product = process_image(base_product, product)
        # return nil if base_product.nil?

        base_product
      end

      # NOTE(cab): Import a variant
      def build_variant(base_product, product)
        variant = process_variant(base_product, product)
        return nil if variant.nil?

        # NOTE(cab): The client this has not decided how the real image will
        # work on the filemaker server. We are waiting for his feedback before
        # pulling the image data. For now we import the image manually.
        # variant = process_image(variant, product)
        # return nil if variant.nil?

        variant
      end

      def product_attrs(product)
        { name: product.name,
          description: product.description,
          item_number: product.item_number,
          price: product.price.to_f,
          regular_price: product.regular_price.to_f,
          meta_keywords: product.metatags,
          shipping_category: @shipping_category,
          tax_category: @tax_category,
          vendor_name: product.vendor_name,
          foldable: product.foldable?,
          available_on: product.available_on,
          max_product_per_customer: nil,  #product.max_product_per_customer
          max_product_per_order: nil      #product.max_product_per_order
        }
      end
    end
  end
end
