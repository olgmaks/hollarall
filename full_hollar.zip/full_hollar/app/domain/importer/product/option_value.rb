module Importer
  module Product
    module OptionValue
      include OptionType

      def process_option_value(product, option_value_name, option_type_name, attrs)
        option_value = Spree::OptionValue.find_by_name(option_value_name)
        option_value = create_option_value(product, option_type_name, attrs) if option_value.nil?
        return nil if option_value.nil?

        IMPORT_LOGGER.info("-- #{product} has one #{option_type_name} option value #{option_value.presentation}")

        option_value
      end

      private

      def create_option_value(product, option_type_name, attrs)
        option_type = find_option_type(product, option_type_name)
        return nil if option_type.nil?

        attrs = option_value_attrs(attrs, option_type)
        option_value = Spree::OptionValue.create(attrs)

        success = process_option_type(option_type, option_value, product)
        return nil if success.nil?

        option_value
      end

      def find_option_type(product, option_type_name)
        option_type_name.titleize
        option_type = Spree::OptionType.find_by_name(option_type_name)

        if option_type.nil?
          IMPORT_LOGGER.error("--- SKIP #{product}")
          IMPORT_LOGGER.error("Impossible to find OptionType #{option_type_name}")
          return nil
        end

        option_type
      end

      def option_value_attrs(attrs, option_type)
        attrs[:option_type] = option_type

        attrs
      end
    end
  end
end

