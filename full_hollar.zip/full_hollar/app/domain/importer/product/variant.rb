module Importer
  module Product
    module Variant
      include Variants::VariantColor
      include Variants::VariantSize
      include Variants::VariantStyle

      # NOTE(cab): We have to create a master variant will all the product
      # information to have a valid product. Also this let us eventually
      # make variants out of this product.
      def process_variant(base_product, product, is_master = false)
        IMPORT_LOGGER.info("#{product} - Importing the variant")

        variant = Spree::Variant.find_by(sku: product.sku)
        variant = generate_new_variant(base_product, is_master) if variant.nil?

        variant.attributes = variant_attrs(product)
        variant.option_values.clear

        # NOTE(cab): When we return nil, it means that we are having an error
        variant_color = process_variant_color(product)
        return nil if variant_color.nil?

        variant_size = process_variant_size(product)
        return nil if variant_size.nil?

        variant_style = process_variant_style(product)
        return nil if variant_style.nil?

        variant.option_values << variant_color if variant_color
        variant.option_values << variant_size  if variant_size
        variant.option_values << variant_style if variant_style

        base_product = add_option_types_to_product(base_product, product)
        if variant.valid?
          base_product = add_variant_to_product(base_product, variant)
          base_product
        else
          IMPORT_LOGGER.error("--- SKIP #{product}")
          IMPORT_LOGGER.error("We an invalid variant \'#{variant.errors.full_messages}\'")
          nil
        end
      end

      private

      def variant_attrs(product)
        # NOTE(cab): Convert the product to a variant. Since they all come from
        # the sam DB.
        { sku: product.sku,
          price: product.price.to_f,
          cost_price: product.cost_price.to_f,
          weight: product.weight,
          height: product.height,
          depth: product.depth }
      end

      def generate_new_variant(base_product, is_master)
        if is_master
          base_product.find_or_build_master
        else
          Spree::Variant.new
        end
      end

      def add_option_types_to_product(base_product, product)
        option_types = []
        Filemaker::Product.option_types.each do |option_type_name|
          option_type = Spree::OptionType.find_by_name(option_type_name)
          option_types << option_type if product.send("#{option_type_name}?")
        end

        base_product.option_types = option_types

        base_product
      end

      def add_variant_to_product(base_product, variant)
        # NOTE(cab): Add in array if new, else it will update down the line
        base_product.variants << variant if variant.new_record?

        base_product
      end
    end
  end
end
