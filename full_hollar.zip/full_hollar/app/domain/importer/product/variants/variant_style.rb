module Importer
  module Product
    module Variants
      module VariantStyle
        include ::Importer::Product::OptionValue

        def process_variant_style(product)
          unless product.style?
            IMPORT_LOGGER.info("-- #{product} has no style option type")
            return false
          end

          attrs = option_value_style_attrs(product)
          option_value = process_option_value(product, product.style, 'Style', attrs)
          return nil if option_value.nil?

          option_value
        end

        private

        def option_value_style_attrs(product)
          { name: product.style,
            presentation: product.style }
        end
      end
    end
  end
end
