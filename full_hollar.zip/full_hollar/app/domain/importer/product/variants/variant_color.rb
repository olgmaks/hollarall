module Importer
  module Product
    module Variants
      module VariantColor
        include ::Importer::Product::OptionValue

        def process_variant_color(product)
          # NOTE(cab): If we have only one of the two required field
          if product.at_least_one_color_field? && !product.color?
            has_error = missing_color_field_error(product)
            return nil if has_error
          end

          unless product.color?
            IMPORT_LOGGER.info("-- #{product} has no color option type")
            return false
          end

          attrs = option_value_color_attrs(product)
          option_value = process_option_value(product, product.hex_color, 'Color', attrs)
          return nil if option_value.nil?

          unless same_name?(option_value, product)
            log_different_name_error(option_value, product)
          end

          option_value
        end

        private

        def log_different_name_error(option_value, product)
          IMPORT_LOGGER.info("--- WARNING #{product}")
          IMPORT_LOGGER.info("The color field is different than the name of the color.
                              Option Value = #{option_value.presentation} - Product Color = #{product.color}")
        end

        def missing_color_field_error(product)
          if product.color.present?
            IMPORT_LOGGER.error("--- SKIP #{product}")
            IMPORT_LOGGER.error("The product has a color field but missing the hex color field \'#{product.color}\'")
            return true
          elsif product.hex_color.present?
            IMPORT_LOGGER.error("--- SKIP #{product}")
            IMPORT_LOGGER.error("The product has a hex color field but missing the color field \'#{product.hex_color}\'")
            return true
          end

          false
        end

        def same_name?(option_value, product)
          option_value.presentation == product.color
        end

        def option_value_color_attrs(product)
          { name: product.hex_color,
            presentation: product.color }
        end
      end
    end
  end
end
