module Importer
  module Product
    module Variants
      module VariantSize
        include ::Importer::Product::OptionValue

        def process_variant_size(product)
          unless product.size?
            IMPORT_LOGGER.info("-- #{product} has no size option type")
            return false
          end

          attrs = option_value_size_attrs(product)
          option_value = process_option_value(product, product.size, 'Size', attrs)
          return nil if option_value.nil?

          option_value
        end

        private

        def option_value_size_attrs(product)
          { name: product.size,
            presentation: product.size }
        end
      end
    end
  end
end
