module Importer
  module Product
    module Image

      # NOTE(cab): Here we call it viewable, since we can add an image to a
      # PRODUCT or a VARIANT. We do not need to differenciate them which is
      # why we use a generic name.
      def process_image(viewable, product)
        IMPORT_LOGGER.info("#{product} - Importing the image")

        # if product.image.blank?
        #   Rails.logger.warning "--- SKIP #{product.to_s}"
        #   Rails.logger.warning "-- There is no images for this product."
        #   return false
        # else

        # rand_number = Random.rand(1..3)
        # placeholder_image = Rails.root.join('db', 'examples', "product_placeholder_#{rand_number}.jpg")
        # image = Spree::Image.create(attachment: File.open(placeholder_image),
        #                             viewable: viewable)

        # NOTE(cab): Can't import product if no images
        return nil if image.nil?

        add_image_to_viewable(viewable, image)
      end

      private

      def add_image_to_viewable(viewable, image)
        # TODO(cab): Unsure what they do here.
        # We should not always add "new # images"
        viewable.images << image

        viewable
      end
    end
  end
end
