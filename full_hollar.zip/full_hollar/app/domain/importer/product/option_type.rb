module Importer
  module Product
    module OptionType
      def process_option_type(option_type, option_value, product)
        unless option_type.option_values.map(&:name).include?(option_value.name)
          option_type.option_values << option_value
          if option_type.save
            IMPORT_LOGGER.info("Added #{option_value.presentation} to #{option_type.presentation}")
            return option_type
          else
            IMPORT_LOGGER.error("--- SKIP #{product}")
            IMPORT_LOGGER.error("Unable to save the new option_value to the option_type #{option_type.errors.full_messages}")
            return nil
          end
        end

        option_type
      end
    end
  end
end
