module Importer
  class Base
    # TODO(cab) : Would like to eventually refactor this
    LOCAL_IMPORT_LOCATION_CSV       = Rails.root.join('tmp', 'import', 'csv')
    LOCAL_IMPORT_LOCATION_IMAGES    = Rails.root.join('tmp', 'import', 'images')
    LOCAL_IMPORT_ARCHIVE_PATH       = Rails.root.join(LOCAL_IMPORT_LOCATION_CSV, 'archive')
    LOCAL_IMPORT_IMAGE_ARCHIVE_PATH = Rails.root.join(LOCAL_IMPORT_LOCATION_IMAGES, 'archive')

    def self.create_archive_dir
      archive_location = LOCAL_IMPORT_ARCHIVE_PATH
      FileUtils.mkdir_p(archive_location) unless File.directory?(archive_location)
    end

    def self.create_csv_dir
      csv_location = LOCAL_IMPORT_LOCATION_CSV
      FileUtils.mkdir_p(csv_location) unless File.directory?(csv_location)
    end

    def self.create_image_archive_dir
      archive_location = LOCAL_IMPORT_IMAGE_ARCHIVE_PATH
      FileUtils.mkdir_p(archive_location) unless File.directory?(archive_location)
    end

    def self.create_image_dir
      images_location = LOCAL_IMPORT_LOCATION_IMAGES
      FileUtils.mkdir_p(images_location) unless File.directory?(images_location)
    end
  end
end

