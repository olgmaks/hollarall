module Importer
  class Products
    def initialize(number_to_import)
      @products = load_products(number_to_import)
      @success = 0
      @product_count = @products.count
    end

    def perform
      factory = Importer::Product::ProductFactory.new
      IMPORT_LOGGER.info("BEGIN -- Importing #{@product_count} products")
      @products.each do |product|
        next if !product.should_update_or_create? || !product.valid?

        constructed_product = factory.construct(product)
        save(constructed_product, product)
      end

      display_stats
    end

    private

    def load_products(number_to_import)
      begin
        if number_to_import > 0
          return Filemaker::Product.limit(number_to_import).all
        else
          return Filemaker::Product.all
        end
      rescue Filemaker::Errors::CommunicationError => e
        IMPORT_LOGGER.fatal('MAJOR -- Unable to retrieve any results from Filemaker')
        IMPORT_LOGGER.fatal(e.message)
        return []
      end
    end

    def save(constructed_product, product)
      if constructed_product && constructed_product.save
        @success += 1
        IMPORT_LOGGER.info("#{product} - Imported!")
      else
        IMPORT_LOGGER.error("#{constructed_product.errors.full_messages}") if constructed_product
        IMPORT_LOGGER.error("#{product} - Importation failed!")
      end
    end

    def display_stats
      @failure = @product_count - @success
      IMPORT_LOGGER.info("TOTAL: #{@product_count}, SUCCESS: #{@success}, FAILURE: #{@failure}")
      IMPORT_LOGGER.info("END -- Finished importing #{@product_count} products")
    end
  end
end
