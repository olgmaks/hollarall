require 'import_logger'

module Importer
  class Importer
    def import_products(number_to_import = -1)
      ::Importer::Products.new(number_to_import).perform
    end

    def import_products_from_csv(archive = true)
      ::Importer::Base.create_csv_dir
      ::Importer::CSV::Products.new(archive).perform
    end

    def import_images_from_folder(archive = true)
      ::Importer::Base.create_image_dir
      ::Importer::Images.new(archive).perform
    end
  end
end

