module Importer
  module FileSystem
    module FileSystemHelper
      def archive_all(files)
        IMPORT_LOGGER.info('Archiving the imported images')
        ::Importer::Base.create_archive_dir

        files.each do |file|
          archive(file)
        end
      end

      # TODO(cab): A little bit of code cleanup
      def archive(file)
        filename = File.basename(file)
        archive_location = create_folder

        FileUtils.move(file, "#{archive_location}/#{filename}")
      end

      private

      def create_folder
        archive_location = ::Importer::Base::LOCAL_IMPORT_IMAGE_ARCHIVE_PATH
        archive_location = format_foldername(archive_location)
        FileUtils.mkdir_p(archive_location) unless File.directory?(archive_location)

        archive_location
      end

      def format_foldername(folder)
        date = DateTime.now.strftime('%Y%m%d')
        File.join(folder, date)
      end
    end
  end
end


