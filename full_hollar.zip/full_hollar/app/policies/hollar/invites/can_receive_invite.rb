module Hollar
  module Invites
    class CanReceiveInvite
      attr_reader :email, :error

      def initialize(user:, email:,
                     user_repo: ::Spree::User,
                     invite_repo: ::Spree::Invite)
        @user = user
        @email = email
        @user_repo = user_repo
        @invite_repo = invite_repo
      end

      def invitable?
        valid? && !has_account? && !invited?
      end

      private

      attr_reader :user, :user_repo, :invite_repo

      def has_account?
        if user_repo.exists?(email: email)
          @error = :existing_accounts

          true
        end
      end

      def invited?
        if invite_repo.exists?(referer: user, referee_email: email)
          @error = :existing_invites

          true
        end
      end

      def valid?
        if EmailValidator.valid?(email)
          true
        else
          @error = :invalid_emails

          false
        end
      end
    end
  end
end
