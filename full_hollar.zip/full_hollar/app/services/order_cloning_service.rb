class OrderCloningService
  attr_reader :source, :items, :creator

  def initialize(params)
    @source  = params[:source]
    @items   = params[:items]
    @creator = params[:creator]
  end

  def perform
    return if source.gift_card?

    populate_with_items
    save_and_recalculate
    return order
  end

  private

  def save_and_recalculate
    order.save && order.update!
  end

  def populate_with_items
    items.each(&method(:assign_to_order))
  end

  def assign_to_order(item)
    quantity = [item.variant.total_on_hand, item.quantity].min
    order.contents.add(item.variant, quantity)
  end

  def order
    @order ||= Spree::Order.new do |o|
      o.bill_address_id = source.bill_address_id
      o.ship_address_id = source.ship_address_id
      o.store_id        = source.store_id
      o.created_by      = creator
      o.email           = source.email
      o.shipment_state  = INITIAL_SHIPMENT_STATE
      o.payment_state   = INITIAL_PAYMENT_STATE
      o.user_id         = source.user_id
    end
  end

  INITIAL_SHIPMENT_STATE = :pending
  INITIAL_PAYMENT_STATE  = :checkout
end
