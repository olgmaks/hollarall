module OrderCheckoutRulesHelper
  def retrieve_product_quantity_of_previous_orders(order_id, user_id, related_product_id)
    ::Spree::LineItem.joins(:order, :variant).
      where(spree_orders: { user_id: user_id },
            spree_variants: { product_id: related_product_id }).
      where.not(order_id: order_id).
      sum(:quantity)
  end

  def retrieve_other_variant_quantity_of_current_order(order, variant_id, related_product_id)
    order.line_items.includes(:variant).
      where(spree_variants: { product_id: related_product_id }).
      where.not(variant_id: variant_id).
      sum(:quantity)
  end
end
