class OrderCheckoutRules
  include ErrorHelper
  include CheckoutError
  include OrderCheckoutRulesHelper

  def initialize(order, user)
    @order = order
    @user = user
    @errors = ::Error.new(status_code)
  end

  def verify_against_all_rules
    verify_minimum_quantity
    verify_insufficient_stock
    verify_max_products_per_line_items
    verify_max_by_group
    errors
  end

  def verify_insufficient_stock
    removed_error_code = ::ErrorCode::ORDER_PRODUCTS_REMOVED
    adjusted_error_code = ::ErrorCode::ORDER_PRODUCTS_ADJUSTED

    err_collection = { removed_error_code => [],
                       adjusted_error_code => [] }

    order.line_items.each do |line_item|
      if !line_item.variant.in_stock?
        err_collection[removed_error_code] << line_item.variant
      elsif line_item.insufficient_stock?
        err_collection[adjusted_error_code] << line_item.variant
      end
    end

    if err_collection[removed_error_code].any?
      variants = err_collection[removed_error_code]
      errors.add_error(insufficient_stock_error(removed_error_code, variants))
    end

    if err_collection[adjusted_error_code].any?
      variants = err_collection[adjusted_error_code]
      errors.add_error(insufficient_stock_error(adjusted_error_code, variants))
    end

    errors
  end

  def verify_minimum_quantity
    errors.add_error(minimum_quantity_error) unless order.minimum_amount?

    errors
  end

  def verify_max_products_per_line_items
    order.line_items.each do |line_item|
      related_product = ::Spree::Product.by_variant_id(line_item.variant_id)
      next if related_product.nil?

      verify_max_product(line_item.variant_id, line_item.quantity, related_product)
    end

    errors
  end

  def verify_would_hit_max_by_group(variant_id, quantity)
    product = ::Spree::Product.by_variant_id(variant_id)
    return errors if product.nil? || product.group.nil?

    items = order.line_items.select { |line_item| line_item.group == product.group }
    verify_group(items, product.group.limit, quantity)

    errors
  end

  def verify_max_by_group
    order.line_items.group_by(&:group).each do |group, items|
      next unless group
      verify_group(items, group.limit)
    end

    errors
  end

  def verify_group(items, limit, additional_quantity = 0)
    return if items.sum(&:quantity) + additional_quantity <= limit

    error_code = ::ErrorCode::ORDER_MAX_PRODUCT_PER_GROUP_HIT
    details    = { group_limit: limit, items: items }
    errors.add_error(max_product_per_group_reached_error(error_code, details))
  end


  def verify_would_hit_max_product(variant_id, to_add_quantity)
    related_product = ::Spree::Product.by_variant_id(variant_id)
    return errors if related_product.nil?

    current_line_item = order.line_items.detect { |li| li.variant.id == variant_id }
    current_quantity = current_line_item ? current_line_item.quantity : 0
    quantity = current_quantity + to_add_quantity
    verify_max_product(variant_id, quantity, related_product)
  end

  def error_container
    errors
  end

  private

  attr_accessor :order, :user, :errors

  def verify_max_product(variant_id, quantity, related_product)
    variant = ::Spree::Variant.find(variant_id)
    max_product_order_error_code = ::ErrorCode::ORDER_MAX_PRODUCT_PER_ORDER_HIT
    max_product_customer_error_code = ::ErrorCode::ORDER_MAX_PRODUCT_PER_CUSTOMER_HIT

    cart_product_quantity = quantity
    cart_product_quantity += retrieve_other_variant_quantity_of_current_order(order, variant.id, related_product.id)

    if reached_max_products_per_order?(related_product, cart_product_quantity)
      errors.add_error(max_product_reached_error(max_product_order_error_code, variant))
    elsif reached_max_products_per_customer?(related_product, cart_product_quantity)
      errors.add_error(max_product_reached_error(max_product_customer_error_code, variant))
    end

    errors
  end

  def reached_max_products_per_order?(related_product, cart_product_quantity)
    return true if related_product.hidden && cart_product_quantity > 1

    max_product_per_order = related_product.max_product_per_order
    return false if max_product_per_order.nil? || max_product_per_order == 0

    return true if cart_product_quantity > max_product_per_order

    false
  end

  def reached_max_products_per_customer?(related_product, cart_product_quantity)
    max_product_per_customer = related_product.max_product_per_customer
    return false if max_product_per_customer.nil? || max_product_per_customer == 0 || user.nil?

    historic_product_quantity = retrieve_product_quantity_of_previous_orders(order.id,
                                                                             user.id,
                                                                             related_product.id)

    return true if historic_product_quantity + cart_product_quantity > max_product_per_customer

    false
  end

  def status_code
    422
  end
end
