class OrderCheckoutSolver
  include ErrorHelper
  include OrderCheckoutRulesHelper

  def initialize(order, errors)
    @order = order
    @errors = errors
  end

  def auto_solve
    solve_products_removed_error
    solve_products_adjusted_error
    solve_max_product_per_customer_error
    solve_max_product_per_order_error
    solve_max_product_per_group_error
  end

  def solve_max_product_per_group_error
    order.line_items.group_by(&:group).each do |group, items|
      total = items.sum(&:quantity)
      next if group.nil? || group.limit > total
      quantity_to_remove = total - group.limit

      items.sort_by(&:quantity).reverse.each_with_index do |item, index|
        break if quantity_to_remove <= 0

        amount = [quantity_to_remove, [1, item.quantity - 1].max].min
        amount = item.quantity if index + 1 > group.limit # In case it's time to remove items

        order.contents.remove(item.variant, amount)
        quantity_to_remove -= amount
      end
    end
  end

  def solve_products_removed_error
    infos = errors.filter_by_code(::ErrorCode::ORDER_PRODUCTS_REMOVED)
    infos.each do |info|
      variants = info[:details].map { |detail| ::Spree::Variant.find(detail[:variant_id]) }
      order.line_items.each do |line_item|
        next unless variants.include?(line_item.variant)
        order.contents.remove(line_item.variant, line_item.quantity)
      end
    end
  end

  def solve_products_adjusted_error
    infos = errors.filter_by_code(::ErrorCode::ORDER_PRODUCTS_ADJUSTED)
    infos.each do |info|
      variants = info[:details].map { |detail| ::Spree::Variant.find(detail[:variant_id]) }
      order.line_items.each do |line_item|
        next unless variants.include?(line_item.variant)
        on_hand = ::Spree::Stock::Quantifier.new(line_item.variant).total_on_hand
        order.contents.remove(line_item.variant, line_item.quantity - on_hand)
      end
    end
  end

  def solve_max_product_per_customer_error
    infos = errors.filter_by_code(::ErrorCode::ORDER_MAX_PRODUCT_PER_CUSTOMER_HIT)
    infos.each do |info|
      variant_id = info[:details][0][:variant_id]
      product_id = info[:details][0][:product_id]
      product = ::Spree::Product.find(product_id)
      variant = ::Spree::Variant.find(variant_id)

      past_quantity = retrieve_product_quantity_of_previous_orders(order, order.user.id, product.id)
      current_quantity = retrieve_other_variant_quantity_of_current_order(order, variant_id, product.id)
      line_item = order.line_items.detect { |li| li.variant.id == variant_id }
      current_quantity += line_item.quantity if line_item.present?

      if past_quantity >= product.max_product_per_customer
        order.contents.remove(variant, current_quantity)
      else
        quantity_to_remove = product.max_product_per_customer - past_quantity
        order.contents.remove(variant, current_quantity - quantity_to_remove)
      end
    end
  end

  def solve_max_product_per_order_error
    infos = errors.filter_by_code(::ErrorCode::ORDER_MAX_PRODUCT_PER_ORDER_HIT)
    infos.each do |info|
      variant_id = info[:details][0][:variant_id]
      product_id = info[:details][0][:product_id]
      variant = ::Spree::Variant.find(variant_id)
      product = ::Spree::Product.find(product_id)

      current_quantity = retrieve_other_variant_quantity_of_current_order(order, variant_id, product.id)

      line_item = order.line_items.detect { |li| li.variant.id == variant_id }
      current_quantity += line_item.quantity if line_item

      if product.max_product_per_order && current_quantity > product.max_product_per_order
        order.contents.remove(variant, current_quantity - product.max_product_per_order)
      end
    end
  end

  private

  attr_accessor :order, :errors
end
