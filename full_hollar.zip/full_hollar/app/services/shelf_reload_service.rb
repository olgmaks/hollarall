class ShelfReloadService
  def self.call(params)
    new(params).call
  end

  def initialize(params)
    @source = params[:source]
  end

  def call
    return unless referenced_taxon

    source.shelf_product_memberships.destroy_all
    source.update!(product_ids: load_products)
  end

  private

  def load_products
    collection     = retrieve(scope: :most_likeable)
    collection.push *retrieve(scope: :most_purchasable, excluded: collection, args: TIMEFRAME)
    collection.push *retrieve(scope: :newest, excluded: collection, limit: false)

    collection.slice(0, TOTAL).map(&:id).shuffle
  end

  def retrieve(scope:, excluded: [], args: [], limit: true)
    excluded_ids = excluded.pluck(:id) if excluded.respond_to?(:id)
    collection   = products.unscope(:order).where.not(id: excluded_ids).send(scope, *args)

    limit ? collection.limit(PER_CRITERIA) : collection
  end

  attr_reader :source

  delegate :referenced_taxon, to: :source, allow_nil: true
  delegate :products, to: :referenced_taxon

  TOTAL        = 15
  PER_CRITERIA = 5
  TIMEFRAME    = 3.days
end
