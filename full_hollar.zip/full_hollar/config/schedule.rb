# Use this file to easily define all of your cron jobs.
#
# It's helpful, but not entirely necessary to understand cron before proceeding.
# http://en.wikipedia.org/wiki/Cron

# Example:
#
# set :output, "/path/to/my/cron_log.log"
#
# every 2.hours do
#   command "/usr/bin/some_great_command"
#   runner "MyModel.some_method"
#   rake "some:great:rake:task"
# end
#
# every 4.days do
#   runner "AnotherModel.prune_old_records"
# end

# Learn more: http://github.com/javan/whenever

require 'active_support/time'
Time.zone = 'Pacific Time (US & Canada)'

env :PATH, '/usr/local/bin:/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/sbin:/opt/aws/bin:/opt/aws/bin'

# send notification on error output
env :MAILTO, 'productionsupport@hollar.com'

# only redirect standard out
set :output, standard: 'log/cron.log'

# source stack environment variables before each command
set :job_template, "bash -l -c 'source /etc/profile.d/hollar.sh; :job'"

every 3.minutes do
  rake "searchkick:reindex_touched_products"
end

every 5.minutes do
  if @environment == 'production'
    rake "fixer:ensure_orders_sent_to_wms"
  end
end

every 10.minutes do
  if @environment == 'production'
    rake "snapfulfil:process_outbound_messages"
  end
end

every 30.minutes do
  if @environment == 'production'
    rake "google_data_feed:generates"
  end
end

every 1.day do
  rake "hollar:data:invalidate_credits"
end

every 1.day do
  if @environment == 'production' || @environment == 'qa2'
    rake "hollar:send_todays_gift_cards"
  end
end

job_time = Time.zone.parse('12:01am').utc.strftime('%I:%M%p')
every :day, at: job_time do
  if @environment == 'production'
    rake 'rs:generate_promo_codes'
    rake 'hollar:update_delayed_orders'
  end
end


autoload_job_time = Time.zone.parse('03:00am')
every :day, at: autoload_job_time do
  runner 'ShelvesReloadWorker.perform_now'
end
