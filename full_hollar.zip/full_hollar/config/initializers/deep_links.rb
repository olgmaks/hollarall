DEEP_LINKS = HashWithIndifferentAccess.new(YAML.load_file("#{Rails.root}/config/deep_links.yml")[Rails.env])
