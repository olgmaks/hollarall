if defined?(Minfraud)
  Minfraud.configure do |c|
    c.user_id     = ENV['MINFRAUD_USER_ID']
    c.license_key = ENV['MINFRAUD_LICENSE_KEY']
  end
end
