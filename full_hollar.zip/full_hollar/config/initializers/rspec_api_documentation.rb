if Rails.env.test?
  require 'rspec_api_documentation'

  # Values listed are the default values
  RspecApiDocumentation.configure do |config|
    # Set the application that Rack::Test uses
    config.app = Rails.application

    # Output folder
    config.docs_dir = Rails.root.join("doc")

    # An array of output format(s).
    # Possible values are :json, :html, :combined_text, :combined_json,
    #   :json_iodocs, :textile, :markdown, :append_json, :slate
    config.format = [:slate]

    # Used when adding a cURL output to the docs
    # Allows you to filter out headers that are not needed in the cURL request,
    # such as "Host" and "Cookie". Set as an array.
    config.curl_headers_to_filter = nil

    # Change how the post body is formatted by default, you can still override by `raw_post`
    # Can be :json, :xml, or a proc that will be passed the params
    config.request_body_formatter = :json

    # By default, when these settings are nil, all headers are shown,
    # which is sometimes too chatty. Setting the parameters to an
    # array of headers will render *only* those headers.
    config.request_headers_to_include = [""]
    config.response_headers_to_include = [""]

    # Change the name of the API on index pages
    config.api_name = "Hollar Platform API"
  end
end
