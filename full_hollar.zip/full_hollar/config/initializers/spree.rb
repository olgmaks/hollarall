# Configure Solidus Preferences

# See http://docs.solidus.io/Spree/AppConfiguration.html for details

Spree.config do |config|
  # Without this preferences are loaded and persisted to the database. This
  # changes them to be stored in memory.
  # This will be the default in a future version.
  config.use_static_preferences!

  ### Core:

  # Default currency for new sites
  config.currency = "USD"

  # from address for transactional emails
  config.mails_from = "store@example.com"

  # Uncomment to stop tracking inventory levels in the application
  # config.track_inventory_levels = false

  # When true, product caches are only invalidated when they come in or out of
  # stock. Default is to invalidate cache on any inventory changes.
  # config.binary_inventory_cache = true

  ### Frontend:

  # Custom logo for the frontend
  # config.logo = "logo/solidus_logo.png"

  # Template to use when rendering layout
  # config.layout = "spree/layouts/spree_application"

  ### Admin:

  # Custom logo for the admin
  config.admin_interface_logo = "logo-hollar.png"

  # Gateway credentials can be configured statically here and referenced from
  # the admin. They can also be fully configured from the admin.
  #
  # config.static_model_preferences.add(
  #   Spree::Gateway::StripeGateway,
  #   'stripe_env_credentials',
  #   secret_key: ENV['STRIPE_SECRET_KEY'],
  #   publishable_key: ENV['STRIPE_PUBLISHABLE_KEY'],
  #   server: Rails.env.production? ? 'production' : 'test',
  #   test: !Rails.env.production?
  # )

  # Products per page
  config.products_per_page = 32

  # Disable guest checkout
  config.allow_guest_checkout = false
end

# Use Airbrake to notify us of Spree API errors
::Spree::Api::BaseController.error_notifier = ->(e, _) { Airbrake.notify(Airbrake.build_notice(e)) }

Spree.user_class = "Spree::LegacyUser"
Spree::Auth::Config[:confirmable] = false

config = Rails.application.config
config.spree.calculators.shipping_methods << Spree::Calculator::Shipping::MerchantFlatRateStandard
config.spree.calculators.shipping_methods << Spree::Calculator::Shipping::MerchantFlatRateExpedited
config.spree.calculators.shipping_methods << Spree::Calculator::Shipping::VariableRate
config.spree.calculators.tax_rates << Spree::Calculator::CloudTax
config.spree.calculators.promotion_actions_create_adjustments << Spree::Calculator::HighestPricedItemPercent

[Spree::Gateway::MobilePaypal, CompPaymentMethod].each { |method| config.spree.payment_methods << method }
[Spree::Promotion::Rules::MobileFirstOrder,
 Spree::Promotion::Rules::MobileOrder,
 Spree::Promotion::Rules::Merchant].each { |promo| config.spree.promotions.rules << promo }

Spree::PermittedAttributes.user_attributes << [:email, :first_name, :last_name, :gender]

Spree::PermittedAttributes.taxon_attributes << :image
Spree::PermittedAttributes.taxon_attributes << :published
Spree::PermittedAttributes.taxon_attributes << :display_web
Spree::PermittedAttributes.taxon_attributes << :display_android
Spree::PermittedAttributes.taxon_attributes << :display_ios
Spree::PermittedAttributes.taxon_attributes << {
  images_attributes: [:attachment]
}
Spree::PermittedAttributes.taxon_attributes << :featured_image
Spree::PermittedAttributes.taxon_attributes << :icon_image

Spree::PermittedAttributes.taxonomy_attributes << :image
Spree::PermittedAttributes.user_attributes << { bill_address_attributes:
                                                [:firstname,
                                                 :lastname,
                                                 :address1,
                                                 :address2,
                                                 :city,
                                                 :country_id,
                                                 :state_id,
                                                 :zipcode,
                                                 :phone]
                                              }
Spree::PermittedAttributes.user_attributes << { ship_address_attributes:
                                                [:firstname,
                                                 :lastname,
                                                 :address1,
                                                 :address2,
                                                 :city,
                                                 :country_id,
                                                 :state_id,
                                                 :zipcode,
                                                 :phone
                                                ]
                                              }
