attachment_config = {
  s3_credentials: {
      access_key_id:     ENV['AWS_ACCESS_KEY_ID'],
      secret_access_key: ENV['AWS_SECRET_ACCESS_KEY'],
      bucket:            ENV['S3_BUCKET_NAME']
  },

  storage:        :s3,
  s3_headers:     { "Cache-Control" => "max-age=31557600" },
  s3_protocol:    "https",
  bucket:         ENV['S3_BUCKET_NAME'],
  url:            ENV['CDN_ASSET_HOST'].blank? ? ":s3_domain_url" : ":s3_alias_url",
  s3_host_alias:  ENV['CDN_ASSET_HOST'],

  path:           "/#{Rails.env}/:class/:id/:style/:basename.:extension"
}

ATTACHED_FILE_ENTITY = {
  background: '2400x2838>',
  heading_logo: '188x69>',
  product_image: '780x780#',
  sign_up_logo: '78x42>'
}

ATTACHED_FILE_ENTITY.each do |attachment, size|
  Spree::MarketingPage.attachment_definitions[attachment.to_sym].merge!(attachment_config) if !!defined? attachment_config
  Spree::MarketingPage.attachment_definitions[attachment.to_sym].merge!(
    default_url: "missing_#{attachment}.png",
    styles: {
      landing: size,
      thumb: '300x300>'
    }
  )
end
