require "middleware/rack/admin"
require "middleware/rack/www"
require "middleware/rack/utm"

Rails.application.config.middleware.insert_before(
  "ActionDispatch::Cookies", "Rack::Utm"
)
