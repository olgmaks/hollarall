Airbrake.configure do |config|
  # Airbrake will complain if the following two keys are nil, even in ignored environments, so use defaults
  config.project_key = ENV['AIRBRAKE_API_KEY'].presence || '00000000000000000000000000000000'
  config.project_id = ENV['AIRBRAKE_PROJECT_ID'].presence || '117171'
  config.environment = Rails.env
  config.ignore_environments = %w(development test)
  config.root_directory = Rails.root
end

# Ignore very frequent and inconsequential errors
Airbrake.add_filter do |notice|
  notice.ignore! if notice[:errors].any? do |error|
    # Ignore:
    # - ActionController::InvalidAuthenticityToken errors from stale pages
    # - TaxCloud zip code mismatches
    error[:type] == 'ActionController::InvalidAuthenticityToken' ||
    (error[:type] == 'TaxCloud::Errors::ApiError' &&
     error[:message] =~ /The Ship To zip code \(\d+\) is not valid for this state/)
  end
end
