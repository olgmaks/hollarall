token = ENV.fetch('LOGENTRIES_TOKEN', nil)
if !Rails.env.development? && !Rails.env.debug? && !Rails.env.test? && token.present?
  Rails.logger = Le.new(token, log_level: Logger.const_get(Rails.configuration.log_level.to_s.upcase))
end
