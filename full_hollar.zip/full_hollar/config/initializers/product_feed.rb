PRODUCT_FEED = HashWithIndifferentAccess.new(YAML.load_file("#{Rails.root}/config/product_feed.yml")[Rails.env])
