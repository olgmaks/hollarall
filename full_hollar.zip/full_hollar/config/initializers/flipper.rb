require 'flipper'
require 'flipper-active_record'
require 'flipper/adapters/memory'

FLIPPER_CONFIG = HashWithIndifferentAccess.new(YAML.load_file(Rails.root.join('config', 'flipper.yml')))

module FeatureFlags
  extend self

  attr_reader :experiment_features
  attr_reader :feature_experiments

  def set_experiments(active_experiment_hashes)
    @experiment_enables = []

    unless active_experiment_hashes.blank?
      features = experiment_features
      active_experiment_hashes.each do |h|
        if features[h] && FeatureExperiment.find_by(name: features[h].to_s, enabled: true)
          @experiment_enables << features[h]
        end
      end
    end
  end

  def [](flag)
    if @experiment_enables && @experiment_enables.include?(flag.to_sym)
      return Flipper::Feature.new(flag.to_sym, Flipper::Adapters::Memory.new).tap(&:enable)
    end

    flipper[flag]
  end

  def experiment_features
    if @experiment_features.nil?
      read_experiments
    end
    @experiment_features
  end

  def feature_experiments
    if @feature_experiments.nil?
      read_experiments
    end
    @feature_experiments
  end

  def read_experiments
    @experiment_features = {}
    @feature_experiments = {}

    if FeatureExperiment.connection.table_exists?(FeatureExperiment.table_name) && FeatureExperiment.any?
      FeatureExperiment.all.each do |exp|
        experiment_array = [exp.try(:experiment_id), exp.try(:variation_id)].flatten.map(&:to_s)
        @feature_experiments[exp.try(:name).to_sym] = experiment_array
        @experiment_features[experiment_array] = exp.try(:name).to_sym
      end
    end
  end

  def flipper
    if @feature_experiments.nil?
      read_experiments
    end

    @flipper ||= Flipper.new(Flipper::Adapters::ActiveRecord.new).tap do |flip|
      # make sure that all defined features are created
      (FLIPPER_CONFIG[:features] + @feature_experiments.keys).each do |flag|
        flip.adapter.add(flip[flag])
      end
    end
  end
end

class CanAccessFlipperUI
  def self.matches?(request)
    current_user = request.env['warden'].user
    current_user.present? && current_user.respond_to?(:admin?) && current_user.admin?
  end
end
