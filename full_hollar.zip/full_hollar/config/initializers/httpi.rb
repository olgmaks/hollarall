HTTPI.logger = Rails.logger
