# config/initializers/elasticsearch.rb
require 'faraday_middleware/aws_signers_v4'

if Rails.env.development? || Rails.env.debug? || Rails.env.test?
  searchkick_development_prefix = `hostname -s`.strip
  if searchkick_development_prefix.blank?
    searchkick_development_prefix = Socket.ip_address_list.detect { |a| a.ipv4? && !a.ipv4_loopback? }.ip_address
    if searchkick_development_prefix.blank?
      raise "Unable to find a development prefix to use with Elasticsearch (even tried multi)."
    end
  end

  searchkick_development_prefix = "#{ENV['LOGNAME']}_#{searchkick_development_prefix}".downcase.gsub(/[^a-z0-9]+/, '_')

  Searchkick.env = "#{searchkick_development_prefix}_#{Rails.env}"
end

if ENV['AWS_ELASTICSEARCH_ENDPOINT_URL'].present?
  Searchkick.client =
    Elasticsearch::Client.new(
      url: ENV["AWS_ELASTICSEARCH_ENDPOINT_URL"],
      transport_options: { request: { timeout: 10 } }
    ) do |f|
      f.request :aws_signers_v4,
                credentials: Aws::Credentials.new(ENV["AWS_ACCESS_KEY_ID"], ENV["AWS_SECRET_ACCESS_KEY"]),
                service_name: "es",
                region: ENV['AWS_REGION']
    end

  if Rails.env.test?
    es_url_rx = Regexp.new(Regexp.escape(ENV["AWS_ELASTICSEARCH_ENDPOINT_URL"]))
    WebMock.disable_net_connect!(allow: es_url_rx, allow_localhost: true)
  end
end

module Searchkick
  class Index
    # override Searchkick's index method to use update instead to preserve Oryx-set columns in ES
    # (also allow up to 5 retries on conflict when Oryx is updating the same record at the same time)
    def bulk_index(records)
      Searchkick.queue_items(records.map do |r|
        {
          update: record_data(r).merge(_retry_on_conflict: 5,
                                       data: {
                                         doc: search_data(r),
                                         doc_as_upsert: true
                                       })
        }
      end)
    end

    # allow up to 5 retries on conflict when Oryx is updating the same record at the same time
    def bulk_update(records, method_name)
      Searchkick.indexer.queue(records.map do |r|
        {
          update: record_data(r).merge(_retry_on_conflict: 5,
                                       data: {
                                         doc: search_data(r, method_name)
                                       })
        }
      end)
    end
  end

  # override Searchkick's perform_items method to find update errors instead of index errors
  def self.perform_items(items)
    if items.any?
      response = client.bulk(body: items)
      if response["errors"]
        first_item = response["items"].first
        raise Searchkick::ImportError, (first_item["update"] || first_item["delete"])["error"]
      end
    end
  end
end
