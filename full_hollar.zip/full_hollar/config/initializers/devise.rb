Devise.secret_key = "628e68d973520b137db5048d2978db542a698bce3831e3efc2a7a2d032c51ff6865bad2cc643ec59e386a531b91ebf2b38bc"
Devise.impersonate_one_time_use = true
Devise.impersonate_expires_in = 60.minutes

Warden::Manager.after_set_user do |user,auth,opts|
  auth.cookies[:signed_in] = 1
end

Warden::Manager.before_logout do |user,auth,opts|
  auth.cookies.delete :signed_in
end
