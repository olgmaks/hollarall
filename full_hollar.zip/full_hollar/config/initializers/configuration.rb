module Spree
  Hollar::Config = Spree::AppConfiguration.new
end