require File.expand_path('../boot', __FILE__)

require 'rails/all'
require 'flipper/middleware/memoizer'

# Require the gems listed in Gemfile, including any gems
# you've limited to :test, :development, or :production.
Bundler.require(*Rails.groups)

module Hollar
  class Application < Rails::Application
    console do
      # load some "helpers" for the console that effectively extend Rails::ConsoleMethods
      require 'console_methods'

      # See http://blog.nhocki.com/2015/06/03/add-helper-methods-to-your-rails-console-with-pry/
      TOPLEVEL_BINDING.eval('self').extend Hollar::ConsoleMethods
    end

    config.to_prepare do
      # Load application's model / class decorators
      Dir.glob(File.join(File.dirname(__FILE__), "../app/**/*_decorator*.rb")) do |c|
        Rails.configuration.cache_classes ? require(c) : load(c)
      end

      # Load application's view overrides
      Dir.glob(File.join(File.dirname(__FILE__), "../app/overrides/*.rb")) do |c|
        Rails.configuration.cache_classes ? require(c) : load(c)
      end

      # Load application's view overrides
      Dir.glob(File.join(File.dirname(__FILE__), "../app/repositories/*.rb")) do |c|
        Rails.configuration.cache_classes ? require(c) : load(c)
      end

      # Action Mailer temporary override
      Dir.glob(File.join(File.dirname(__FILE__), "../lib/action_mailer/*.rb")) do |c|
        Rails.configuration.cache_classes ? require(c) : load(c)
      end

      # Includes email template selector for A/B tests
      if Rails.configuration.cache_classes
        require 'email_template_selector'
      else
        load Rails.root.join('lib', 'email_template_selector.rb')
      end
    end

    # Settings in config/environments/* take precedence over those specified here.
    # Application configuration should go into files in config/initializers
    # -- all .rb files in that directory are automatically loaded.

    # Set Time.zone default to the specified zone and make Active Record auto-convert to this zone.
    # Run "rake -D time" for a list of tasks for finding time zone names. Default is UTC.
    config.time_zone = 'Pacific Time (US & Canada)'

    # The default locale is :en and all translations from config/locales/*.rb,yml are auto loaded.
    # config.i18n.load_path += Dir[Rails.root.join('my', 'locales', '*.{rb,yml}').to_s]
    # config.i18n.default_locale = :de

    # Do not swallow errors in after_commit/after_rollback callbacks.
    config.active_record.raise_in_transactional_callbacks = true
    config.generators do |g|
      g.test_framework :rspec,
                       fixtures: true,
                       view_specs: false,
                       helper_specs: false,
                       routing_specs: false,
                       controller_specs: true,
                       request_specs: true
      g.fixture_replacement :factory_girl, dir: "spec/factories"
    end

    config.exceptions_app = routes

    # configure job queuing backend
    if Rails.env.test?
      config.active_job.queue_adapter = :test
    elsif Rails.env.development? || Rails.env.debug?
      config.active_job.queue_adapter = :sucker_punch
    else
      config.active_job.queue_adapter = :shoryuken
    end
    config.active_job.queue_name_prefix = Rails.env

    if ENV["ELASTICACHE_ENDPOINT"].present?
      elasticache = Dalli::ElastiCache.new(ENV["ELASTICACHE_ENDPOINT"])

      config.cache_store = :dalli_store, elasticache.servers, {
        namespace: "hollar-#{Rails.env}",
        expires_in: 1.day,
        compress: true
      }
    end

    # add app/assets/fonts to the asset path
    config.assets.paths << Rails.root.join("app", "assets", "fonts")

    config.middleware.use Flipper::Middleware::Memoizer, -> { FeatureFlags.flipper }
    config.versioncake.default_version = 1
  end
end
require 'active_job/arguments'
ActiveJob::Arguments::TYPE_WHITELIST << BigDecimal
