workers Integer(ENV['WEB_CONCURRENCY'] || 4)
threads_count = Integer(ENV['RAILS_MAX_THREADS'] || 5)
threads threads_count, threads_count

preload_app!

rackup      DefaultRackup
environment ENV['RACK_ENV'] || 'development'
worker_timeout Integer(ENV['PUMA_WORKER_TIMEOUT'] || 60)

on_worker_boot do
  ActiveRecord::Base.establish_connection
end
