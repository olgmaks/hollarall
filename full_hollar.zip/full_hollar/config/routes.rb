Rails.application.routes.draw do
  mount Spree::Core::Engine, at: '/'

  # config/routes.rb
  get 'healthcheck/_status', to: 'healthcheck#alive'

  Spree::Core::Engine.add_routes do
    resources :orders do
      collection do
        post 'offer_promotion'
      end
      resources :adjustments, only: [:destroy]
      delete 'remove_line_adjustments'
    end

    devise_scope :spree_user do
      resources :share, only: [:show, :create]
    end
    resource  :earn, only: [:show]
    resources :pods, only: [:show]
    resources :shelf_groups, only: [:show], path: 'shops', param: :permalink
    resources :newsletters, only: [:create]
    resources :giftcards, only: [:destroy] do
      member do
        patch :toggle_redeemable
      end
    end
    resources :merchants, only: [:show]

    get '/orders/current/can_add_product', to: 'orders#can_add_product'
    get '/orders/current/cart_refresh', to: 'orders#cart_refresh'
    get '/redeem', to: 'giftcards#redeem', as: 'gift_cards_redeem'
    get '/print/:id', to: 'giftcards#print', as: 'gift_cards_print'
    patch '/cart/set_quantity', to: 'orders#set_quantity'

    namespace :giftcard, path: 'gift-card' do
      patch '/checkout/update/:state', to: 'checkout#update', as: :update_checkout
      get '/checkout/:state', to: 'checkout#edit', as: :checkout_state
      get '/checkout', to: 'checkout#edit', as: :checkout
    end

    namespace :admin do
      get '/search/merchants', :to => 'search#merchants', as: :search_merchants

      resources :groups
      resources :shelf_groups, except: %i(index)
      resources :shelf_product_styles
      resources :taxon_groups, only: %i(index)

      resources :shelves do
        collection do
          post :reload
          get :homelist
        end
      end
      resources :scheduled_promotions do
        collection do
          get :generated_codes
        end
      end
      resources :pods do
        collection do
          put :update_positions
        end
      end
      resource :minfraud, only: [:edit, :update], controller: :minfraud
      resource :site_preferences, only: [:edit, :update]
      resources :users, only: [] do
        member do
          post :comment, to: 'users/comments#create'
          put :one_time_password, to: 'users#one_time_password'
        end
        resources :comments, module: :users, only: [:index]
        resources :credit_cards, module: :users, only: [:index, :destroy]
      end
      resources :homepage_pods, only: :index
      resources :email_templates do
        collection do
          get :sublist
          get :references
          put :update_percentage
        end
      end
      resources :articles do
        member do
          put :move
        end
      end
      resources :shipments, only: [] do
        post 'clone', on: :member
      end
      resources :feature_experiments
      resources :giftcard_orders, only: [:index]
      resources :quarantine_orders, only: [:index]
      resources :orders, only: [] do
        post 'refresh_snapfulfil'
        resources :payments, only: [] do
          member do
            get 'mobile_paypal_refund'
            post 'mobile_paypal_refund'
          end
        end
      end

      resources :orders do
        member do
          get 'risk_output'
          get 'release'
        end
        resources :comments, module: :orders
      end

      resources :taxons do
        member do
          put :move
          put :update_positions
        end
      end
    end

    namespace :api do
      resources :taxon_groups, only: %i(index)
      resource :sign_in, only: :create
      resource :sign_up, only: [:create] do
        collection do
          post :fb_create
        end
      end

      resources :taxons, only: [:index] do
        get :merchant, on: :collection
      end

      resources :users do
        collection do
          get :me
        end
      end

      resources :invites, only: [:create, :index]

      resources :paypal_payments, only: :create
      resources :products do
        post :like
        get :liked_by_current_user, on: :collection
        get :likes, on: :collection
        post :likes, on: :collection
        get :landing, on: :collection
        post :refresh_recommendations, on: :collection
      end

      resources :orders do
        collection do
          get :mine, as: 'my_orders'
          get :current, as: 'current_order'
        end

        resources :adjustments, only: :destroy
      end

      resources :gift_card_orders do
        member do
          put :next
          put :advance
          put :complete
        end
      end

      resources :checkouts do
        collection do
          post :verify_address
        end
      end

      # route globbing for pretty nested taxon paths
      get '/t/*permalink', to: 'taxons#show', as: :api_nested_taxons
      # ordinary taxon access
      resources :taxons, only: [:show], constraints: { id: /[0-9|]+/ }
    end

    get 'easter', to: redirect('/shops/easter')
    get 'press', to: 'articles#index'

    get 'back2school', to: 'back_to_school#index'
    post 'back2school/spin', to: 'back_to_school#spin'

    get 'treasure_hunt', to: 'treasure_hunt#index'

    get 'sell', to: 'marketplace_landing#index', as: 'marketplace_landing'
    post 'sell', to: 'marketplace_landing#apply'

    %w(404 422 500).each do |code|
      get code, to: 'errors#show', code: code
    end
  end

  # Feature flags via Flipper
  constraints CanAccessFlipperUI do
    if ActiveRecord::Base.connection.table_exists? :flipper_features
      mount Flipper::UI.app(FeatureFlags.flipper) => '/admin/features'
    end
  end

  namespace :partners do
    resources :enchant, only: :none do
      post 'sidebar', on: :collection
    end
  end

  namespace :api, defaults: { format: 'json' } do
    resources :shelves do
      collection do
        get :tree
      end
    end
    resources :shelf_product_memberships
    resources :merchants, only: :show
  end
end
